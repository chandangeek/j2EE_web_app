var ipaddr="http://192.168.10.33:8080/Service"; 
var myipaddr="http://ingbtcpic2nb3nb:8080/UIA/";
//var width;
//$(document).on('click', 'a.resize', function() {
//		$cn = $('.container');
//		var width = 600, onComplete;
//		if (!$cn.data('fullWidth')) {
//			$cn.data('fullWidth', $cn.width());
//			$cn.css('maxWidth', $cn.width());
//		} else {
//			width = $cn.data('fullWidth');
//			$cn.data('fullWidth', null);
//			onComplete = function() {
//				$cn.css('maxWidth', null);
//			};
//		}
//		$cn.animate({
//			maxWidth : width
//		}, {
//			complete : onComplete
//		});
//		$(window).trigger('resize');
//		return false;
//	});
// $(function() {
// $('.tabcordion').tabcordion();
// });
//window.brunch = window.brunch || {};
//window.brunch['auto-reload'] = {
//	enabled : true
//};
//$(document).ready(function() {
////});
//$(window).resize(function() {
//	
//});
//		alert(wd+" "+hi);
////	$(document).ready(function() {
////		$('#accordion').accordion();
////	});
//		$cn = $('.container');
//		width = 1000; var onComplete;
//		if (!$cn.data('fullWidth')) {
//			$cn.data('fullWidth', $cn.width());
//			$cn.css('maxWidth', $cn.width());
//		} else {
//			width = $cn.data('fullWidth');
////			alert(width);
//			$cn.data('fullWidth', null);
//			onComplete = function() {
//				$cn.css('maxWidth', null);
//			};
//		}
//		$cn.animate({
//			maxWidth : width
//		}, {
//			complete : onComplete
//		});
//		$(window).trigger('resize');
////		return false;
//		alert(width);
//		$('.tabcordion').tabcordion();
//		}
//});
$("#taskmsg").hide();
function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
  }
return "";
}

function deletecookies(){
	var cookies = document.cookie.split(";");

	for (var i = 0; i < cookies.length; i++) {
		var cookie = cookies[i];
		var eqPos = cookie.indexOf("=");
		var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		window.location.replace(myipaddr);
	}
}

//// $(document).ready(function() {
//// $("#sphome").click(function(event){
//// $("#col2").show();
//// $("#noservice").hide();
//// loc=ipaddr+"/Service/index.html";
//// //checkloc(value.patId,value.medName);
//// NoServices(loc,function(status){
//// if((status == 200)){// dynamiciframe!= null
//// $('#dynamiciframe').attr('src', loc);
//// $("iframe").show();
//// }
//// else if(status == 404 || status == 503 ){
//// // alertify.alert('<h1>Sorry, Service is not available for this
//// profile</h1>');
//// $("#noservice").show();
//// $("#strt").hide();
//// $("#jstorder").hide();
//// }
//// });
//// });
//// });
//// config.EnableCors(new EnableCorsAttribute(Properties.Settings.Default.Cors,
//// "", ""));
//// app.UseCors(CorsOptions.AllowAll);
var patid,pid,patdob,patname;
var firsttime=0,cot=0;
//$("#showTable").click(function(event){
//	//cot=0;
//	alert("patient details");
//		resetservicedisplay();
//		location.href="#home";
//	          getpatientdetails();
//	         // $(window).trigger('hashchange');
//	   });    
var back=0;
function getpatientdetails()
{
//	 resetservicedisplay();
	// $("#col2").hide();
//	location.hash="#";
	resetservicedisplay();
	 $.get('rest/patient/'+patid,function(responseJson) {
         if(responseJson!=null){
             $("#patienttable").find("tr:gt(0)").remove();
             var table1 = $("#patienttable");
             $.each(responseJson, function(key,value) { 
             	pid=value.patId;
             	patname=value.patName;
             	patdob=value.patDob;
             	document.getElementById("paid").innerHTML=pid;
             	document.getElementById("paname").innerHTML=value.patName;
             	document.getElementById("dob").innerHTML=value.patDob;
             	document.getElementById("bg").innerHTML=value.patBloodGroup;
             	document.getElementById("addr").innerHTML=value.patAddress;
             	document.getElementById("cty").innerHTML=value.patCity;
             	document.getElementById("sta").innerHTML=value.patState;
             	document.getElementById("ph").innerHTML=value.patPhone;
             	document.getElementById("ei").innerHTML=value.patEmail;
             });
             }
         });
         $("#tablediv").show();
        // $("#tablediv2").hide();
//         alert(cot);
//     	alert(width);
         if(cot || back)
        	 {
        	// alert("inside that");
//        	 if(width>1000)
//     		{
//        	 document.getElementById("c1").setAttribute("style", "width:100%");
//             document.getElementById("col2").setAttribute("style", "width:30%");
        	 clearclass();
         document.getElementById("hom").className="home2 active in tab-pane";
         document.getElementById("pd").className="active";
//     		}
        	 }
}
function clearclass()
{
	document.getElementById("hom").className="home2 tab-pane";
    document.getElementById("pro").className="profile2 tab-pane";
    document.getElementById("msg").className="messages2 tab-pane";
    document.getElementById("stt").className="settings2 tab-pane";
    document.getElementById("ab").className="abcd3 tab-pane";
    document.getElementById("abc").className="abcd2 tab-pane";
    document.getElementById("abcd").className="abcd0 tab-pane";
    document.getElementById("docser").className="abcd1 tab-pane";
    document.getElementById("pd").className="";
    document.getElementById("md").className="";
    document.getElementById("tk").className="";
    document.getElementById("at").className="";
    document.getElementById("hhr").className="";
    document.getElementById("ool").className="";
    document.getElementById("aaf").className="";
    document.getElementById("ssd").className="";
}
function checkingsize()
{
	var wd=$(document).width();
	var hi=$(document).height();
//	alert(wd+" "+hi);
	if(wd<963)
		{
//		change class tab-pane to --accordion-body collapse... but to changeing in clearclass and set where where ever required.....
		$("#desktopdisplay").remove();
//		alert("mobile");
		$("#loading").remove();
		enable_scroll();
//		document.getElementById("c1").setAttribute("style", "width:100%");
		}
	else
		{
		$("#mobiledisplay").remove();
//		alert("inside");
		$("#loading").remove();
		enable_scroll();
		}
}

var keys = [37, 38, 39, 40];

function preventDefault(e) {
  e = e || window.event;
  if (e.preventDefault)
      e.preventDefault();
  e.returnValue = false;  
}

function keydown(e) {
    for (var i = keys.length; i--;) {
        if (e.keyCode === keys[i]) {
            preventDefault(e);
            return;
        }
    }
}

function wheel(e) {
  preventDefault(e);
}

function disable_scroll() {
  if (window.addEventListener) {
      window.addEventListener('DOMMouseScroll', wheel, false);
  }
  window.onmousewheel = document.onmousewheel = wheel;
  document.onkeydown = keydown;
}

function enable_scroll() {
    if (window.removeEventListener) {
        window.removeEventListener('DOMMouseScroll', wheel, false);
    }
    window.onmousewheel = document.onmousewheel = document.onkeydown = null;  
}

function checkcookie()
{
	patid=getCookie("patid");
		if(patid=='')
			{
			window.location.replace(myipaddr);
			}
		else
			{
			disable_scroll();
			}
}

function geturl()
{
	window.location.hash='#home';
	//alert(window.location.href);
//	if(width>1000)
//	{
	clearclass();
//	}
	getpatientdetails();
	resetservicedisplay();
//	if(width>1000)
//		{
	document.getElementById("hom").className="home2 active in tab-pane";
	document.getElementById("pd").className="active";
//		}
}

function urlbased()
{
	    var hash = location.hash;
//	    alert("hash "+hash);
	    if(hash=="#medication" && !(hash=="#medication/#"))
	    	{
	    	getmedication();
	    	}
	    else if(hash=="#tasks" && !(hash=="#tasks/#"))
	    	{
	    	gettasks();
	    	}
	    else if(hash=="#appointments" && !(hash=="#appointments/#"))
	    	{
	    	getappoints();
	    	}
	    else if(hash=="#healthrecord" && !(hash=="#healthrecord/#"))
	    	{
	    	getpr();
	    	}
	    else if(hash=="#orders" && !(hash=="#orders/#"))
    	{
	    	$("#nothing4").hide();
	    	getorders();
	   	 $("#col2").show();
		 $("#strt").show();
		 $("#myservices").show();
		 $("#cond").show();
		 $("#om").show();
		 $("#orderform").show();
    	}
	    else if(hash=="#af" && !(hash=="#af/#"))
    	{
	    	aform();
    	}
	    else if(hash=="#sd" && !(hash=="#sd/#"))
    	{
	    	searchdoc();
    	}
	    else if(hash=="#home" && !(hash=="#home/#"))
	    {
	    	getpatientdetails();
	    }
//	  });
}
var medNam,medDosag,loc,medcount=0,qty,reqty=100,mededate;
// var theshold=31,;
$(document).ready(function() {
	// medname="medName",meddosage="medDosage";
	var not;
	resetservicedisplay();
	$("#nothing").hide();
	     $("#showMedication").click(function(event){
	    	 resetservicedisplay();
	    	 patdisease="";
	    	 patid=getCookie("patid");
	    	 medcount++;
	    	 var myth;
	           $.get('rest/medicine/'+patid,function(responseJson) {
	        	   location.hash="#medication";
	//        	   var routers = new Array();
//	        	   var route1 = crossroads.addRoute('/#medication/medicine/'+patid);
//	        	   route1.rules = {
//	        			   
//	        			   section:['crocin','100mg'],
//	        			   id : function(value, request, valuesObj){
//	        			        if(isNaN(value)){
//	        			            return false;
//	        			        }else{
//	        			            if(+value < 100 && valuesObj.section == 'crocin'){
//	        			                return true;
//	        			            }else if(valuesObj.section == '100mg'){
//	        			                return true;
//	        			            }else{
//	        			                return false;
//	        			            }
//	        			        }
//	        			    },
//	        			    request_ : function(request){
//	        			        return (request != '13');
//	        			    },
//	        			    normalize_ : function(request, vals){
//	        			        //ignore "date" since it isn't important for the application
//	        			        return [vals.section, vals.id];
//	        			    }
//	        			 
//	        			};
//	        	   crossroads.parse(document.location.pathname);
//	        	   alert(document.location.hash);
//	        	   var default_routes = crossroads.addRoute("#medication",function(){
//	   				//getmedication(); // The function that you would like to call when somebody hits a url like yoursite.com/product/123
	        	   iservice="Pharmacy";
	            if(responseJson!=null){
	                $("#medicinetable").find("tr:gt(0)").remove();
	                var table1 = $("#medicinetable");
	                var check=0;
	                $.each(responseJson, function(key,value) {
	                	qty=value.medAvail;
// alert(qty);
	                	not=qty;
	                	myth=theshold;
                		mededate=value.medEndDate;
                		// alert(qty+" "+myth);
	                	// $("#col2").show();
	                	if(qty<myth)
	            		{
// alert("inside condition thes");
	                		reqty=qty;
	                		medNam=value.medName;
	                		medDosag=value.medDosage;
	                		gettotalmedicine(patid,value.medName,value.medDosage);
// getmedicinesno(patid,medNam,medDosag);
// alert(reqty);
	            		}
	                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
// rowNew.children().eq(0).text(value['medId']);
// rowNew.children().eq(0).text(value['patId']);
	                        rowNew.children().eq(0).text(value['medName']); 
	                        rowNew.children().eq(1).text(value['medDosage']);
	                        rowNew.children().eq(2).text(value['medFrequency']);
	                        rowNew.children().eq(3).text(value['medStartDate']); 
	                        rowNew.children().eq(4).text(value['medEndDate']); 
	                        rowNew.children().eq(5).text(value['qty']); 
	                        rowNew.children().eq(6).text(value['medAvail']); 
	                        rowNew.appendTo(table1);
	                        // alert(mededate);
	                        getremainingdays(mededate);
//	                        alert(remaindays+" "+medNam);
// $.notific8('Hi, Your '+medNam+' course will end in '+remaindays+' days' , {
// life: 5000,
// heading: 'Medication Course',
// theme: 'amethyst',
// horizontalEdge: 'bottom',
// verticalEdge: 'right',
// zindex: 1500
// });
	                        $("#tablediv2").show();
	                        if(reqty==100)
	                        	{
//	                        	getmedserviceattri();
	                        	}
	                        if(reqty<myth)
		            		{
	                        	$("#col2").show();
		                		 $("#myservices").show();
		                		 $("#strt").show();
	                        getserviceurl("Medication Supplier");
//	                        document.getElementById("c1").setAttribute("style", "width:70%");
//	                        document.getElementById("col2").setAttribute("style", "width:30%");
		            		}
	                });
	                $("#nothing").hide();
	                }
	            if(typeof not == 'undefined')
	            	{
	            	$("#col2").hide();
	            	$("#nothing").show();
            		$("#tablediv2").hide();
            		}
	            else if(qty>theshold) 
	            	{
//	            	$("#col2").show();
//	            	$("#myservices").show();
//	            	getmedserviceattri();
	            	}
	        	//   });
	            });
	            // $("#tablediv2").show();
	  });      
	});

var iservice,inx;
function  getmedserviceattri()
{
	// set get request to getserviceattri service
// xmlHttp = GetXmlHttpObject();
// var req_url = 'rest/patient/getserviceattri/Pharmacy';
// SendAsync_GETRequest(xmlHttp,req_url,null,allattributes);
	resetservicedisplay();
	$("#col2").show();
	$("#strt").show();
	 $.get('rest/patient/getserviceattri/Pharmacy',function(responseJson) {
		 location.hash="#pharmacyattri";
		 iservice="Pharmacy";
		 inx=0;
         if(responseJson!=null){
            // $("#plist").find("tr:gt(0)").remove(); //get the div where to
			// display attributes
             var table1 = $("#plist"); // get the div where to display
										// attributes
             var dispattri=$("<div></div>");
             var atvalue;
             $.each(responseJson, function(key,value) {
            	 atvalue=value.spAttri;
// alert(atvalue);
            	 inx++;
            	 dispattri.append("<div><input type=\"button\" value=\""+value.spAttri+"\" id='med"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></div><hr />"); 
            	 dispattri.appendTo(table1);
             });
             $("#plist").show(); // get the div where to display attributes
         }
	 });
}

// check url #new/#foofor the state and display based on if.. getpr() or
// getfitserviceattri(0)
//var self;
//self.list=['Healthrecord'];

// dscnks' get getonediscount service to create with discount id and its
// description returning' and alseo check the ipaddr for required medication
// form its not coorect....
var subcribed,checkonce=false;
var checkyoga=null,onlyone=0;
function getfitserviceattri(ct)
{
//	alert(none);
//	if(none!=0)
//	{
//		none++;
//	}
//	else
//		{
	inx=0;
	$.get('rest/patient/getserviceattri/Fitness/'+patid,function(responseJson) {
		iservice="Fitness";
		var atrr;
        if(responseJson!=null){
        	$("#hlist").empty();
            var table1 = $("#hlist"); // get the div where to display
            var dispattri=$("<div></div>");
            var atvalue="";
            dispattri.append("<h2>Click to Subcribe</h2><hr>");
            $.each(responseJson, function(key,value) {
//            	alert(patdisease+" "+value.sp_atrri);
            	var subsattri=value.atrri_type;
            	 if(subsattri!=null && value.sp_url!=null)
                 {
                 	subcribed=subsattri;
                 	surl=value.sp_url;
//                 	alert(surl+" "+subcribed);
                 	inx++;
                 	if(subcribed=='Yoga')
                 	{
                 	checkyoga='Yoga';
                 	}
                 	displayfitservice(surl,subcribed);
                 }
            	 else if((patdisease=='heart ' && value.sp_atrri=='music') || (patdisease=='diabetic' && value.sp_atrri=='Fitness Tips') || (patdisease=='malaria' && value.sp_atrri=='Diet Service') || (patdisease=='cold' && value.atrri_type=='Diet Service') || (patdisease=='thyroid' && value.atrri_type=='Yoga')) //((patdisease=='Anemia' || patdisease=='jaundice' || patdisease=='diarrhea') && value.sp_atrri=='Yoga') || ((patdisease=='heart ' || patdisease=='diabeties') && value.sp_atrri=='Yoga') || (patdisease=='malaria' && value.sp_atrri=='Fitness tips') ||  (patdisease=='diarrhea' && value.sp_atrri=='Diet Service')   
	            {
	            	atvalue=value.sp_atrri;
//	                	alert("inside for"+atvalue);
	            	if(atvalue!=null)
	            	{
//	            		none=0;
	                	dispattri.append("<div><input type=\"button\" value=\""+value.sp_atrri+"\" id='fit"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></div><hr />"); // .fit"+inx+"
	                    dispattri.appendTo(table1);
//	            		document.getElementById("hlist").innerHTML="<div><input type=\"button\" value=\""+value.sp_atrri+"\" id='fit"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></a></div><hr />";
	                    inx+=1;
	                    $("#col2").show();
	                    $("#myservices").show();
	            		$("#strt").show();
	                    $("#hlist").show(); // get the div where to display attributes
	                    $("#hs").show();
	                    checkyoga='Fitness';
	                	if(value.sp_atrri=='Diet Service')
	            		{
	            		dsurl=value.sp_url;
//	            		alert(dsurl);
	            		}
	                }
	            }
            });
        }
	});
//	if(none!=0)
//		{
//            	 if(inx==0 && checkyoga==null)
//            		 {
//            		 $.get('rest/patient/getserviceattrionly/Fitness/',function(responseJson) {
//            				iservice="Fitness";
//            				var atrr;
//            		        if(responseJson!=null){
//            		        	$("#hlist").empty();
//            		            var table1 = $("#hlist"); // get the div where
//															// to display
//            		            var dispattri=$("<div></div>");
//            		            var atvalue="";
//            		            dispattri.append("<h2>Click to Subcribe</h2><hr>");
//            		            $.each(responseJson, function(key,value) {
//// alert(patdisease+" "+value.sp_atrri);
//            		            	var subsattri=value.atrri_type;
//            		                 	subcribed=subsattri;
//            		                 	 if(subsattri=='Yoga')
//            		                 		{
//            		                 		surl=value.sp_url;
//            		                 		alert(surl);
//            			                	dispattri.append("<div><input type=\"button\" value=\""+value.atrri_type+"\" id='fit"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></div><hr />"); // .fit"+inx+"
//            			                    dispattri.appendTo(table1);
//// document.getElementById("hlist").innerHTML="<div><input type=\"button\"
//// value=\""+value.sp_atrri+"\" id='fit"+inx+"' width='100%'
//// onclick=\"getserviceurl(this.value)\" /></a></div><hr />";
//            			                    inx+=1;
//            			                    $("#col2").show();
//            			                    $("#myservices").show();
//            			            		$("#strt").show();
//            			                    $("#hlist").show(); // get the div
//																// where to
//																// display
//																// attributes
//            			                    $("#hs").show();
//            			                    checkyoga='Yoga';
//            			                }
//            });
//        }
//	 });
//            		 }
//            	 else
//            		 {
////            			alert(inx+" "+checkyoga);
//            		 $("#hlist").empty();
//            		 $("#hs").hide();
//            		 }
//		}
}

function showifonlyyoga()
{
//	 if(inx==0 && checkonce==true)
//	 	{
	 	$("#hlist").empty();
	     var table1 = $("#hlist"); // get the div where to display
	     var dispattri=$("<div></div>");
	     var atvalue="";
	     dispattri.append("<h2>Click to Subcribe</h2><hr>");
	 	$.get('rest/patient/getserviceattrionly/Fitness/',function(responseJson) {
	 		iservice="Fitness";
	 		//inx=0;
	 		var atrr;
	         if(responseJson!=null){
	         	$("#hlist").empty();
//	             var table1 = $("#hlist"); // get the div where to display
//	             var dispattri=$("<div></div>");
	             var atvalue="";
//	             dispattri.append("<h2>Click to Subcribe</h2><hr>");
	             $.each(responseJson, function(key,value) {
//	             	alert(patdisease+" "+value.sp_atrri);
	             	if(value.atrri_type=='Yoga')
	     	            {
	     	            	dispattri.append("<div><input type=\"button\" value=\""+value.atrri_type+"\" id='fit"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></div><hr />"); // .fit"+inx+"
	                         dispattri.appendTo(table1);
	                         inx+=1;
//	                         alert(value.atrri_type);
	                         $("#col2").show();
	                         $("#myservices").show();
	                 		$("#strt").show();
	                         $("#hlist").show(); // get the div where to display attributes
	                         $("#hs").show();
	     	            }
	             });
	         }
	         });
	 	//$("#myservices").hide();
	      //$("#hs").hide();	
//	 	}
//		 $("iframe").show();
//		 $("#newiframe").show();
		 checkonce=true;
}

function getsubcriberlist(myslist)
{
//	alert(myslist);
//	if(mylist!=null)
//		{
	$.get('rest/patient/fitsubcriberlist/'+patid+'/'+myslist,function(responseJson) {
	    if(responseJson!=null){
	        $.each(responseJson, function(key,value) {
	        	subcribed=value.atrri_type;
	        	if(subcribed!='Diet Service')
	        		{
	        	surl=value.sp_url;
	        	displayfitservice(surl,subcribed);
	        		}
	        	else
	        		{
	        		dsurl=value.sp_url;
//	        		alert(subcribed+" "+dsurl);
	        		}
//	        	alert(surl);
//	        	if(surl!=null)
//	        		{
//	        	
//	        		}
	        });
	    }
//	    else
//	    	{
//	    	return null;
//	    	}
	});
	return subcribed;
//		}
//	else
//		{
//		return null;
//		}
}

var surl;
var tiphistroy=[],z=0,j=0;
var previoustip,currenttip,ds=false,dsurl;
function displayfitservice(serviceurl,at)
{
//	alert(serviceurl+" "+at);
//	if(tiphistroy[i]!=null)
//		{
//		j++;
//	previoustip.push(tiphistroy[i]);
//	i++;
//	$.get(surl+"/rest/thirdparty/"+tiphistroy,function(responseJson) { // /getservice
//	    if(responseJson!=null){
//	    	  var table1 = $("#fittemplate"); 
//	    	  var dispattri=$("<div></div>");
//	        $.each(responseJson, function(key,value) {
//	        	if(tiphistroy!=value.sd_id)
//	        		{
//	        	tiphistroy.push(value.sd_id);//set the tip id for url change.....
//	        	currenttip=value.sd_id;
//	        	alert(currenttip);
//	        	location.href="#healthrecord/#fitness/#"+subcribed+"/#"+currenttip;
////	        	dispattri.append("<div><b><u>"+subcribed+"-Tip of The Day</u></b></div>");
////	        	dispattri.append("<div>"+value.com_desc+"</div>");
////	        	dispattri.append("<input type='button' value='next tip' onclick='getnexttask()'");
////	        	dispattri.appendTo(table1);
////	        	return;
//	 document.getElementById("title").innerHTML="<b><u>"+subcribed+"-Tip of The Day</u></b>";//json values
//	 document.getElementById("derc").innerHTML=value.com_derc;
////	 document.getElementById("ifany").innerHTML=value.;
////   	 document.getElementById("next").inerHTML="<input type='button' value='next tip' onclick='getnexttask("+serviceurl+")>";
//	        		}
//	        });
//	    }
//	});
//		}
//	else
//		{
	//var checkyoga=null;
	if(at!='Diet Service')
		{
		myAgeValidation();
		$.get(serviceurl+"/rest/thirdparty/subscribe/"+patid+"/"+patname+"/"+age+"/"+patdisease,function(responseJson) { // subcribe/
		    if(responseJson!=null){
		    	var table1 = $("#fittemplate"); 
		    	  var dispattri=$("<div></div>");
		  		previoustip=currenttip;
		  		var once=true;
		        $.each(responseJson, function(key,value) {
		        	if(tiphistroy!=value.sd_id)
		        		{
		        	tiphistroy.push(value.sd_id);//set the tip id for url change.....
		        	z=z+1;
		        	tipback=z;
//		        	alert(tiphistroy);
		        	if(once==true)
		        		{
		        	currenttip=value.sd_id;
//		        	alert(at+" "+currenttip);
		        	if(at!='Diet Service')
		        		{
		        		if(at=='Yoga')
		        			{
		        		checkyoga='Yoga';
		        	location.href="#healthrecord/#fitness/#"+at+"/#"+currenttip;
		        			}
		        		}
		        	else
		        		{
		        		ds=true;
		        		}
		        	once=false;
		        	$("#fittemplate").empty();
		        	subcribed=at;
		        	dispattri.append("<div><h4>"+at+"-Tip of The Day<h4></div>");
		        	dispattri.append("<div>"+value.com_desc+"</div>");
		        	dispattri.append("<div><input type='button' value='next tip' onclick='getnexttip()'</div>");
		        	dispattri.appendTo(table1);
//		        	alert(once);
//		        	 document.getElementById("title").innerHTML="<h2><u>"+at+"-Tip of The Day</u></h2>";//json values
//		    		 document.getElementById("derc").innerHTML=value.com_desc;
		        		}
//		        	
		 //document.getElementById("ifany").innerHTML=value.;
	   	 //document.getElementById("next").inerHTML="<input type='button' value='next tip' onclick='displayfitservice("+serviceurl+")>";
		        		}
		        });
		    }
		});
//		if(inx==0 && checkyoga==null)
//		{
//			showifonlyyoga();
//		}
//		}
		$("#col2").show();
		$("#myservices").show();
		$("#strt").show();
		$("#cond").show();
	$("#fittemplate").show();
		}
	else
		{
		if(checkyoga!='Yoga' && at=='Diet Service')
		{
			durl=serviceurl;
			location.href="#healthrecord/#fitness/#"+at;
		}
//		window.open(serviceurl);
		}
}
var abcurl;
var o=true;
function displaytip()
{
//	alert("display tip");
//	if(checkyoga=='Yoga')
//	{
////	alert(inx+" "+checkyoga);
//	if(inx==0 && checkyoga==null)
//		{
//			showifonlyyoga();
//		}
//	}
//	else
//		{
	myAgeValidation();
	$.get(abcurl,function(responseJson) { // subcribe/
	    if(responseJson!=null){
	    	$("#fittemplate").empty();
	    	var table1 = $("#fittemplate");
	    	  var dispattri=$("<div></div>");
	        $.each(responseJson, function(key,value) {
//	        	location.href="#healthrecord/#fitness/#"+subcribed+"/#"+currenttip;
//	        	tiphistroy.push(value.sd_id);
	        	currenttip=value.sd_id;
//	        	alert(value.com_desc+" "+value.sd_id);
//	        	 document.getElementById("title").innerHTML="<h2><u>"+subcribed+"-Tip of The Day</u></h2>";//json values
//	    		 document.getElementById("derc").innerHTML="<p>"+value.com_desc+"</p>";
	        	dispattri.append("<div><h4>"+subcribed+"-Tip of The Day</h4></div>");
	        	dispattri.append("<div>"+value.com_desc+"</div>");
	        	dispattri.append("<input type='button' value='next tip' onclick='getnexttip()'/>");
//	        	alert(currenttip);
	        	dispattri.appendTo(table1);
//	    		 if(checkyoga=='null')
//	    			 {
	    			 checkyoga='Yoga';
//	    			 }
	        });
	    }
//	    if(o==true)
//	    	{
//	    	$("#hs").show();
//	    	o=false;
//	    	}
//	    else
//	    	{
//	    	$("#hs").remove();
//	    	}
//	    if(checkyoga!='Yoga')
//	    	{
//	    		window.open(dsurl);
//	    	}
	});
//		}
	$("#col2").show();
	$("#myservices").show();
	$("#strt").show();
	$("#cond").show();
	$("#fittemplate").show();

	$("#tablediv5").show();
	clearclass();
	document.getElementById("ab").className = "abcd3 active in tab-pane";
	document.getElementById("hhr").className = "active";
//	if(ds==true)
//	{
//		$("#hs").hide();
//		$('#dynamiciframe').attr('src', dsurl+"/abc.html?patid="+patid+"&patage="+age+"&patdisease="+patdisease+"&patname="+patname);
//		$("iframe").show();
//	}
}

function getnexttip()
{
	myAgeValidation();
//	alert(surl+" "+tiphistroy[z-1]);
	$.get(surl+"/rest/thirdparty/nexttip"+"/"+age+"/"+tiphistroy[z-1],function(responseJson) { // subcribe/
	    if(responseJson!=null){
	    	$("#fittemplate").empty();
	    	var table1 = $("#fittemplate");
	    	  var dispattri=$("<div></div>");
	        $.each(responseJson, function(key,value) {
	        	tiphistroy.push(value.sd_id);//set the tip id for url change.....
	        	z=z+1;
	        	tipback=z;
	        	currenttip=value.sd_id;
	        	location.href="#healthrecord/#fitness/#"+subcribed+"/#"+currenttip;
	        	dispattri.append("<div><b><u>"+subcribed+"-Tip of The Day</u></b></div>");
	        	dispattri.append("<div>"+value.sd_desc+"</div>");
	        	dispattri.append("<input type='button' value='next tip' onclick='getnexttask()'");
	        	dispattri.appendTo(table1);
//	 document.getElementById("title").innerHTML="<h4>"+subcribed+"-Tip of The Day/h4>";//json values
//	 document.getElementById("derc").innerHTML=value.com_desc;
	 //document.getElementById("ifany").innerHTML=value.;
   	 //document.getElementById("next").inerHTML="<input type='button' value='next tip' onclick='displayfitservice("+serviceurl+")>";
//	        		}
	        });
	    }
	});
//	alert(tiphistroy);
//	$("#col2").show();
//	$("#myservices").show();
//	$("#strt").show();
//	$("#cond").show();
$("#fittemplate").show();
}

var ex_date,discountderc,displaydiscount=0;
function gettaskservice()
{
	 resetservicedisplay();
		$.get('rest/patient/getservicetask',function(responseJson) {
    if(responseJson!=null){
       // $("#dcdiv").find("tr:gt(0)").remove(); //get the div where to display
		// attributes
// var table1 = $("#dcdiv"); //get the div where to display attributes
// var dispattri=$("<div></div>");
// var dis;
        $.each(responseJson, function(key,value) {
        	discountderc=value.discount_desc;
       	 document.getElementById("discountders").innerHTML=value.discount_desc;
       	 document.getElementById("discode").value=value.discount_id;
       	 document.getElementById("discountcode").innerHTML=value.discount_id;
       	 ex_date=value.expire_date;
        });
    }
});
		 $("#col2").show();
	        $("#myservices").show();
	        $("#strt").show();
//	        $("#taskcom").show();
	        $("#cond").show();
	        $("#dc").show();
	        $("#dcdiv").show(); // get the div where to display attributes
	        $("#taskcom").show();
	        alertify.success("<h4>Congratulations--See your Discount</h4>");
}
var serviceipaddr,atrri;
function getserviceurl(attris) 
{
	atrri=attris;
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/patient/getservice/'+iservice+'/'+attris;
	SendAsync_GETRequest(xmlHttp,req_url,null,singleurl);
}

function singleurl()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	// Json response
		if(json_resp!=null)
			{
			serviceipaddr=json_resp;
			 // display home page of the 3rd partiy service using
				// serviceurl...
			if(reqty<theshold)
				{
				respipaddr=json_resp;
// alert(respipaddr);
				loc=respipaddr+"/rest/medicationservice/imdjson/"+patname+"/"+medNam+"/"+medDosag;
// alert(loc);
        		getorderlist(loc);
        		reqty=100;
				}
			else if(inx!=0 ){
				if(atrri=='Diet Service')
					{
					insertsubcription(json_resp);
					myAgeValidation();
					$('#dynamiciframe').attr('src', json_resp+"/abc.html?patid="+patid+"&patage="+age+"&patdisease="+patdisease+"&patname="+patname);
					$("iframe").show();
					$("#hs").hide();
					}
				else
					{
						insertsubcription(json_resp);
						displayfitservice(json_resp,atrri);
						$("#hs").hide();
					}
	            	}
			else if(document.getElementById("tprice").value>=0)
				{
					//alert(document.getElementById("tprice").value);
				}
			else if(subcribed!="" && !(reqty<myth))
				{
				insertsubcription(json_resp);
				//displayfitservice(json_resp);
				}
//			else if(patdisease!="")
//        	{
//				getfitnessservice();
//				patdisease="";
//        	}
			else
				{
				displayservice();
				}
			}
		else
			{
			alertify.alert("<h3>Service Not Found for this service type and attribute</h3>");
			}
	}
}

function insertsubcription(spurl)
{
	xmlHttp  = GetXmlHttpObject();
	//create json and pass in param... pid, pdisease, spurl...
	var formd={};
	formd["patid"]=patid;
	formd["s_type"]=iservice;
	formd["atrri_type"]=atrri;
	formd["sp_url"]=spurl;
	var param = JSON.stringify(formd);
//	alert(param);
	var req_url = 'rest/patient/setsubcription/'; // +patid+'/'+iservice+'/'+atrri+'/'+spurl;
	SendAsync_PostRequest(xmlHttp,req_url,param,conformsub);
}
function conformsub()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	// Json response
		if(json_resp!=null)
			{
			alertify.success("<h3>subcription added</h3>");
			}
	}
}
function resetservicedisplay()
{
	$("col2").hide();
	$("#myservices").hide();
	$("#strt").hide();
	$("#spserving").hide();
	$("#noservice").hide();
	$("#ps").hide();
	$("#hs").hide();
	$("#dc").hide();
	$("#om").hide();
	$("#plist").hide();
	$("#hlist").hide();
	$("#dcdiv").hide();
	$("#taskyet").hide();
	$("#taskcom").hide();
	$("#orderform").hide();
	$("#customo").hide();
	$("iframe").hide();
	$("#fittemplate").hide();
	$("#muteservice").hide();
	$("#demo").hide();
	$("#mapholder").hide();
	// $("#closeimage").hide();
	first=1;
}
function displayservice()
{
	resetservicedisplay();
	loc=serviceipaddr;
	NoServices(loc,function(status){
		if(status==204)
			{
			$('#dynamiciframe').attr('src', loc);
			$("iframe").show();
			}
		else if(status == 404 || status == 503){  // 503 Service Unavailable
			// alertify.alert('<h1>Sorry, Service is not available for this
			// profile</h1>');
						$("#noservice").show();
						$("#strt").hide();
		}
     		 });
}
/*var dyn='dynamicifame';
if(dyn=='')
	{
		displayiframeservice();
	}


function displayiframeservice()
{
	resetservicedisplay();
	loc=serviceipaddr;
	NoServices(loc,function(status){
		if(status==204)
			{
			$('#newiframe').attr('src', loc);
			$("iframe").show();
			}
		else if(status == 404 || status == 503){  // 503 Service Unavailable
			// alertify.alert('<h1>Sorry, Service is not available for this
			// profile</h1>');
						$("#noservice").show();
						$("#strt").hide();
		}
     		 });
}*/

function getorderlist(locc)
{
	resetservicedisplay();
	$("#col2").show();
	$("#myservices").show();
	$("iframe").hide();
//	alert(locc);
	NoServices(locc,function(status){
		var notg;
			 $.get(locc,function(rJson) {
  	            if(rJson!=null){
  	            	$.each(rJson, function(key,value) {
  	            		gettotalmedicine(patid,value.med_name,value.med_dosage);
  	            		notg=value.med_name;
  	            		// alert(value.ppname);
// alert(notg);			
//  	            		alert(value.patname);
 	            		document.getElementById("ppname").value=patname;
	                	document.getElementById("mmname").value=value.med_name;
	                	document.getElementById("mdos").value=value.med_dosage;
	                	document.getElementById("price").value=value.med_price;
// alert(value.med_price);
  	            	});
  	            	$("#strt").show();
  	            	$("#spserving").show();
  	            }
  	            else
  	            	{
  	            	notg=null;
  	            	}
     		 });
		// }
		if(notg==null)
			{
			$("#strt").show();
			}
		else if(status == 404 || status == 503){  // 503 Service Unavailable
// alertify.alert('<h1>Sorry, Service is not available for this profile</h1>');
			$("#noservice").show();
			$("#strt").hide();
		}
	});
}
var theshold=10;
var later=false,one=true;
var tipback=0,seeconce=0,onetime=0;
$(function() {
	  // Bind an event to window.onhashchange that, when the hash changes, gets the
	  // hash and adds the class "selected" to any matching nav link.
	$(window).on('hashchange', function(){
//		z--;
//		alert(currenttip);
//		alert(subcribed+" "+tiphistroy[z-2] +" ");
		later=true;
	    var hash = location.hash;
//	    alert("hash "+hash);
//		alert(hash);
	    if(hash=="#medication" && !(hash=="#medication/#"))
	    	{
	    	getmedication();
	    	}
// 	    else if (one) {
//	}
 	    else if(hash=="#tasks" && !(hash=="#tasks/#"))
	    	{
	    	gettasks();
	    	}
	    else if(hash=="#appointments" && !(hash=="#appointments/#"))
	    	{
	    	getappoints();
	    	}
	    else if(hash=="#orders" && !(hash=="#orders/#"))
    	{
	    	getorders();
	    	$("#col2").show();
			$("#strt").show();
			$("#myservices").show();
			$("#cond").show();
			$("#om").show();
			$("#orderform").show();
    	}
	    else if(hash=="#af" && !(hash=="#af/#"))
    	{
	    	aform();
    	}
	    else if(hash=="#sd" && !(hash=="#sd/#"))
    	{
	    	searchdoc();
//	    	if(onetime>0)
//	    		{
//	    	if(inspecdept==1)
//	    		{
//	    		$("#btnname").hide();
//	    		}
//	    	else
//	    		{
//	    		$("#srh").hide();
//	    		$("#oneor").hide();
//	    		}
//	    		}
	    	onetime=1;
    	}
	    else if(hash=="#home" && !(hash=="#home/#"))
	    {
	    	back=1;
	    	getpatientdetails();
	    	back=0;
	    }
	    else if (hash == "#healthrecord/#fitness/#" + subcribed + "/#"+tiphistroy[tipback-2] && later==true) // && !(hash=="#healthrecord/#")
		{
			tipback=tipback-2;
//			currenttip=tiphistroy.pop();
//			z=z-1;
//			tiphistroy[z]=currenttip;
//			z=z+1;
			currenttip=tiphistroy[tipback];
//			alert(currenttip);
			abcurl = surl + "/rest/thirdparty/backtip/" + age +"/"+currenttip;
//			alert(abcurl);
			displaytip();
			seeconce=1;
		}
				// }
		else if (hash == "#healthrecord/#fitness/#" + subcribed + "/#"
						+ tiphistroy[tipback - 1]
						&& later == true) // && !(hash=="#healthrecord/#")
		{
				tipback = tipback - 1;
				currenttip = tiphistroy[tipback];
					// alert(currenttip);
				abcurl = surl + "/rest/thirdparty/backtip/" + age + "/"
							+ currenttip;
					// alert(abcurl);
				displaytip();
				seeconce=1;
		}
		else if (hash == "#healthrecord" && !(hash == "#healthrecord/#")) {
			if(seeconce==1)
			{
			tiphistroy = [];
			z = 0;
			tipback = 0;
			currenttip = "";
			getonlypr();
			seeconce=0;
			}
			else
				{
				getpr();
//				 $("#hs").show();
				}
	}
		else if (hash == "#healthrecord/#fitness/#" + subcribed)
			{
			myAgeValidation();
//			alert(age);
//			alert( durl+"/abc.html?patid="+patid+"&patage="+age+"&patdisease="+patdisease+"&patname="+patname);
				$('#dynamiciframe').attr('src', durl+"/abc.html?patid="+patid+"&patage="+age+"&patdisease="+patdisease+"&patname="+patname);
				$("#col2").show();
				$("#myservices").show();
				$("#strt").show();
				$("iframe").show();
				$("#cond").hide();
				$("#hs").hide();
			}
		else if(hash=="#searchdoctor")
			{
			$("#hidespec").hide();
			$("#deptdiv").hide();
			$("#btnname").hide();
//			$("#tablediv7").show();
//			$("#").show();
			}
//	    else if(hash=="#" && hash=="##")
//    	{
//    	
//    	}
//	    else if(hash=="#" && hash=="##")
//    	{
//    	
//    	}
//	    else if(hash=="#" && hash=="##")
//    	{
//    	
//    	}
//	    else if(hash=="")
//	    	{
////	    	alert("inside patient");
////	    	alert(hash);
//	    	cot++;
//	    	resetservicedisplay();
//	    	getpatientdetails();
//	    	}
	  });
});

function getmedication()
{
	resetservicedisplay();
	$.get('rest/medicine/'+patid,function(responseJson) {
		//location.hash="#medication";
		var myth;
        if(responseJson!=null){
            $("#medicinetable").find("tr:gt(0)").remove();
            var table1 = $("#medicinetable");
            iservice="Pharmacy";
            var check=0;
            $.each(responseJson, function(key,value) {
            	qty=value.medAvail;
            	not=qty;
            	myth=theshold;
        		medNam=value.medName;
            	if(qty<myth)
        		{
            		$("#col2").show();
            		$("#myservices").show();
            		$("#strt").show();
            		$("#spserving").show();
            		reqty=qty;
            		mededate=value.medEndDate;
// getmedicinesno(patid,medNam,medDosag);
            		gettotalmedicine(patid,value.medName,value.medDosage);
        		}
        		
                 var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
                 // rowNew.children().eq(0).text(value['medId']);
                 // rowNew.children().eq(0).text(value['patId']);
                    rowNew.children().eq(0).text(value['medName']); 
                    rowNew.children().eq(1).text(value['medDosage']);
                    rowNew.children().eq(2).text(value['medFrequency']);
                    rowNew.children().eq(3).text(value['medStartDate']); 
                    rowNew.children().eq(4).text(value['medEndDate']); 
                    rowNew.children().eq(5).text(value['qty']); 
                    rowNew.children().eq(6).text(value['medAvail']); 
                    rowNew.appendTo(table1);
                    $("#tablediv2").show();
                    getremainingdays(mededate);
// alert(remaindays);
//                    $.notific8('Hi Your '+medNam+' course will end in next '+remaindays+' days' , {
//      	    		  life: 5000,
//      	    		  heading: 'Medication Course Duration',
//      	    		  theme: 'amethyst',
//      	    		  horizontalEdge: 'bottom',
//      	    		  verticalEdge: 'right',
//      	    		  zindex: 1500
//      	    		});
//                    notif({
//                    	  type: "info",
//                    	  msg: '<b>Hi Your '+medNam+' course will end in '+remaindays+' days</b>',
//                    	  position: "right",
//                    	  opacity: 0.9
//                    	});
                    alertify.success('<b>Hi Your '+medNam+' course will end in '+remaindays+' days</b>');
            });
// $("iframe").show();
            if(reqty<myth)
    		{
            getserviceurl("Medication Supplier");
// $("#ps").show();
// $("#spserving").show();
    		}
            $("nothing").hide();
//            $("#orderform").hide();
            if(qty>theshold)
    		{
//            	getmedserviceattri();
    		}
            }
        if(typeof not == 'undefined')
        	{
        	$("#nothing").show();
    		$("#tablediv2").hide();
    		resetservicedisplay();
    		}
        else if(typeof mededate == 'undefined')
        	{
        	resetservicedisplay();
        	}
//        else if(document.getElementById("tprice").value==0)
//        {
//        	resetservicedisplay();
//        }
        });
//	 if(cot)
//	 {
//		 if(width>1000)
//			{
	 clearclass();
 document.getElementById("pro").className="profile2 active in  tab-pane";
 document.getElementById("md").className="active";
//			}
//	 }
}

var remaindays;

function getremainingdays(edate)
{
	var currentdate=getdate();
	 // Total time for one day
    var one_day=1000*60*60*24; 
// alert(currentdate+" "+edate);
// Here we need to split the inputed dates to convert them into standard format
    var x=edate.split("-");     
    var y=currentdate.split("-");

    var date1=new Date(x[0],(x[1]-1),x[2]);

    var date2=new Date(y[2],(y[0]-1),y[1]);
    var month1=x[1]-1;
    var month2=y[0]-1;
    
    // Calculate difference between the two dates, and convert to days
           
    remaindays=Math.ceil((date1.getTime()-date2.getTime())/(one_day)); 
// alert(remaindays);
}
var respipaddr;

function settingspurl()
{
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText; 
		json_resp=respiaddr;
	}
	else
		{
		alertify.alert("<h3>Server not Responding</h3>");
		}
}
function gettpriceg()
{
	var mediname=document.getElementById("mmnameg").value;
	var medidos=document.getElementById("mdosg").value;
	$.get(respipaddr+"/rest/medicationservice/setprice/"+mediname+"/"+medidos,function(rJson) {
          if(rJson!=null){
          	$.each(rJson, function(key,value) {
          		document.getElementById("priceg").value=value.med_price;
          	});
          }
          	});
}
function gettotal()
{
	var mediqty=document.getElementById("mqtyg").value;
	var uprice=document.getElementById("priceg").value;
	document.getElementById("tpriceg").value=mediqty*uprice;
}
function gettprice()
{
	var qqty=document.getElementById("mqty").value;
// alert(qqty);
	var uprice=document.getElementById("price").value;
// alert(uprice);
	document.getElementById("tprice").value=qqty*uprice;
}
function suborder()
{
	validateorder();
	
}
function validateorder()
{
	var a=validateopname();
	var b=validateomedname();
	var c=validateomeddosage();
	var d=validatemedoqty();
	var e=validateotprice();
	if(a == true || b == true || c == true || d == true || e == true)
		{
		insertorder();
		}
	else
		{
		alertify.alert("<h3>All the fields are compulsory</h3>");
		return false;
		}
}

function insertorderg()
{
	var formData = form2object('fgo', '.', true, function(node) {
		if (node.id && node.id.match(/ggg/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	var json = JSON.stringify(formData, null, '\t');
// alert(json);
	result = json;
	sendorder();
}

function insertorder()
{
	var formData = form2object('fo', '.', true, function(node) {
		if (node.id && node.id.match(/ooo/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	var json = JSON.stringify(formData, null, '\t');
// alert(json);
	result = json;
	sendorder();
}
var result;
function sendorder()
{
	xmlHttp = GetXmlHttpObject();
	var req_url = serviceipaddr+'/rest/medicationservice/orderinsert';
	var params = result;
// alert(result);
	SendAsync_PostRequest(xmlHttp, req_url, params, order_resp);
}

function order_resp()
{
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText;
		if(json_resp!=null)
			{
				alertify.success("<h3>order placed successfully, <br>Your order id is:"+json_resp+"</h3>");
				resetservicedisplay();
				if(medcount>0){
				// getmedication();
				}
			}
		else
		{
			alertify.alert("<h3>Order not placed internal server error<br>sorry, we will repair it shortly sorry, for the inconvience, thank you</h3>");
		}
	}
}
function validateopname()
{
	var ppname=document.getElementById("ppname").value;
	if(ppname !="" || ppname !=null)
		{
		alertify.alert("<h3>please enter patient name</h3>");
		return false;
		}
	return true;
}

function validateomedname()
{
	var ppname=document.getElementById("mmname").value;
	if(ppname !="" || ppname !=null)
		{
		alertify.alert("<h3>please enter medication name</h3>");
		return false;
		}
	return true;
}
function validateomeddosage()
{
	var ppname=document.getElementById("mdos").value;
	if(ppname !="" || ppname !=null)
		{
		alertify.alert("<h3>please enter medicine dosage</h3>");
		return false;
		}
	return true;
}
function validatemedoqty()
{
	var ppname=document.getElementById("mqty").value;
	if(ppname !="" || ppname !=null)
		{
		alertify.alert("<h3>please enter medicine quantity</h3>");
		return false;
		}
	return true;
}
function validateotprice()
{
	var ppname=document.getElementById("tprice").value;
	if(ppname !="" || ppname !=null)
		{
		alertify.alert("<h3>please enter quantity to get total price</h3>");
		return false;
		}
	return true;
}
var cdate,todaytaskcount=0;
$(document).ready(function() {
	 $("#tablediv3").hide();
	 $("#nothingtask").hide();
	 var not;
	     $("#showTask").click(function(event){
//	    	 $("#taskmsg").hide();
//	    	 $("#nothingtask").hide();
	    	 resetservicedisplay();
	    	 location.hash="#tasks";
    		 // gettaskservice();
	    	 if(todaytaskcount==0)
	    	{
	    	 todaytaskcount++;
	    	 patid=getCookie("patid");
	    	 cdate=getdate();
	           $.get('rest/task/'+patid+'/'+cdate,function(responseJson) {
	            if(responseJson!=null){
	                $("#tasktable").find("tr:gt(0)").remove();
	                var table1 = $("#tasktable");
	                $.each(responseJson, function(key,value) {
	                	taskno+=1;
	                	not=value.taskId;
	                     var rowNew = $("<tr><td></td><td></td></tr>");
// rowNew.children().eq(0).text(value['taskId']);
// rowNew.children().eq(0).text(value['patId']);
	                        rowNew.children().eq(0).text(value['taskDescription']); 
	                        rowNew.children().eq(1).text(value['status']); 
	                        rowNew.append("<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' value='Done' width='100%' id='drod' onclick='deletetask("+value.taskId+")'>");
	                        rowNew.appendTo(table1);
	                        $("#tablediv3").show();
	                });
	                }
	            if(typeof not == 'undefined')
            	{
//            	$("#nothingtask").show();
//            	$("#tablediv3").hide();
            	//gettaskservice();
        		}
	            else{
//	            	 $("#col2").show();
//	            	 $("#myservices").show();
//	            	$("#dc").show(); 
//	            	notif({
//	                	  type: "error",
//	                	  msg: 'Hi buddy,Special discount is waiting for you.<br>Complete your tasks to grab the offer ',
//	                	  position: "right",
//	                	  opacity: 0.9,
//	                	  height:100px
//	                	});
//	            	 alertify.error('<h2>Hi buddy,Special discount is waiting for you.<br>Complete your tasks to grab the offer</h2>');
	            	alertify.error('<b>Hi buddy, Special discount is waiting for you.<br><h5>Complete your tasks to grab the offer</h5></b>');
	            	$("#nothingtask").hide();
		    	 }
	            });
	    		 }
	  });      
	});

function getdate()
{
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; // January is 0!
	var yyyy = today.getFullYear();

	if(dd<10) {
	    dd='0'+dd;
	} 

	if(mm<10) {
	    mm='0'+mm;
	} 

	today = mm+'-'+dd+'-'+yyyy;
	return today;
}

function deletetask(tid)
{
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/patient/deletetask/'+tid;
	SendAsync_GETRequest(xmlHttp,req_url,null,conformdeleted);
}

function conformdeleted()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	// Json response
		if(json_resp!=null)
			{
			taskno-=1;
			alertify.success("<h3>Task Completed</h3>");
			first=0;
			gettasks();
			}
		else
			{
			alertify.alert("<h3>Wrong Operation</h3>");
			}
	}
}
var taskno=0,first=1;
function gettasks()
{
	var not;
	// resetservicedisplay();
	$("#nothingtask").hide();
	$("#taskmsg").hide();
	$.get('rest/task/'+patid,function(responseJson) {
		//location.hash="#tasks";
//		$("#col2").show();
//		$("#myservices").show();
//		$("#strt").show();
//		$("#cond").show();
//		$("#taskcom").show();
//		$("#nothingtask").hide();
//		$("#taskmsg").hide();
        if(responseJson!=null){
            $("#tasktable").find("tr:gt(0)").remove();
            var table1 = $("#tasktable");
            // gettaskservice();
            $.each(responseJson, function(key,value) {
            	not=value.taskId;
                 var rowNew = $("<tr><td></td><td></td></tr>");
// rowNew.children().eq(0).text(value['taskId']);
// rowNew.children().eq(0).text(value['patId']);
                    rowNew.children().eq(0).text(value['taskDescription']); 
                    rowNew.children().eq(1).text(value['status']); 
                    rowNew.append("<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='button' value='Done' id='drod' width='100%' onclick='deletetask("+value.taskId+")'>");
                    rowNew.appendTo(table1);
            });
            }
        $("#tablediv3").show();
    	$("#nothingtask").hide();
    	$("#taskmsg").hide();
        if(typeof not == 'undefined')
    	{
    	$("#nothingtask").show();
		$("#tablediv3").hide();
//		alert(taskno);
//		alert(taskno+" "+first);
		if(taskno==0 && first==0)
			{
		gettaskservice();
//		document.getElementById("c1").setAttribute("style", "width:70%");
//        document.getElementById("col2").setAttribute("style", "width:30%");
			}
		}
//        else
//        	{
//        	alertify.error('<b>Hi buddy, Special discount is waiting for you.<br><h5>Complete your tasks to grab the offer</h5></b>');
//        	}
//        else
//        	{
//        	$("#col2").show();
//       	 $("#myservices").show();
//       	 $("#strt").show();
//       	$("#dc").show(); 
////       	$("#taskyet").show();
//        	}
        });
//	if(cot)
//	 {
//		if(width>1000)
//		{
	 clearclass();
document.getElementById("msg").className="messages2 active in tab-pane";
document.getElementById("tk").className="active";
//		}
//	 }
}
var docid,docname;
$(document).ready(function() {
	 $("#tablediv4").hide();
	  $("#nothing2").hide();
	  $("#addsuccess").hide();
	 var not;
	     $("#showSp").click(function(event){
	    	 location.hash="#appointments";
	  });      
	});

function showappointment()
{
	 resetservicedisplay();
	 patid=getCookie("patid");
	 $("#nothing2").hide();
       $.get('rest/appointment/'+patid,function(responseJson) {
        if(responseJson!=null){
            $("#sptable").find("tr:gt(0)").remove();
            var table1 = $("#sptable");
            $.each(responseJson, function(key,value) { 
            	not=value.appointId;
            	docid=value.docId;
                 var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td></tr>");
//rowNew.children().eq(0).text(value['appointId']);
//rowNew.children().eq(1).text(value['patId']);
//rowNew.children().eq(0).text(value['docId']);
                 	rowNew.children().eq(0).text(value['docName']);
                    rowNew.children().eq(1).text(value['appointDersc']);
                    rowNew.children().eq(2).text(value['appointTimming']); 
                    rowNew.children().eq(3).text(value['appointDate']); 
                    rowNew.children().eq(4).text(value['appointStatus']);
                    rowNew.append("<td><input type='button' value='Remove' id='drod' width='100%' onclick='deleteappointment("+value.appointId+")'>");
                    rowNew.appendTo(table1);
                    $("#tablediv4").show();          
            });
            }
        
        if(typeof not == 'undefined')
    	{
    	$("#nothing2").show();
		$("#tablediv4").hide();
		}
        });
}
function deleteappointment(appoid)
{
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/patient/deleteappointment/'+appoid;
	SendAsync_GETRequest(xmlHttp,req_url,null,conformdelete);
}

function conformdelete()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	// Json response
		if(json_resp!=null)
			{
			alertify.error("<h3>Deleted the Appointment</h3>");
			getappoints();
			}
		else
			{
			alertify.alert("<h3>Wrong Operation</h3>");
			}
	}
}

function getappoints()
{
	resetservicedisplay();
	$.get('rest/appointment/'+patid,function(responseJson) {
//		location.hash="#appointments";
        if(responseJson!=null){
            $("#sptable").find("tr:gt(0)").remove();
            var table1 = $("#sptable");
            $.each(responseJson, function(key,value) { 
            	not=value.appointId;
            	docid=value.docId;
                 var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td></tr>");
// rowNew.children().eq(0).text(value['appointId']);
// rowNew.children().eq(1).text(value['patId']);
// rowNew.children().eq(0).text(value['docId']);
                 	rowNew.children().eq(0).text(value['docName']);
                    rowNew.children().eq(1).text(value['appointDersc']);
                    rowNew.children().eq(2).text(value['appointTimming']); 
                    rowNew.children().eq(3).text(value['appointDate']); 
                    rowNew.children().eq(4).text(value['appointStatus']);
                    rowNew.append("<td><input type='button' value='Remove' id='drod' width='100%' onclick='deleteappointment("+value.appointId+")'>");
                    rowNew.appendTo(table1);
                    $("#tablediv4").show();
                    $("#nothing").hide();
            });
            }
        $("#addsuccess").hide();
        if(typeof not == 'undefined')
    	{
    	$("#nothing2").show();
		$("#tablediv4").hide();
		}
        });
//	if(cot)
//	 {
//		if(width>1000)
//		{
//	document.getElementById("c1").setAttribute("style", "width:100%");
//    document.getElementById("col2").setAttribute("style", "width:30%");
	 clearclass();
document.getElementById("stt").className="settings2 active in  tab-pane";
document.getElementById("at").className="active";
//		}
//	 }
}
function SendAsync_GETRequest(post_xmlHttp, post_url, post_params, resFunction)
{
  try
  {
      post_xmlHttp.onreadystatechange = resFunction;
     // post_url = post_url.replace(/\|/g, "%7C");
      post_xmlHttp.open("GET",post_url,true);
      post_xmlHttp.setRequestHeader("Content-type", "application/json");
      // post_xmlHttp.setRequestHeader("Content-length", post_params.length);
      // post_xmlHttp.setRequestHeader("Connection", "close");
      post_xmlHttp.send();
  }
  catch(e)
  {
	  alertify.alert('<h4>Server is not Responding... some Problem in server</h4>');
  }
}
var patdisease,sts;
$(document).ready(function(){
	 $("#tablediv5").hide();
	 $("#nothing3").hide();
	 var not,ct=0;
     $("#showPR").click(function(event){
//   	 getpr();
    	 location.href="#healthrecord";
  });    
});

// $(document).ready(function(){
// if(Histroy.back())
// {
// Histroy.replaceState({fit:1,rand:Math.random()},"Fit","/Fit");
// }
// });

function getonlypr()
{
	resetservicedisplay();
	 patid=getCookie("patid");
	 // ct++;
       $.get('rest/patient/patientrecord/'+patid,function(responseJson) {
// location.hash="#healthrecord";
        if(responseJson!=null){
            $("#prtable").find("tr:gt(0)").remove();
            var table1 = $("#prtable");
            $.each(responseJson, function(key,value) { 
            	not = value.pr_id;
            	//sts=value.status;
            	patdisease=value.disease;
                 var rowNew = $("<tr><td></td><td></td><td></td><td></td></tr>");
                 	rowNew.children().eq(0).text(value['docName']);
                    rowNew.children().eq(1).text(value['symtoms']);
                    rowNew.children().eq(2).text(value['disease']); 
                    rowNew.children().eq(3).text(value['status']); 
                    rowNew.appendTo(table1);
            });
            }
        $("#tablediv5").show();
        if(typeof not == 'undefined')
    	{
        $("#col2").hide();
    	$("#nothing3").show();
		$("#tablediv5").hide();
		}
        });
  	clearclass();
   document.getElementById("ab").className="abcd3 active in tab-pane";
   document.getElementById("hhr").className="active";
}
var ct=1,none=0;
function getpr()
{
	 resetservicedisplay();
// $("#orderform").hide();
	 patid=getCookie("patid");
	 // ct++;
       $.get('rest/patient/patientrecord/'+patid,function(responseJson) {
// location.hash="#healthrecord";
        if(responseJson!=null){
            $("#prtable").find("tr:gt(0)").remove();
            var table1 = $("#prtable");
            $.each(responseJson, function(key,value) { 
            	not = value.pr_id;
            	sts=value.status;
            	patdisease=value.disease;
                 var rowNew = $("<tr><td></td><td></td><td></td><td></td></tr>");
                 	rowNew.children().eq(0).text(value['docName']);
                    rowNew.children().eq(1).text(value['symtoms']);
                    rowNew.children().eq(2).text(value['disease']); 
                    rowNew.children().eq(3).text(value['status']); 
                    rowNew.appendTo(table1);
            });
            }
        $("#tablediv5").show();
        if(typeof not == 'undefined')
    	{
        $("#col2").hide();
    	$("#nothing3").show();
		$("#tablediv5").hide();
		}
        else 
        	{
//        	document.getElementById("c1").setAttribute("style", "width:70%");
//            document.getElementById("col2").setAttribute("style", "width:30%");
//            if(none!=0)
//            	{
//            		none=1;
//       	 			getfitserviceattri(ct);
        	getsubscribedservice();
        	getunsubscribedservice();
//						if (none > 0) {
//								getonlyyoga();
//							}
//// }
//            none++;
        	}
        });
//       if(cot)
//  	 {
//    	 if(width>1000)
//   		{
  	clearclass();
   document.getElementById("ab").className="abcd3 active in tab-pane";
   document.getElementById("hhr").className="active";
//   		}
//  	 }
//   if(onlyone==0)
//		 {
//		 onlyone=1;
//		 getfitserviceattri(0);
//		 }
}
function getonlyyoga()
{
//	alert("inside only yoga"+servicetosubscribe+" "+checkyoga);
	if(servicetosubscribe==0 && checkyoga!='Yoga')
	{
//		alert("insider condition");
		 $.get('rest/patient/getserviceattrionly/Fitness/',function(responseJson) {
				iservice="Fitness";
				var atrr;
		        if(responseJson!=null){
		        	$("#hlist").empty();
		            var table1 = $("#hlist"); // get the div where
												// to display
		            var dispattri=$("<div></div>");
//		            var atvalue="";
		            dispattri.append("<h2>Click to Subcribe</h2><hr>");
		            $.each(responseJson, function(key,value) {
		            	var subsattri=value.atrri_type;
		                 	subcribed=subsattri;
//		                 	 if(checkyoga=='Yoga' && subcribed=='Yoga')
//		                 		{
//		                 		 alert(subcribed);
		                 		 if(subcribed=='Yoga')
		                 		{
		                 		surl=value.sp_url;
//		                 		alert(surl);
			                	dispattri.append("<div><input type=\"button\" value=\""+value.atrri_type+"\" id='fit"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></div><hr />"); // .fit"+inx+"
			                    dispattri.appendTo(table1);
//document.getElementById("hlist").innerHTML="<div><input type=\"button\"
//value=\""+value.sp_atrri+"\" id='fit"+inx+"' width='100%'
//onclick=\"getserviceurl(this.value)\" /></a></div><hr />";
			                    inx+=1;
			                    $("#col2").show();
			                    $("#myservices").show();
			            		$("#strt").show();
			                    $("#hlist").show(); // get the div
													// where to
													// display
													// attributes
			                    $("#hs").show();
			                    checkyoga='Yoga';
			                }
});
}
});
	}
}
function getsubscribedservice()
{
	$.get('rest/patient/getserviceattri/Fitness/'+patid,function(responseJson) {
		iservice="Fitness";
		var atrr;
        if(responseJson!=null){
        	$("#hlist").empty();
            var table1 = $("#hlist"); // get the div where to display
            var dispattri=$("<div></div>");
            var atvalue="";
            dispattri.append("<h2>Click to Subcribe</h2><hr>");
            $.each(responseJson, function(key,value) {
//            	alert(patdisease+" "+value.sp_atrri);
            	var subsattri=value.atrri_type;
            	 if(subsattri!=null && value.sp_url!=null)
                 {
                 	subcribed=subsattri;
                 	surl=value.sp_url;
//                 	alert(surl+" "+subcribed);
                 	inx++;
//                 	if(subcribed=='Yoga')
//                 	{
//                 	checkyoga='Yoga';
//                 	}
                 	displayfitservice(surl,subcribed);
                 }
//            	 else if((patdisease=='heart ' && value.sp_atrri=='music') || (patdisease=='diabetic' && value.sp_atrri=='excersice ') || (patdisease=='malaria' && value.sp_atrri=='Diet Service') ||  (patdisease=='diarrhea' && value.sp_atrri=='Diet Service') || (patdisease=='malaria' && value.sp_atrri=='Fitness tips')) //((patdisease=='Anemia' || patdisease=='jaundice' || patdisease=='diarrhea') && value.sp_atrri=='Yoga') || ((patdisease=='heart ' || patdisease=='diabeties') && value.sp_atrri=='Yoga') 
//	            {
//	            	atvalue=value.sp_atrri;
////	                	alert("inside for"+atvalue);
//	            	if(atvalue!=null)
//	            	{
//	            		none=0;
//	                	dispattri.append("<div><input type=\"button\" value=\""+value.sp_atrri+"\" id='fit"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></a></div><hr />"); // .fit"+inx+"
//	                    dispattri.appendTo(table1);
////	            		document.getElementById("hlist").innerHTML="<div><input type=\"button\" value=\""+value.sp_atrri+"\" id='fit"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></a></div><hr />";
//	                    inx+=1;
//	                    $("#col2").show();
//	                    $("#myservices").show();
//	            		$("#strt").show();
//	                    $("#hlist").show(); // get the div where to display attributes
//	                    $("#hs").show();
//	                    checkyoga='Fitness';
//	                	if(value.sp_atrri=='Diet Service')
//	            		{
//	            		dsurl=value.sp_url;
////	            		alert(dsurl);
//	            		}
//	                }
//	            }
            });
        }
	});
}
var servicetosubscribe=0;
function getunsubscribedservice()
{
	$.get('rest/patient/getserviceattrionly/Fitness/',function(responseJson) {
		iservice="Fitness";
		var atrr;
        if(responseJson!=null){
        	$("#hlist").empty();
            var table1 = $("#hlist"); // get the div where
										// to display
            var dispattri=$("<div></div>");
            var atvalue="";
            dispattri.append("<h2>Click to Subcribe</h2><hr>");
            $.each(responseJson, function(key,value) {
//alert(patdisease+" "+value.sp_atrri);
            	var subsattri=value.atrri_type;
                 	subcribed=subsattri;
                 	 if((patdisease=='heart ' && value.atrri_type=='music') || (patdisease=='diabetic' && value.atrri_type=='excersice ') || (patdisease=='malaria' && value.atrri_type=='Diet Service') ||  (patdisease=='diarrhea' && value.atrri_type=='Diet Service') || (patdisease=='malaria' && value.atrri_type=='Fitness tips') || (patdisease=='cold' && value.atrri_type=='Diet Service') || (patdisease=='fever' && value.atrri_type=='Yoga')) //((patdisease=='Anemia' || patdisease=='jaundice' || patdisease=='diarrhea') && value.sp_atrri=='Yoga') || ((patdisease=='heart ' || patdisease=='diabeties') && value.sp_atrri=='Yoga') 
     	            {
     	            	atvalue=value.atrri_type;
//     	                	alert("inside for"+atvalue);
     	            	if(atvalue!=null)
     	            	{
     	                	dispattri.append("<div><input type=\"button\" value=\""+value.atrri_type+"\" id='fit"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></div><hr />"); // .fit"+inx+"
     	                    dispattri.appendTo(table1);
//     	            		document.getElementById("hlist").innerHTML="<div><input type=\"button\" value=\""+value.sp_atrri+"\" id='fit"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></a></div><hr />";
     	                    inx+=1;
     	                    $("#col2").show();
     	                    $("#myservices").show();
     	            		$("#strt").show();
     	                    $("#hlist").show(); // get the div where to display attributes
     	                    $("#hs").show();
//     	                    checkyoga='Fitness';
     	                   if(subcribed=='Yoga')
                    		{
                    		checkyoga='Yoga';
                    		}
     	                    servicetosubscribe=1;
     	                }
     	            }
//                 	 if(subcribed=='Yoga')
//                 		{
//                 		surl=value.sp_url;
//	                	dispattri.append("<div><input type=\"button\" value=\""+value.atrri_type+"\" id='fit"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></a></div><hr />"); // .fit"+inx+"
//	                    dispattri.appendTo(table1);
////document.getElementById("hlist").innerHTML="<div><input type=\"button\"
////value=\""+value.sp_atrri+"\" id='fit"+inx+"' width='100%'
////onclick=\"getserviceurl(this.value)\" /></a></div><hr />";
//	                    inx+=1;
//	                    $("#col2").show();
//	                    $("#myservices").show();
//	            		$("#strt").show();
//	                    $("#hlist").show(); // get the div
//											// where to
//											// display
//											// attributes
//	                    $("#hs").show();
//	                    checkyoga='Yoga';
//	                }
});
}
});
}
function getfitnessservice()
{
	// getfitserviceattri();
	location.hash="#fitservice";
	if(sts=='Critical' || sts=='Normal' || sts=='First Stage' || sts=='2nd stage' && aservice!="yoga")
	{
	// getserviceurl("Fitness tips");
	myAgeValidation();
	resetservicedisplay();
    $("#col2").show();
    $("#myservices").show();
		loc=serviceipaddr+"/abc.html?patid="+patid+"&patage="+age+"&patdisease="+patdisease+"&patname="+patname; // service
		NoServices(loc,function(status){
			if((status == 200)){// dynamiciframe!= null
				$('#dynamiciframe').attr('src', loc);
// alert("opening iframe");
				$("#strt").show();
				$("iframe").show();
			}
			else if(status == 404 || status == 503){  
// alert("i am here");
				$("#noservice").show();
			}
		});
		}
	else if(aservice=="yoga")
		{
		myAgeValidation();
		resetservicedisplay();
	    $("#col2").show();
	    $("#myservices").show();
		//get yoga tips.. get with yoga id...send patient age , disease and name...
		}
	else
		{
		// patdisease=value.disease;
		// getserviceurl("Fitness tips");
// alert("i am in else");
		resetservicedisplay();
    	myAgeValidation();
        $("#col2").show();
        $("#myservices").show();
    		loc=serviceipaddr+"/abc.html?patage="+age+"&patdisease="+patdisease;
    		NoServices(loc,function(status){
    			if(status == 200){
    				$('#dynamiciframe').attr('src', loc);	
                    $("iframe").show();
    			}
    			else if(status == 404 || status == 503 ){
                    $("#strt").show();
    				$("#noservice").show();
    			}
    		});
		}
}

$(document).ready(function(){
	$("#showAP").click(function(event){
		resetservicedisplay();
		location.hash="#af";
	});
});

$(document).ready(function(){
	$("#showDR").click(function(event){
		//resetservicedisplay();
		location.hash="#sd";
	});
});
var spname;
$(document).ready(function(){
	 $("#tablediv6").hide();
	 $("#nothing4").hide();
// $("#orderform").hide();
	 var nots;
    $("#showOR").click(function(event){
    	location.hash="#orders";
    	
// alert("inside order table");
//    	resetservicedisplay();
//    	$("#col2").show();
//    	$("#myservices").show();
//   	 patid=getCookie("patid");
//   	 // ToDo:we need to change to service url dyanmically to get all orders
//		// of the patient with differnt service provider....
//   	 $("iframe").hide();
//   	$("#strt").show();
//   	 $("#om").show();
//   	 $("#orderform").show();
//// $("#orderform").show();
//   	$.get("rest/patient/getallspurl",function(rJson) {
//   		
//   		$.each(rJson, function(key,value) {
//   			spname=value.spName;
//   		 ipaddr=value.spUrl;
//   		 alert(ipaddr);
//           $.get(ipaddr+"/rest/medicationservice/orderedlist/"+patname,function(responseJson) {
//        	   location.hash="#orders";
//           if(responseJson!=null){
//               $("#ordertable").find("tr:gt(0)").remove();
//               var table1 = $("#ordertable");
//               $.each(responseJson, function(key,value) { 
//            	   nots = value.o_id;
//                    var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
//                       rowNew.children().eq(0).text(value['o_id']); 
//                       rowNew.children().eq(1).text(value['pat_name']);
//                       rowNew.children().eq(2).text(value['med_name']);
//                       rowNew.children().eq(3).text(value['med_dosage']);
//                       rowNew.children().eq(4).text(value['med_quantity']); 
//                       rowNew.children().eq(5).text(value['med_price']); 
//                       rowNew.children().eq(6).text(value['status']); 
//                       rowNem.children().eq(7).text(spname);
//                       rowNew.appendTo(table1);
//                       $("#tablediv6").show();
//               });
//               }
//           if(typeof nots == 'undefined')
//       		{
//        	   $("#nothing4").show();
//        	   $("#tablediv6").hide();
//       		}
//           });
//   	 });
//   	});
 });    
});


function getorders()
{
	$("#nothing4").hide();
	//location.hash="#orders";
	// alert("inside order table");
	    	resetservicedisplay();
//	    	$("#col2").show();
//	    	$("#myservices").show();
	   	 patid=getCookie("patid");
	   	 // ToDo:we need to change to service url dyanmically to get all orders
			// of the patient with differnt service provider....
	   	 $("iframe").hide();
//	   	$("#strt").show();
//	   	 $("#om").show();
//	   	 $("#orderform").show();
         $("#ordertable").find("tr:gt(0)").remove();
	   	$.get("rest/patient/getallspurl",function(rJson) {
	   		$.each(rJson, function(key,value) {
	   			spname=value.spName;
	   		 ipaddr=value.spUrl;
//	   		alert(ipaddr+" "+value.spAttri);
	   		 if(value.spAttri=="Medication Supplier") //|| value.spAttri=="Arurvadic Medication Supplier" || value.spAttri=="Arurvadic and Medication Supplier")
	   		{
//	   			 alert(ipaddr);
	   		getsporders(ipaddr,spname);
	   		iframeipaddr=ipaddr;
	   		}
	   	 });
	   	});
//	   	if(cot)
//		 {
//	   		if(width>1000)
//			{
//	   	document.getElementById("c1").setAttribute("style", "width:70%");
//        document.getElementById("col2").setAttribute("style", "width:30%");
		 clearclass();
	 document.getElementById("abc").className="abcd2 active in tab-pane";
	 document.getElementById("ool").className="active";
//			}
//		 }
}

function getsporders(spip,spname)
{
//	alert(spip);
	  $.get(spip+"/rest/medicationservice/orderedlist/"+patname,function(responseJson) {
   	   //location.hash="#orders";
      if(responseJson!=null){
          var table1 = $("#ordertable");
          $.each(responseJson, function(key,value) { 
       	   nots = value.o_id;
//       	alert(nots);
               var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
                  rowNew.children().eq(0).text(value['o_id']); 
                  rowNew.children().eq(1).text(value['pat_name']);
                  rowNew.children().eq(2).text(value['med_name']);
                  rowNew.children().eq(3).text(value['med_dosage']);
                  rowNew.children().eq(4).text(value['med_quantity']); 
                  rowNew.children().eq(5).text(value['med_price']); 
                  rowNew.children().eq(6).text(value['status']); 
                  rowNew.children().eq(7).text(spname);
                  rowNew.appendTo(table1);
                  $("#tablediv6").show();
          });
          }
      if(typeof nots == 'undefined')
  		{
   	   $("#nothing4").show();
   	   $("#tablediv6").hide();
   	   resetservicedisplay();
  		}
//      else
//    	  {
//    	  }
      });
}
function checkloc(patid,medname){
	xmlHttp = GetXmlHttpObject();
	var req_url = serviceipaddr+"/rest/medicationservice/checkreqmedicine/"+patid+"/"+medname;
	// var params = result;
	SendAsync_GetRequest(xmlHttp, req_url,null,check_resp);
}

function check_resp() {
	var loc=null;
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText; // Json response
			if (json_resp=='0') {
				loc = serviceipaddr+"/rest/medicationservice/imd/"+ medNam + "/" + medDosag;
				location.hash="#immediateservice";
				NoServices(loc,function(status){
        			if(status == 200){
        				$('#dynamiciframe').attr('src', loc);		
        			}
        			else if(status == 404  || status == 503){
// alertify.alert('<h1>Sorry, Service is not available for this profile</h1>');
        				$("#noservice").show();
// $("#strt").hide();
        			}
        		});
			} else {
				loc = serviceipaddr+"";
				NoServices(loc,function(status){
        			if(status == 200){
        				$('#dynamiciframe').attr('src', loc);		
        			}
        			else if(status == 404 || status == 503){ 
// alertify.alert('<h1>Sorry, Service is not available for this profile</h1>');
        				$("#noservice").show();
// $("#strt").hide();
        			}
        		});


			}
	}
	else
		{
		getPharmaService();
		}
// $('#dynamiciframe').attr('src', loc);
}

function SendAsync_GetRequest(post_xmlHttp, post_url, post_params, resFunction) {
	try {
		post_xmlHttp.onreadystatechange = resFunction;
		// post_url = post_url.replace(/\|/g, "%7C");
		post_xmlHttp.open("GET", post_url, true);
		post_xmlHttp.setRequestHeader("Content-type", "application/json");
		// post_xmlHttp.setRequestHeader("Content-length", post_params.length);
		// post_xmlHttp.setRequestHeader("Connection", "close");
		post_xmlHttp.send();
	} catch (e) {
		alertify.alert('<h3> Server is not Responding... some Problem in server</h3>');
	}
}

function chide()
{
	$("#tablediv3").hide();
	$("#taskmsg").show();
}

function setCookie(cname,cvalue,exdays)
{
	// deleteAllCookies();
var d = new Date();
d.setTime(d.getTime()+(exdays*24*60*60*1000));
var expires = "expires="+d.toGMTString();
document.cookie = cname + "=" + cvalue + "; " + expires;
}


$(document).ready(function(){
	resetservicedisplay();
	 $("#docname").show();
	 $("#deptdiv").hide();
	 $("#tablediv7").hide();
	 $("#docname").hide();
	 $("#noth").hide();
	 $("#appform").hide();
	 $("#showDR").click(function(event){
	
});
});


function searchdoc()
{
	//location.hash="#sd";
	resetservicedisplay();
	$("#searchdiv").show();
	$("#tablediv7").hide();
	$("#deptdiv").hide();
		 // $("#docser").show();
	$("#noth").hide();
	$("#btnname").show();
	$("#hidespec").show();
//	if(cot)
//	 {
//		if(width>1000)
//		{
//	document.getElementById("c1").setAttribute("style", "width:100%");
//    document.getElementById("col2").setAttribute("style", "width:30%");
		clearclass();
document.getElementById("docser").className="abcd1 active in tab-pane";
document.getElementById("ssd").className="active";
//		}
//	 }
}
$(document).ready(function(){
	 $("#showAP").click(function(event){
//		 aform();
		 location.hash="#af";
});
});

function aform()
{
	resetservicedisplay();
//	 location.hash="#appointments";
$("#appointdiv8").show();
//getpatnam(patid);
//repeat();
//document.getElementById("c1").setAttribute("style", "width:100%");
//document.getElementById("col2").setAttribute("style", "width:30%");
clearclass();
document.getElementById("abcd").className="abcd0 active in tab-pane";
document.getElementById("aaf").className="active";
document.form1.patId.value=patname;
}
function showappoint(ddname,dddid)
{
	mydid=dddid;
	$("#searchdiv").hide();
	$("#appform").show();
// $("#appbtn").hide();
	// $("#sptable").show();
	// $("#appointdiv8").show();
	// $("#docser").hide();
	document.form2.patId.value=patname;
	document.form2.docId.value=ddname;
}
// $(document).ready(function(){
// $("#appoint").onclick(function(event){
// $("#sptable").show();
// $("#appointdiv8").hide();
// $("#searchdiv").hide();
// document.form1.patId.value=pid;
// document.form1.docId.value=docid;
// });
// });
// var docid;
// function shows()
// {
// $("#spec").show();
// $("#docname").hide();
// $("#dept").hide();
// }
//
// function showd()
// {
// $("#dept").show();
// $("#docname").hide();
// $("#spec").hide();
// }
// function test11()
// {
// var search=document.formss.dname.value;
// test1(search);
// }

var mydid;

function test12(spec,dept)
{
	if(spec==null || spec=='')
	{
	alertify.alert("<h3>please specify one of the specilization values</h3>");
	return false;
	}
	else if(dept==null || dept=='')
		{
		alertify.alert("<h3>please specify one of the department values</h3>");
		return false;
		}
	else
	{
		var not;
	$.get('rest/patient/searchdocs/'+spec+'/'+dept,function(responseJson) {
		location.hash="#searchdoctor";
        if(responseJson!=null){
            $("#searchtable").find("tr:gt(0)").remove();
            var table1 = $("#searchtable");
            $.each(responseJson, function(key,value) { 
            	var dname1,ddid;
            	not =value.doc_id;
                 var rowNew = $("<tr><td></td><td></td></tr>");
                mydid=value.doc_id;
                docname=value.doc_name;
                dname1=docname;
                ddid=mydid;
//                alert(ddid);
                    rowNew.children().eq(0).text(value['doc_id']); 
                    rowNew.children().eq(1).text(value['doc_name']);
                    rowNew.append("<input type='button' value='Apply' width='100%' onclick=\"showappoint('"+dname1+"','"+ddid+"')\">");
                    rowNew.appendTo(table1);
                    $("#tablediv7").show();
                    $("#searchdiv").show();
//                    alert("showing result");
// $("#appform").show();
                    $("#noth").hide();
            });
            }
        if(typeof not == 'undefined')
        	{
        	$("#noth").show();
        	$("#tablediv7").hide();
        	$("#hidespec").show();
        	$("#deptdiv").hide();
        	$("#searchdiv").hide();
// $("#hidespec").hide();
        	}
        });
	}
//	if(cot)
//	 {
//		if(width>1000)
//		{
//		clearclass();
//document.getElementById("abcd").className="abcd0 active in tab-pane";
//document.getElementById("aaf").className="active";
//		}
//	 }
}
var inspecdept=0;
function test01(search)
{
// $("#deptdiv").show();
	if(search==null || search=='')
		{
		alertify.alert("<h3>please specify one of the specialization values</h3>");
		return false;
		}
	else
		{
		inspecdept=1;
		var not;
	$.get('rest/patient/doctorsearch/'+search,function(responseJson) {
//		location.hash="#searchdoctor";
        if(responseJson!=null){
            $("#searchtable").find("tr:gt(0)").remove();
            var table1 = $("#searchtable");
            $.each(responseJson, function(key,value) { 
            	not =value.doc_id;
                 var rowNew = $("<tr><td></td><td></td></tr>");
                mydid=value.doc_id;
                docname=value.doc_name;
                var ddid=mydid;
                var dname1=docname;
                    rowNew.children().eq(0).text(value['doc_id']); 
                    rowNew.children().eq(1).text(value['doc_name']);
                    rowNew.append("<input type='button' value='Apply' width='100%' onclick=\"showappoint('"+dname1+"','"+ddid+"')\">");
                    rowNew.appendTo(table1);
            });
            }
        $("#tablediv7").show();
        $("#searchdiv").show();
        $("#hidespec").hide();
        document.getElementById("ddid").value="";
        $("#appform").hide();
        $("#deptdiv").show();
        $("#btnname").hide();
//$("#appbtn").show();
        $("#noth").hide();
        if(typeof not == 'undefined')
        	{
        	$("#noth").show();
        	$("#tablediv7").hide();
        	$("#hidespec").show();
        	$("#deptdiv").hide();
        	$("#searchdiv").show();
// $("#hidespec").hide();
        	}
        
        });
// if(docid==null)
// {
// alert("Sorry,No Such Specilization");
// return false;
// }
		}
        return true;
}
function test1(search)
{
	// var search=document.getElementById("spec").value;
// $("#deptdiv").show();
	if(search==null || search=='')
		{
		alertify.alert("<h3>please specify Doctor Name</h3>");
		return false;
		}
	else
		{
		var not;
	$.get('rest/patient/doctorsearch/'+search,function(responseJson) {
		//location.hash="#searchdoctor";
        if(responseJson!=null){
            $("#searchtable").find("tr:gt(0)").remove();
            var table1 = $("#searchtable");
            $.each(responseJson, function(key,value) { 
            	not =value.doc_id;
                 var rowNew = $("<tr><td></td><td></td></tr>");
                mydid=value.doc_id;
                var ddid=mydid;
                docname=value.doc_name;
                var dname1=docname;
                    rowNew.children().eq(0).text(value['doc_id']); 
                    rowNew.children().eq(1).text(value['doc_name']);
                    rowNew.append("<input type='button' value='Apply' width='100%' onclick=\"showappoint('"+dname1+"','"+ddid+"')\">");
                    rowNew.appendTo(table1);
                    $("#tablediv7").show();
                    $("#searchdiv").hide();
                    $("#noth").hide();
            });
            }
        if(typeof not == 'undefined')
        	{
        	$("#tablediv7").hide();
        	$("#noth").show();
        	$("#hidespec").show();
        	$("#deptdiv").hide();
        	$("#searchdiv").hide();
// $("#hidespec").hide();
        	}
        
        });
		}
        return true;
}

function validatepatid()
{
	var num=document.form1.patId;
	if((num.value==null)||(num.value=="")){
		alertify.alert("<h3>Please Enter patient id</h3>");
		num.focus();
		return false;
	}
	return true;
}

function validatedocid()
{
	var num=document.form1.docId;
	if((num.value==null)||(num.value=="")){
		alertify.alert("<h3>Please Enter doctor Name</h3>");
		num.focus();
		return false;
	}
	
	return true;
}

function validatedersc()
{
	var name=document.form1.appointDersc;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter Appointment Description field</h3>");
		name.focus();
		return false;
	}
	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets with space allowed</h3>');
		name.focus;
		return false;
		}
	return true;
}

function validatetimming()
{
	var num=document.form1.appointTimming;
	if((num.value==null)||(num.value=="")){
		alertify.alert("<h3>Please Enter timming</h3>");
		num.focus();
		return false;
	}
// var filter=/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;
// if(!filter.test(num.value))
// {
// alertify.alert('Please provide 24 timming format-HH:MM');
// num.focus;
// return false;
// }
// return true;
	return true;
}

function validatedate()
{
	var dob=document.form1.appointDate;
	if((dob.value==null)||(dob.value==""))
	{
		alertify.alert("<h3>Please Enter date MM/DD/YY</h3>");
		dob.focus();
		return false;
	}
	return true;
}

function validatestatus()
{
	var name=document.form1.appointStatus;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter Status field</h3>");
		name.focus();
		return false;
	}
	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets with space allowed</h3>');
		name.focus;
		return false;
		}
	return true;
}
function validateall()
{
	var a=validatepatid();
	var b=validatedocid();
	var c=validatedersc();
	var d=validatetimming();
	var e=validatedate();
	// var f=validatestatus();
	if(a==true && b==true && c==true && d==true && e==true)
		{
		appointcall();
		}
	else
		{
		alertify.alert("<h3>all the fields are compulsory</h3>");
		return false;
		}
	return true;
}

function appointcall1()
{
	document.getElementById("ppid").value=patid;
	document.getElementById("ddid").value=mydid;
	var formData = form2object('ff', '.', true, function(node) {
		if (node.id && node.id.match(/zzz/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	var json = JSON.stringify(formData, null, '\t');
// alert(json);
	result = json;
	registerappoint();
}
// var did;
function appointcall()
{
	document.getElementById("patid1").value=pid;
	var dname=document.getElementById("docid1").value;
	mydocids(dname);
	
}
function sendjson()
{
	var formData = form2object('f', '.', true, function(node) {
		if (node.id && node.id.match(/qqq/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	var json = JSON.stringify(formData, null, '\t');
// alert(json);
	result = json;
	registerappoint();
} 
function registerappoint()
{
	xmlHttp = GetXmlHttpObject();
	var req_url = 'rest/patient/appointinsert';
	var params = result;
	SendAsync_PostRequest(xmlHttp, req_url, params, registration_resp);
}

function mydocids(dname)
{
	xmlHttp = GetXmlHttpObject();
	var req_url = 'rest/patient/docid/'+dname;
	SendAsync_GetRequest(xmlHttp, req_url, null, myres);
}
var xmlHttp;
function myres()
{
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText;
// did=json_resp;
// alert(json_resp);
// document.form1.docId.value=json_resp;
		document.getElementById("docid1").value=json_resp;
		sendjson();
	}
}

function registration_resp() {
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText; // Json response
		if (json_resp != null) {
			alertify.success("<h4>Appointment Added Successfully<br>Check Appointment List for Doctor Conformation</h4>");
//			window.open(myipaddr+"dowload.html");
//			$("#srh").show();
//			$("#btnname").show();
			window.open("dowload.html");
			if(document.form1.patId.value!='')
				{
				document.form1.patId.value='';
				document.form1.docId.value='';
				document.form1.appointDersc.value='';
				document.form1.appointDate.value='';
				document.form1.appointTimming.value='';
				document.form1.appointStatus.value='';
				document.form2.patId.value='';
				document.form2.docId.value='';
				document.form2.appointDersc.value='';
				document.form2.appointDate.value='';
				document.form2.appointTimming.value='';
				document.form2.appointStatus.value='';
				resetservicedisplay();
				$("#searchtable").empty();
				$("#tablediv7").hide();
				$("#appform").hide();
				searchdoc();
				}
		}
	}
}


function SendAsync_PostRequest(post_xmlHttp, post_url, post_params, resFunction) {
	try {
		post_xmlHttp.onreadystatechange = resFunction;
		// post_url = post_url.replace(/\|/g, "%7C");
		post_xmlHttp.open("POST", post_url, true);
		post_xmlHttp.setRequestHeader("Content-type", "application/json");
		// post_xmlHttp.setRequestHeader("Content-length", post_params.length);
		// post_xmlHttp.setRequestHeader("Connection", "close");
		post_xmlHttp.send(post_params);
	} catch (e) {
		alertify.alert('<h3>Server is not Responding... some Problem in server</h3>');
	}
}
function SendAsync_GetRequest(post_xmlHttp, post_url, post_params, resFunction) {
	try {
		post_xmlHttp.onreadystatechange = resFunction;
		// post_url = post_url.replace(/\|/g, "%7C");
		post_xmlHttp.open("GET", post_url, true);
		post_xmlHttp.setRequestHeader("Content-type", "application/json");
		// post_xmlHttp.setRequestHeader("Content-length", post_params.length);
		// post_xmlHttp.setRequestHeader("Connection", "close");
		post_xmlHttp.send();
	} catch (e) {
		alertify.alert('<h3>Server is not Responding... some Problem in server</h3>');
	}
}

function GetXmlHttpObject() {

	var xmlHttp = null;
	try {
		// Firefox, Opera 8.0+, Safari
		xmlHttp = new XMLHttpRequest();

	} catch (e) {
		// Internet Explorer
		try {
			xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}

	return xmlHttp;
}
function NoServices(url,cb)
{
	jQuery.ajax({
	url: url,
	datatype: 'text',
	type: 'GET',
	complete: function(xhr){
		if(typeof cb == 'function')
			cb.apply(this,[xhr.status]);
	}
	
	});
}	

function myAgeValidation() {
	 
    var lre = /^\s*/;
    var datemsg = "";
//    alert(patdob);
    var inputDate = patdob;
    inputDate = inputDate.replace(lre, "");
// document.as400samplecode.myDate.value = inputDate;
    datemsg = isValidDate(inputDate);
        if (datemsg != "") {
//            alertify.alert(datemsg);
        }
        else {
            // Now find the Age based on the Birth Date
// alert(inputDate);
            getAge(new Date(inputDate));
        }
}
 var age;
function getAge(birth) {
 
    var today = new Date();
    var nowyear = today.getFullYear();
    var nowmonth = today.getMonth();
    var nowday = today.getDate();
 
    var birthyear = birth.getFullYear();
    var birthmonth = birth.getMonth();
    var birthday = birth.getDate();
 
    age = nowyear - birthyear;
    var age_month = nowmonth - birthmonth;
    var age_day = nowday - birthday;
    
    if(age_month < 0 || (age_month == 0 && age_day <0)) {
            age = parseInt(age) -1;
        }
// alert(age);
    
// if ((age == 18 && age_month <= 0 && age_day <=0) || age < 18) {
// }
// else {
// alert("You have crossed your 18th birthday !");
// }
}
 
function isValidDate(dateStr) {
 
    
    var msg = "";
    // Checks for the following valid date formats:
    // MM/DD/YY MM/DD/YYYY MM-DD-YY MM-DD-YYYY
    // Also separates date into month, day, and year variables
 
    // To require a 2 & 4 digit year entry, use this line instead:
    // var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{2}|\d{4})$/;
    // To require a 4 digit year entry, use this line instead:
    var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{4})$/;
 
    var matchArray = dateStr.match(datePat); // is the format ok?
    if (matchArray == null) {
        msg = "Date is not in a valid format.";
        return msg;
    }
 
    month = matchArray[1]; // parse date into variables
    day = matchArray[3];
    year = matchArray[4];
 
    
    if (month < 1 || month > 12) { // check month range
        msg = "Month must be between 1 and 12.";
        return msg;
    }
 
    if (day < 1 || day > 31) {
        msg = "Day must be between 1 and 31.";
        return msg;
    }
 
    if ((month==4 || month==6 || month==9 || month==11) && day==31) {
        msg = "Month "+month+" doesn't have 31 days!";
        return msg;
    }
 
    if (month == 2) { // check for february 29th
    var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
    if (day>29 || (day==29 && !isleap)) {
        msg = "February " + year + " doesn't have " + day + " days!";
        return msg;
    }
    }
 
    if (day.charAt(0) == '0') day= day.charAt(1);
    
    // Incase you need the value in CCYYMMDD format in your server program
    // msg = (parseInt(year,10) * 10000) + (parseInt(month,10) * 100) +
	// parseInt(day,10);
    return msg;  // date is valid
}

function form2valid()
{
	if(validateappoitment())
		{
	appointcall1();
		}
}

function validateappoitment()
{
//	var che=0;
	if(document.form2.appointDersc.value!='')
	{
		if(document.form2.appointTimming.value!='')
			{
			if(document.form2.appointDate.value!='')
				{
				return true;
				}
			else
				{
				alertify.alert("<h3>Please Enter Appointment Date</h3>");
				}
			}
		else
			{
			alertify.alert("<h3>Please Enter Appointment Time</h3>");
			}
	}
	else
		{
			alertify.alert("<h3>Please Enter Appointment Description</h3>");
		}
	return false;
}
function dispname(){
	$("#btnname").hide();
	$("#hidespec").hide();
	$("#deptdiv").hide();
	$("#docname").show();
	$("#tablediv7").hide();
}


var serviceip;

function getpharmaservices()
{
	$("#plist").hide();
	$("#hlist").hide();
	$("#dcdist").hide();
	$("#hs").hide();
//	$("#om").hide();
}

$(document).ready(function(){
$("#pdiv").click(function(event){
	serviceip=myipaddr+"getpharmaservice";
 $.get(serviceipaddr,function(responseJson) {
	 location.hash="#pharmaservice";
	 if(responseJson!=null)
	 {
		 $("#plist").find("tr:gt(0)").remove();
		 var table1 = $("#plist");
            $.each(responseJson, function(key,value) {
            	var oservice=$("");
            	oservice.append("<a href='#'>"+value.spAtrri+"</a>");
            	oservice.appendTo(table1);
            });
	 }
 });
 $("#plist").show();
});
});
function getfitservices()
{
	$("#plist").hide();
	$("#hlist").hide();
	$("#dcdist").hide();
	$("#ps").hide();
//	$("#om").hide();
	$("#dc").hide();
}

// $(document).ready(function(){
// // $("#jstorder").hide();
// $("#hdiv").click(function(event){
// serviceip=myipaddr+"rest/getserviceattri";
// $.get(serviceip,function(responseJson) {
// if(responseJson!=null)
// {
// $("#hlist").find("tr:gt(0)").remove();
// var table1 = $("#hlist");
// $.each(responseJson, function(key,value) {
// var oservice="<a href='#'>"+value.spAtrri+"</a>";
// oservice.appendTo(table1);
// });
// }
// $("#customo").hide();
// $("#om").hide();
// });
// $("#hlist").show();
// });
// });

function getdiscountcoupons()
{
	$("#plist").hide();
	$("#hlist").hide();
	$("#dclist").hide();
	$("#hlist").hide();
	$("#ps").hide();
//	$("#om").hide();
	$("#hs").hide();
}

// $(document).ready(function(){
//	
// // $("#jstorder").hide();
// $("#hdiv").click(function(event){
// serviceip=serviceipaddr+"/gethealthservice";
// $.get(serviceipaddr,function(responseJson) {
// if(responseJson!=null)
// {
// $("#dcdiv").find("tr:gt(0)").remove();
// var table1 = $("#dcdiv");
// $.each(responseJson, function(key,value) {
// var oservice="<a href='#'>"+value.spAtrri+"</a>";
// oservice.append(table1);
// });
// }
// });
// $("#hlist").show();
// });
// });

function submitdiscount()
{
	var mydiscount;
	var formd={};
	if($("#disdate").val()!='')
		{
		if($("#distime").val()!='')
		{
	formd["patid"]=patid;
	formd["discount_id"]=$('#discode').val();
	formd["offer"]=$('#discountcode').val();
	formd["values"]=$("#disdate").val();
	formd["status"]="granted";
	mydiscount = JSON.stringify(formd);
	setappointment();
		}
		else
			{
			alertify.alert("<h4>please select time of appointment</h4>");
			}
		}
	else
		{
		alertify.alert("<h4>Please select data of appointment</h4>");
		}
	// grantdiscount(mydiscount);
}

function grantdiscount(mydiscount)
{
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/patient/mydiscount';
	var params    = mydiscount;  
	$("#discountders").val('');
	$("#discountcode").val('');
	$("#disdate").val('');
	$("#distime").val('');
	resetservicedisplay();
	SendAsync_PostRequest(xmlHttp,req_url,params,conformdiscount);
}

function conformdiscount()
{
if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
	// var json_resp = xmlHttp.responseText; //Json response
	alertify.success("<h3>Discount Granted</h3>");
	
}
else
	{
	alertify.alert("<h3>Server Not Reachable or internal Server Error</h3>");
	}
}

function setappointment()
{
	// var mydiscount;
	var formd={};
	formd["patId"]=patid;
	formd["docId"]="111";
	formd["appointDersc"]=discountderc;
	formd["appointTimming"]=$("#distime").val();
	formd["appointDate"]=$("#disdate").val();
	formd["appointStatus"]="awaited";
	mydiscount = JSON.stringify(formd);
	result=mydiscount;
// alert(result);
	registerappoint();
}

// var noreqmedicines;
// function getmedicinesno(ptid,mn,md)
// {
// xmlHttp = GetXmlHttpObject();
// var req_url = 'rest/patient/gettotalmedicinesreq/'+ptid+'/'+mn+'/'+md;
// SendAsync_GetRequest(xmlHttp,req_url,null,setreqmedicines);
// }
//
// function setreqmedicines()
// {
// if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
// var json_resp = xmlHttp.responseText; // Json response
// if (json_resp != null) {
//			
// }
// }
// }

function gettotalmedicine(ptid,mn,md)
{
// alert(ptid+mn+md);
	xmlHttp  = GetXmlHttpObject();
// alert(mn+" "+md);
	var req_url = 'rest/patient/gettotalmedicines/'+ptid+'/'+mn+'/'+md;
	SendAsync_GetRequest(xmlHttp,req_url,null,settheshold);
}

function settheshold()
{
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
// alert("responce");
		// alert(xmlHttp.responseText);
		var json_resp = xmlHttp.responseText; // Json response
// alert("got responce"+json_resp);
		if (json_resp != null) {
			// theshold=json_resp;
			json_resp=json_resp-qty;
// alert(json_resp);
			document.getElementById("mqty").value=json_resp;
			gettprice();
			$("#myservices").show();
			$("#strt").show();
			$("#spserving").show();
		}
	}
	else
	{
		resetservicedisplay();
		
	}
// else
// {
// alertify.alert("<h3>Server Not Responding</h3>");
// }
}
// <div id="mapholder"></div> -- the cuurent location of urs ll display in this
// div...
// function gethospitals()
// {
// resetservicedisplay();
// $("col2").show();
// $("#demo").show();
// $("#mapholder").show();
// if (navigator.geolocation)
// {
// navigator.geolocation.watchPosition(showPosition);
// }
// else{
// alertify.alert("Geolocation is not supported by this browser.");
// }
//	
// }
// var x=document.getElementById("demo");
// var lat,log;
// function getLocation()
// {
// if (navigator.geolocation)
// {
// navigator.geolocation.getCurrentPosition(showPosition,showError);
// }
// else{x.innerHTML="Geolocation is not supported by this browser.";}
// }
//
// function showPosition(position)
// {
// var latlon=position.coords.latitude+","+position.coords.longitude;
// lat=position.coords.latitude;
// log=position.coords.longitude;
// // alert(latlon);
// var img_url="http://maps.googleapis.com/maps/api/staticmap?center="
// +latlon+"&zoom=14&size=400x300&sensor=false";
// document.getElementById("mapholder").innerHTML="<img src='"+img_url+"'>";
// $("#imdservice").hide();
// $("#mapholder").show();
// //create a service by geting the latitude and logitude of the patient to get
// immediate ambulance by admin profile granting the service on his profils tab
// immediate service(1st tab)....
// //setemergencycall();
// setemergency();
// }
//
// function showError(error)
// {
// switch(error.code)
// {
// case error.PERMISSION_DENIED:
// x.innerHTML="The request for Geolocation denied .";
// break;
// case error.POSITION_UNAVAILABLE:
// x.innerHTML="Location information is unavailable.";
// break;
// case error.TIMEOUT:
// x.innerHTML="The request to get user location timed out.";
// break;
// case error.UNKNOWN_ERROR:
// x.innerHTML="An unknown error occurred.";
// break;
// }
// }

	var time=100;
	function hideallservices()
	{
//		setInterval(function(){resetservicedisplay();},time);
//		time=50;
		resetservicedisplay();
	}
// $('#bdy').translate('en');
// var myem;
// function setemergencycall()
// {
// var formd={};
// formd["pat_id"]=patid;
// formd["pat_name"]=patname;
// formd["em_lat"]=lat;
// formd["em_log"]=log;
// myem = JSON.stringify(formd);
// result=myem;
// // alert(myem);
// setemergency();
// }
//	
// function setemergency()
// {
// xmlHttp = GetXmlHttpObject();
// var req_url = 'rest/admin/eminsert/'+patid+'/'+patname+'/'+lat+'/'+log+'/';
// //var params = result;
// SendAsync_GetRequest(xmlHttp, req_url, null, admin_conformation);
// }
//	
// function admin_conformation()
// {
// if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
// var json_resp = xmlHttp.responseText; // Json response
// // alert(json_resp);
// // if (json_resp != null) {
// alertify.alert("<h4>Dont Panic, <hr>Ambulance Coming At your Current
// Location</h4>");
// $("#col2").show();
// $("#myservices").show();
// $("#mapholder").show();
//				
// // }
// }
// // }
// // else
// // {
// // alertify.alert("<h3>Server not Responding");
// // }
// }
//
	
//(function($) 
//{
//	var restfulApp=Backbone.Controller.extend({
//		restfulUrl:"http:/api.openleyval.org/",
//		routes:{
//			"anaimals/:animal":"animalAction",
//			"*page":"defaultAction"
//		},
//		defaultAction:function(page)
//		{
//			if(page)
//			{
//				var restfulPageUrl=this.restfulUrl+page+"page";
//				this.loadRestfulDate(restfulPageUrl);
//			}
//		},
//		animalAction:function(animal){
//			var restfulPageUrl=this.restfulUrl+animal+"page";
//			this.loadRestfulDate(restfulPageUrl);
//		},
//			loadRestfulDate:function(pageUrl)
//			{
//				getfitattri();
//			}
//	});
//		var app=new resfulApp;
//		Backbone.emulateHTTP=true;
//		Backbone.emulateJSON=true;
//		Backbone.histroy.start();
//	});
	var iframeipaddr;
	function sphomeopen()
	{
//		iservice="pharmacy";
//		getserviceurl("Medication Supplier");
//		subcribed="";
		iframeipaddr=iframeipaddr+"/index.html";
		$('#dynamiciframe').attr('src', iframeipaddr);
		resetservicedisplay();
		$("#col2").show();
		$("#myservices").show();
		$("#strt").show();
		$("iframe").show();
	}
//		var formData = form2object('o', '.', true, function(node) {
//			if (node.id && node.id.match(/ggg/)) {
//				return {
//					name : node.id,
//					value : node.innerHTML
//				};
//			}
//		});
//
//		var json = JSON.stringify(formData, null, '\t');
//	// alert(json);
//		result = json;
//		getserviceurl("Medication supplier");
//		sendorder();
//	}
//	function sendorder()
//	{
//		xmlHttp = GetXmlHttpObject();
//		 var req_url = respipaddr;
//		 var params = result;
//		 SendAsync_PostRequest(xmlHttp, req_url, params, orderconform);
//		
//	}
//	
//	function orderconform()
//	{
//		 if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
//			 var json_resp = xmlHttp.responseText; // Json response
//			 // alert(json_resp);
//			  if (json_resp != null) {
//				alertify.alert("order placed successful"); 
//			  }
//		 }
//	}
//	
