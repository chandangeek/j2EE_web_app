function validateemail(){
	var user=document.form.email;
	if ((user.value==null)||(user.value=="")){
		alertify.alert("<h3>Please Enter email address</h3>");
		user.focus();
		return false;
	}
	else
	{
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

		if (!filter.test(user.value)) 
		{
			alertify.alert('<h3>Please provide a valid email address</h3>');
		user.focus;
		return false;
		}
	}
	return true;
	}
	function validatepass()
	{
	var pass=document.form.password;
	if ((pass.value==null)||(pass.value==""))
	{
		alertify.alert("<h3>Please Enter password</h3>");
		pass.focus();
		return false;
	}
	return true;
	}
	function validate(){
	var ef=validateemail();
	var pf=validatepass();
	if(ef && pf)
	{
		return false;
	}
	return true;
	}