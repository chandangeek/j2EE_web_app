function fetchPatientInfo() {
	var htmlContent ="<table><th>Medicine Name</th><th>Dosage<th>";
	
	var xmlhttp;
	if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else {// code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

			$.getJSON("http://localhost:8080/RESTSample/rest/patient",
					function(obj) {
						$.each(obj, function(key, value) {
							htmlContent += "<tr><td>"+value.medName +"</td>"+"<td>"+value.medDosage +"</td></tr>";
							//document.getElementById("patient_medcine_info").innerHTML  += value.medName + "<br>";
						});
						htmlContent +="</table>";
						document.getElementById("patient_medicine_info").innerHTML = htmlContent;
					});
			
		}
	}
	xmlhttp.open("GET", "http://192.168.10.4:8080/RESTSample/rest/user", true);
	xmlhttp.send();

}