var patid=1;
function setpatid(pat_id)
{
	patid=pat_id;
	alert("patid set");
}
function getpatid()
{
	return patid;
}
