function validatealpha()
{
	var name=document.form1.patName;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter Name field</h3>");
		name.focus();
		return false;
	}
	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets with space allowed</h3>');
		name.focus;
		return false;
		}
	return true;
} 
function validatealphaonly(name)
{
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter field</h3>");
		name.focus();
		return false;
	}
	var filter=/^[a-zA-Z]*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets</h3>');
		name.focus;
		return false;
		}
	return true;
}

function validatenumric()
{
	var num=document.form1.patPhone;
	if((num.value==null)||(num.value=="")){
		alertify.alert("<h3>Please Enter phone number</h3>");
		num.focus();
		return false;
	}
	var filter=/^\d{10}$/;
	if(!filter.test(num.value)) 
		{
		alertify.alert('<h3>Please provide valid 10 digit phone number</h3>');
		num.focus;
		return false;
		}
	return true;
}

function validateemail(){
	var user=document.form1.patEmail;
	if((user.value==null)||(user.value=="")){
		alertify.alert("<h3>Please Enter email address</h3>");
		user.focus();
		return false;
	}
	else
	{
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

		if(!filter.test(user.value)) 
		{
			alertify.alert('<h3>Please provide a valid email address</h3>');
		user.focus;
		return false;
		}
	}
	return true;
}
	
function validateaddr()
	{
	var addr=document.form1.patAddress;
	if((addr.value==null)||(addr.value==""))
	{
		alertify.alert("<h3>Please Enter address</h3>");
		addr.focus();
		return false;
	}
	return true;
}
function validatebg()
	{
	var bg=document.form1.patBloodGroup;
	if((bg.value==null)||(bg.value==""))
	{
		alertify.alert("<h3>Please Enter Blood group</h3>");
		bg.focus();
		return false;
	}
	return true;
}	
	
function validatepassword()
{
	var pass1=document.form1.patPassword;
	if((pass1.value==null)||(pass1.value==""))
	{
		alertify.alert("<h3>Please Enter password</h3>");
		pass1.focus();
		return false;
	}
	return true;
}
function validatedate()  
      {  
		var dob=document.form1.patDob;
//		alert(dob);
	if((dob.value==null)||(dob.value==""))
	{
		alertify.alert("<h3>Please Enter date of birth</h3>");
		dob.focus();
		return false;
	}
		return true;
	}
function formatDate(input) {
	  var datePart = input.match(/\d+/g),
	  year = datePart[0], // get only two digits
	  month = datePart[1], day = datePart[2];

	  return day+'/'+month+'/'+year;
	}
function validatepatient()
{
	var a=validatealpha();
	//var aa=document.form1.patCity;
	//var bb=document.form1.patState;
	//var b=validatealphaonly(aa);
	//var c=validatealphaonly(bb);
	var d=validatenumric();
	var e=validateemail();
	var f=validateaddr();
	var g=validatebg();
	var h=validatepassword();
	var i=validatedate() ;
	var j=validatepasswords();
	if(a==true && d==true && e==true && f==true && g==true && h==true && i==true && j==true)
	{
	test();
	}
else 
	{
//		window.location.replace("register.html");
	return false;
	}
}



function docName()
{
	var name=document.form2.docname;
	if((name.value==null)||(name.value=="")){
		alertify.alert("Please Enter Name field</h3>");
		name.focus();
		return false;
	}
	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets with space allowed</h3>');
		name.focus;
		return false;
		}
	return true;
}

function docSpec()
{
	var name=document.form2.docspec;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter field</h3>");
		name.focus();
		return false;
	}
	var filter=/^[a-zA-Z]*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets</h3>');
		name.focus;
		return false;
		}
	return true;
}
function docDept()
{
	var name=document.form2.docdept;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter field</h3>");
		name.focus();
		return false;
	}
	var filter=/^[a-zA-Z]*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets</h3>');
		name.focus;
		return false;
		}
	return true;
}

function docPhone()
{
	var num=document.form2.docphone;
	if((num.value==null)||(num.value=="")){
		alertify.alert("<h3>Please Enter phone number</h3>");
		num.focus();
		return false;
	}
	var filter=/^\d{10}$/;
	if(!filter.test(num.value)) 
		{
		alertify.alert('<h3>Please provide valid 10 digit phone number</h3>');
		num.focus;
		return false;
		}
	return true;
}

function docEmail(){
	var user=document.form2.docemail;
	if((user.value==null)||(user.value=="")){
		alertify.alert("<h3>Please Enter email address</h3>");
		user.focus();
		return false;
	}
	else
	{
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

		if(!filter.test(user.value)) 
		{
			alertify.alert('<h3>Please provide a valid email address</h3>');
		user.focus;
		return false;
		}
	}
	return true;
}

function docPassword()
{
	var pass1=document.form2.docpassword;
	if((pass1.value==null)||(pass1.value==""))
	{
		alertify.alert("<h3>Please Enter password</h3>");
		pass1.focus();
		return false;
	}
	return true;
}

function validatedoc()
{
	var a=docName();
	var b=docSpec();
	var c=docDept();
	var d=docPhone();
	var e=docEmail();
	var f=docPassword();
	var g=validatedocpasswords();
	if(a==true && b==true && c==true && d==true && e==true && f==true && g==true)
		{
		doccall();
		}
	else 
		{
//			window.location.replace("register.html");
		return false;
		}
}

function spName3()
{
	var name=document.form3.spName;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter Name field</h3>");
		name.focus();
		return false;
	}
	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets with space allowed</h3>');
		name.focus;
		return false;
		}
	return true;
}

function spType3()
{
	var name=document.form3.spType;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter Service type field</h3>");
		name.focus();
		return false;
	}
	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets with space allowed</h3>');
		name.focus;
		return false;
		}
	return true;
}

function spUrl3()
{
	var name=document.form3.spUrl;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter field</h3>");
		name.focus();
		return false;
	}
	return true;
}

function spPhone3()
{
	var num=document.form3.spPhone;
	if((num.value==null)||(num.value=="")){
		alertify.alert("<h3>Please Enter phone number");
		num.focus();
		return false;
	}
	var filter=/^\d{10}$/;
	if(!filter.test(num.value)) 
		{
		alertify.alert('<h3>Please provide valid 10 digit phone number</h3>');
		num.focus;
		return false;
		}
	return true;
}

function spEmail3()
{
	var user=document.form3.spEmail;
	if((user.value==null)||(user.value=="")){
		alertify.alert("<h3>Please Enter email address</h3>");
		user.focus();
		return false;
	}
	else
	{
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

		if(!filter.test(user.value)) 
		{
			alertify.alert('<h3>Please provide a valid email address</h3>');
		user.focus;
		return false;
		}
	}
	return true;
}
function spAttri3()
{
	var name=document.form3.spAttri;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter Service type field</h3>");
		name.focus();
		return false;
	}
	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets with space allowed</h3>');
		name.focus;
		return false;
		}
	return true;
}

function spPassword3()
{
	var pass1=document.form3.spPassword;
	if((pass1.value==null)||(pass1.value==""))
	{
		alertify.alert("<h3>Please Enter password</h3>");
		pass1.focus();
		return false;
	}
	return true;
}
function validatesp()
{
	var a=spName3();
	var b=spType3();
	var c=spUrl3();
	var d=spPhone3();
	var e=spEmail3();
	var ef=spAttri3();
	var f=spPassword3();
	var g=validatesppasswords3();
	if(a==true && b==true && c==true && d==true && e==true && ef==true && f==true && g==true)
	{
		spcall();
	}
else 
	{
//		window.location.replace("register.html");
	return false;
	}
}
/*	
	function validatedate()  
      {  
	  
		  var dateformat = /^(0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])[\/\-]\d{4}$/;  
		  // Match the date format through regular expression  
		  var inputText=document.form1.dob;
			if((inputText.value==null)||(inputText.value==""))
			{
				alert("Please Enter Date of birth");
				inputText.focus();
				return false;
			}
		  if(inputText.value.match(dateformat))  
		  {  
				document.form1.dob.focus();  
				//Test which seperator is used '/' or '-'  
				var opera1 = inputText.value.split('/');  
				var opera2 = inputText.value.split('-');  
				lopera1 = opera1.length;  
				lopera2 = opera2.length;  
				// Extract the string into month, date and year  
			  if(lopera1>1)  
			  {  
				var pdate = inputText.value.split('/');  
			  }  
			  else if(lopera2>1)  
			  {  
				var pdate = inputText.value.split('-');  
			  }  
				  var mm  = parseInt(pdate[0]);  
				  var dd = parseInt(pdate[1]);  
				  var yy = parseInt(pdate[2]);  
				  // Create list of days of a month [assume there is no leap year by default]  
				  var ListofDays = [31,28,31,30,31,30,31,31,30,31,30,31];  
			  if(mm==1 || mm>2)  
			  {  
				  if(dd>ListofDays[mm-1])  
				  {  
					  alert('Invalid date format!');  
					  return false;  
				  }  
			  }  
			  if(mm==2)  
			  {  
				  var lyear = false;  
				  if( (!(yy % 4) && yy % 100) || !(yy % 400))   
				  {  
				  lyear = true;  
				  }  
				  if((lyear==false) && (dd>=29))  
				  {  
				  alert('Invalid date format!');  
				  return false;  
				  }  
				  if((lyear==true) && (dd>29))  
				  {  
				  alert('Invalid date format!');  
				  return false;  
				  }  
			}  
		  }  
		  else  
		  {  
		  alert("Invalid date format!");  
		  document.form1.dob.focus();  
		  return false;  
		  }  
	return true;
      }   */

var country_arr = new Array("Karnataka", "Tamilnadu", "Delhi", "Maharashtra");

var s_a = new Array();
s_a[0]="";
s_a[1]="Bangalore|Kolar|Mangalore|Mysore|Madikare|Gulbarga|Bidar|Raichur|Ballery";
s_a[2]="Chennai|Combature|Kanyakumari|Madurai";
s_a[3]="Qila Rai Pithora|Mehrauli|Siri|Tughlakabad|Firozabad|Shergarh|Shahjahanabad";
s_a[4]="Mumbai|Pune|Nagpur|Thane|Nashik|Vasai-virar|Solapur|Nanded|Amravati";

function print_city(state){
    //given the id of the <select> tag as function argument, it inserts <option> tags
    var option_str = document.getElementById(state);
    option_str.length=0;
    option_str.options[0] = new Option('Select State','');
    option_str.selectedIndex = 0;
    for (var i=0; i<country_arr.length; i++) {
    option_str.options[option_str.length] = new Option(country_arr[i],country_arr[i]);
    }
}

function print_state(city, selectedIndex){
    var option_str = document.getElementById(city);
    option_str.length=0;    // Fixed by Julian Woods
    option_str.options[0] = new Option('Select City','');
    option_str.selectedIndex = 0;
    var state_arr = s_a[selectedIndex].split("|");
    for (var i=0; i<state_arr.length; i++) {
    option_str.options[option_str.length] = new Option(state_arr[i],state_arr[i]);
    }
}

var sstype = new Array("Pharmacy", "Fitness");
var st= new Array();
st[0]="";
st[1]="Medication Supplier|Arurvadic Medication Supplier|Arurvadic and Medication Supplier";
st[2]="Excersice Service|Diet Service|Yoga|Fitness Tips";
function print_attri(state){
    //given the id of the <select> tag as function argument, it inserts <option> tags
    var option_str = document.getElementById(state);
    option_str.length=0;
    option_str.options[0] = new Option('Select Service type','');
    option_str.selectedIndex = 0;
    for (var i=0; i<sstype.length; i++) {
    option_str.options[option_str.length] = new Option(sstype[i],sstype[i]);
    }
}

function print_stype(city, selectedIndex){
    var option_str = document.getElementById(city);
    option_str.length=0;    // Fixed by Julian Woods
    option_str.options[0] = new Option('Select Service Attribute','');
    option_str.selectedIndex = 0;
    var state_arr = st[selectedIndex].split("|");
    for (var i=0; i<state_arr.length; i++) {
    option_str.options[option_str.length] = new Option(state_arr[i],state_arr[i]);
    }
}
function validatepasswords()
{
	var pass1=document.form1.patPassword;
	var pass2=document.form1.rp;
	if(pass1.value!=pass2.value)	{
		alertify.alert("<h3>password not matching</h3>");
		pass1.focus();
		return false;
	}
	return true;
}

function validatedocpasswords()
{
	var pass1=document.form2.doc_password;
	var pass2=document.form2.docrp;
	if(pass1.value!=pass2.value)	{
		alertify.alert("<h3>password not matching</h3>");
		pass1.focus();
		return false;
	}
	return true;
}

function validatesppasswords3()
{
	var pass1=document.form3.spPassword;
	var pass2=document.form3.sprp;
	if(pass1.value!=pass2.value)	{
		alertify.alert("<h3>password not matching</h3>");
		pass1.focus();
		return false;
	}
	return true;
}
//
//<option>Andhra Pradesh</option>
//<option>Arunachal Prodesh</option>
//<option>Assam</option>
//<option>Bihar</option>
//<option>Chhaattisgarh</option>
//<option>Goa</option>
//<option>Gujarat</option>
//<option>Haryana</option>
//<option>Himachal Prodesh</option>
//<option>Jammu and Kashmir</option>
//<option>Jharkhand</option>
//<option>Karnataka</option>
//<option>Kerala</option>
//<option>Madhya Pradesh</option>
//<option>Maharashtra</option>
//<option>Manipur</option>
//<option>Meghalaya</option>
//<option>Mizoram</option>
//<option>Nagaland</option>
//<option>Odisha</option>
//<option>Punjab</option>
//<option>Rajasthan</option>
//<option>Sikkim</option>
//<option>Tamil Nadu</option>
//<option>Tripura</option>
//<option>Uttar Prodesh</option>
