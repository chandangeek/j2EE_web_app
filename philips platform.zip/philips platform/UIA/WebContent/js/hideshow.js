function hideds()
{
$("#doctorregistration").hide();
$("#spregistration").hide();
}
function choice(val)
{
	if(val=="doctor")
	{
		$("#spregistration").hide();
		$("#patientregistration").hide();
		$("#doctorregistration").show();
	}
	if(val=="serviceprovider")
	{
		$("#patientregistration").hide();
		$("#doctorregistration").hide();
		$("#spregistration").show();
	}
	if(val=="patient")
	{
		$("#spregistration").hide();
		$("#doctorregistration").hide();
		$("#patientregistration").show();
	}
}

