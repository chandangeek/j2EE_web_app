function Validate(){
	var user=document.frm.user;
	var pass=document.frm.pass;
	
	if ((user.value==null)||(user.value=="")){
		alertify.alert("<h3>Please Enter user name</h3>");
		user.focus();
		return false;
	}
	if ((pass.value==null)||(pass.value=="")){
		alertify.alert("<h3>Please Enter password</h3>");
		pass.focus();
		return false;
	}
	return true;
 }