var ipaddr="http://192.168.10.140:8080"; 
var myipaddr="http://ingbtcpic2nb3nb:8080/";
$(document).on('click', 'a.resize', function() {
		$cn = $('.container');
		var width = 600, onComplete;
		if (!$cn.data('fullWidth')) {
			$cn.data('fullWidth', $cn.width());
			$cn.css('maxWidth', $cn.width());
		} else {
			width = $cn.data('fullWidth');
			$cn.data('fullWidth', null);
			onComplete = function() {
				$cn.css('maxWidth', null);
			};
		}
		$cn.animate({
			maxWidth : width
		}, {
			complete : onComplete
		});
		$(window).trigger('resize');
		return false;
	});
$(function() {
	$('.tabcordion').tabcordion();
});
window.brunch = window.brunch || {};
window.brunch['auto-reload'] = {
	enabled : true
};
function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
  }
return "";
}
var spid;

function deletecookies(){
	var cookies = document.cookie.split(";");

	for (var i = 0; i < cookies.length; i++) {
		var cookie = cookies[i];
		var eqPos = cookie.indexOf("=");
		var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		window.location.replace(myipaddr+"UIA");
	}
}
function checkcookie1()
{
	patid=getCookie("spid");
		if(patid=='')
			{
			window.location.replace(myipaddr+"UIA");
			}
		else
			{
			spid=getCookie("spid");
			getmyurl();
			}
}

$(document).ready(function() {
	 $("#tablediv1").hide();
	 document.getElementById("MainPopupIframe").value=ipaddr;
	     $("#bdy").mouseover(function(event){
	    	 spid=getCookie("spid");
	           $.get('rest/serviceprovider/'+spid,function(responseJson) {
	            if(responseJson!=null){
	                $("#sptable").find("tr:gt(0)").remove();
	                var table1 = $("#sptable");
	                $.each(responseJson, function(key,value) {
//	                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td>");
//	                        rowNew.children().eq(0).text(value['spId']); 
//	                        rowNew.children().eq(1).text(value['spName']); 
//	                        rowNew.children().eq(2).text(value['spType']); 
//	                        rowNew.children().eq(3).text(value['spUrl']);
//	                        rowNew.children().eq(4).text(value['spPhone']);
//	                        rowNew.children().eq(5).text(value['spEmail']); 
//	                        rowNew.appendTo(table1);
	                	document.getElementById("sid").innerHTML=value.spId;
	                	document.getElementById("sname").innerHTML=value.spName;
	                	document.getElementById("stype").innerHTML=value.spType;
	                	document.getElementById("surl").innerHTML=value.spUrl;
	                	document.getElementById("sph").innerHTML=value.spPhone;
	                	document.getElementById("sei").innerHTML=value.spEmail;
	                	document.getElementById("sat").innerHTML=value.spAttri;
	                });
	                }
	            });
	            $("#tablediv2").show();
	  });      
	});

$(document).ready(function() {
	 $("#tablediv2").hide();
	 $("#nothing").hide();
	 var not;
	     $("#showProducts").click(function(event){
	    	 $("#nothing").hide();
	    	 //patname=getCookie("patname");
	           $.get(ipaddr+"/rest/medicationservice/products",function(responseJson) {
	            if(responseJson!=null){
	                $("#producttable").find("tr:gt(0)").remove();
	                var table1 = $("#producttable");
	                $.each(responseJson, function(key,value) {
	                	not = value.productId;
	                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
	                        rowNew.children().eq(0).text(value['productId']); 
	                        rowNew.children().eq(1).text(value['productName']); 
	                        rowNew.children().eq(2).text(value['productDosage']); 
	                        rowNew.children().eq(3).text(value['stock']);
	                        rowNew.children().eq(4).text(value['status']);
	                        rowNew.children().eq(5).text(value['price']); 
	                        rowNew.appendTo(table1);
	                        $("#tablediv2").show();
	                });
	                }
	            if(typeof not == 'undefined')
	       		{
	        	   $("#nothing").show();
	        	   $("#tablediv2").hide();
	       		}
	            });
	            
	  });      
	});
var oc=0;
$(document).ready(function() {
	 $("#tablediv3").hide();
	 $("#nothing1").hide();
	 var not;
	     $("#showOrders").click(function(event){
	    	 $("#nothing1").hide();
	    	 //patname=getCookie("patname");
	           $.get(ipaddr+"/rest/medicationservice/orders",function(responseJson) {
	            if(responseJson!=null){
	                $("#ordertable").find("tr:gt(0)").remove();
	                var table1 = $("#ordertable");
	                $.each(responseJson, function(key,value) { 
	                	oc++;
	                	not = value.o_id;
	                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
//	                        rowNew.children().eq(0).text(value['o_id']); 
	                        rowNew.children().eq(0).text(value['pat_name']); 
	                        rowNew.children().eq(1).text(value['med_name']); 
	                        rowNew.children().eq(2).text(value['med_dosage']);
	                        rowNew.children().eq(3).text(value['med_quantity']);
	                        rowNew.children().eq(4).text(value['med_price']);
	                        rowNew.children().eq(5).text(value['status']);
	                        rowNew.append("<td><input type='button' value='update order' id='ord' onclick='getupdateorder("+not+")'></td>");
	                        rowNew.append("<td><input type='button' value='delete order' id='ord' onclick='deleteorder("+not+")'></td>");
	                        rowNew.appendTo(table1);
	                        $("#tablediv3").show();
	                });
	                }
	            if(typeof not == 'undefined')
	       		{
	        	   $("#nothing1").show();
	        	   $("#tablediv3").hide();
	       		}
	            });
	                     
	  });      
	});

function deleteorder(orid){
	xmlHttp  = GetXmlHttpObject();
	var req_url = ipaddr+"/rest/medicationservice/deleteorder/"+orid;
	SendAsync_GETRequest(xmlHttp,req_url,null,conformdelete);
}

function conformdelete()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	//Json response
		 	if(json_resp!=null)
		 		{
		 		alertify.alert("<h3>Order Deleted "+json_resp+"</h3>");
		 		getorders();
		 		}
		 	else
		 		{
		 		alertify.alert("Internal Server error");
		 		}
	}
}
function getorders()
{
	$.get(ipaddr+"/rest/medicationservice/orders",function(responseJson) {
        if(responseJson!=null){
            $("#ordertable").find("tr:gt(0)").remove();
            var table1 = $("#ordertable");
            $.each(responseJson, function(key,value) { 
            	oc++;
            	not = value.o_id;
                 var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
//                    rowNew.children().eq(0).text(value['o_id']); 
                    rowNew.children().eq(0).text(value['pat_name']); 
                    rowNew.children().eq(1).text(value['med_name']); 
                    rowNew.children().eq(2).text(value['med_dosage']);
                    rowNew.children().eq(3).text(value['med_quantity']);
                    rowNew.children().eq(4).text(value['med_price']);
                    rowNew.children().eq(5).text(value['status']);
                    rowNew.append("<td><input type='button' value='update order' id='ord' onclick='getupdateorder("+not+")'></td>");
                    rowNew.append("<td><input type='button' value='update order' id='ord' onclick='deleteorder("+not+")'></td>");
                    rowNew.appendTo(table1);
                    $("#tablediv3").show();
            });
            }
        if(typeof not == 'undefined')
   		{
    	   $("#nothing1").show();
    	   $("#tablediv3").hide();
   		}
        });
}
function getupdateorder(ooid)
{
	document.getElementById("ordID").value=ooid;
}

function updateorder()
{
	xmlHttp  = GetXmlHttpObject();
	var ordID=document.getElementById("ordID").value;
	var status=document.getElementById("Status").value;
	var req_url = ipaddr+"/rest/medicationservice/update/"+ordID+'/'+status;
	$("#ordID").val('');
	$("#Status").val('');
	 $.get(req_url,function(responseJson) {
         if(responseJson!=null){
	$.each(responseJson, function(key,value) {
		 var patname=value.pat_name;
		 var medname=value.med_name;
		 var meddosage=value.med_dosage;
		 var medquantity=value.med_quantity;
		 //alert(medquantity);
	req_url = 'rest/patient/updatemedicine/'+patname+'/'+medname+'/'+meddosage+'/'+medquantity;
	//alert(req_url);
	SendAsync_GETRequest(xmlHttp,req_url,null,update_resp);
	 });
         }
	 });
	//SendAsync_GETRequest(xmlHttp,req_url,null,registration_resp);
}

function SendAsync_GETRequest(post_xmlHttp, post_url, post_params, resFunction)
{
  try
  {
      post_xmlHttp.onreadystatechange = resFunction;
     // post_url = post_url.replace(/\|/g, "%7C");
      post_xmlHttp.open("GET",post_url,true);
      post_xmlHttp.setRequestHeader("Content-type", "application/json");
      //post_xmlHttp.setRequestHeader("Content-length", post_params.length);
      //post_xmlHttp.setRequestHeader("Connection", "close");
      post_xmlHttp.send();
  }
  catch(e)
  {
	  alertify.alert('<h3> Server is not Responding... some Problem in server</h3>');
  }
}
var responseJson;
function registration_resp()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	//Json response
//		alert("update "+json_resp);
		//also updated patient medicine
		xmlHttp  = GetXmlHttpObject();
		 
	}
	//redirecting to patient profile
	//alert("insertion successful!!!");
	//window.location.replace("http://localhost:8080/RESTSample/medicine.html");//or not sure  "./patientprofile.html"
}

function update_resp()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	//Json response
		alertify.alert("</h3>update in patient medicine list successful</h3>");
	}
}
var xmlHttp;
function GetXmlHttpObject() {

	var xmlHttp = null;
	try {
		// Firefox, Opera 8.0+, Safari
		xmlHttp = new XMLHttpRequest();

	} catch (e) {
		// Internet Explorer
		try {
			xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}

	return xmlHttp;
}

function getmyurl() 
{
	xmlHttp  = GetXmlHttpObject();
//	alert(iservice+" "+spid);
	var req_url = 'rest/serviceprovider/geturl/'+spid;
	SendAsync_GETRequest(xmlHttp,req_url,null,singleurl);
}

function singleurl()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	// Json response
		if(json_resp!=null)
			{
			ipaddr=json_resp;
			//alert(serviceipaddr);
			//displayservice();
			}
		else
			{
			alertify.alert("<h3>Service Not Found for this service type and attribute</h3>");
			}
	}
}