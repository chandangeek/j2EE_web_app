var ipaddr="http://192.168.10.140:8080"; 
var myipaddr="http://ingbtcpic2nb3nb:8080/";
$(document).on('click', 'a.resize', function() {
		$cn = $('.container');
		var width = 600, onComplete;
		if (!$cn.data('fullWidth')) {
			$cn.data('fullWidth', $cn.width());
			$cn.css('maxWidth', $cn.width());
		} else {
			width = $cn.data('fullWidth');
			$cn.data('fullWidth', null);
			onComplete = function() {
				$cn.css('maxWidth', null);
			};
		}
		$cn.animate({
			maxWidth : width
		}, {
			complete : onComplete
		});
		$(window).trigger('resize');
		return false;
	});
$(function() {
	$('.tabcordion').tabcordion();
});
window.brunch = window.brunch || {};
window.brunch['auto-reload'] = {
	enabled : true
};
function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
  }
return "";
}
var spid;

function deletecookies(){
	var cookies = document.cookie.split(";");

	for (var i = 0; i < cookies.length; i++) {
		var cookie = cookies[i];
		var eqPos = cookie.indexOf("=");
		var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		window.location.replace(myipaddr+"UIA");
	}
}
function checkcookie1()
{
	patid=getCookie("spid");
		if(patid=='')
			{
			window.location.replace(myipaddr+"UIA");
			}
		else
			{
			disable_scroll();
			location.hash="#home";
			spid=getCookie("spid");
			//getmyurl();
			//spid=getCookie("spid");
	           $.get('rest/serviceprovider/'+spid,function(responseJson) {
	            if(responseJson!=null){
	                $("#sptable").find("tr:gt(0)").remove();
	                var table1 = $("#sptable");
	                $.each(responseJson, function(key,value) {
	                	document.getElementById("sid").innerHTML=value.spId;
	                	document.getElementById("sname").innerHTML=value.spName;
	                	document.getElementById("stype").innerHTML=value.spType;
	                	document.getElementById("surl").innerHTML=value.spUrl;
	                	document.getElementById("sph").innerHTML=value.spPhone;
	                	document.getElementById("sei").innerHTML=value.spEmail;
	                	document.getElementById("sat").innerHTML=value.spAttri;
	                });
	                }
	            });

			}
}


var keys = [37, 38, 39, 40];

function preventDefault(e) {
  e = e || window.event;
  if (e.preventDefault)
      e.preventDefault();
  e.returnValue = false;  
}

function keydown(e) {
    for (var i = keys.length; i--;) {
        if (e.keyCode === keys[i]) {
            preventDefault(e);
            return;
        }
    }
}

function wheel(e) {
  preventDefault(e);
}

function disable_scroll() {
  if (window.addEventListener) {
      window.addEventListener('DOMMouseScroll', wheel, false);
  }
  window.onmousewheel = document.onmousewheel = wheel;
  document.onkeydown = keydown;
}

function enable_scroll() {
    if (window.removeEventListener) {
        window.removeEventListener('DOMMouseScroll', wheel, false);
    }
    window.onmousewheel = document.onmousewheel = document.onkeydown = null;  
}


function checkloaded()
{
	$("#loading").remove();
	enable_scroll();
}