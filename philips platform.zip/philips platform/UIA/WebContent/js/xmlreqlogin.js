var result;
function test() {
	var formData = form2object('fff', '.', true, function(node) {
		if (node.id && node.id.match(/www/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	result = JSON.stringify(formData, null, '\t');
	//alert(result);
	registerUser();
}
var xmlHttp, xmlHttppat;
function registerUser() {
	//var username = document.getElementById("email").value; //alert(username)
	xmlHttp = GetXmlHttpObject();
	var req_url = 'rest/patient/login';
	var params = result;
	//alert(result);
	SendAsync_PostRequest(xmlHttp, req_url, params, registration_resp);
}
var pat, pat_id;
function deleteAllCookies() {
	var cookies = document.cookie.split(";");

	for (var i = 0; i < cookies.length; i++) {
		var cookie = cookies[i];
		var eqPos = cookie.indexOf("=");
		var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
	}
}
function setCookie(cname, cvalue, exdays) {
	deleteAllCookies();
	var d = new Date();
	d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
	var expires = "expires=" + d.toGMTString();
	document.cookie = cname + "=" + cvalue + "; " + expires;
	//alert(document.cookie);
}
function registration_resp() {
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText; //Json response
		//alert(json_resp);
		pat_id = json_resp;
//		alert(pat_id);
		if (pat_id != 0 &&  pat_id < 100) {
			pat = "patid";
			setCookie(pat, pat_id, 1);
			window.location.replace("patientprofile.html");
		} 
		else if (pat_id >100 && pat_id<200) {
			pat = "docid";
			setCookie(pat, pat_id, 1);
			window.location.replace("doctorprofile.html");
		}
		else if (pat_id >200 && pat_id < 9888) {
			pat = "spid";
			setCookie(pat, pat_id, 1);
			window.location.replace("sprofile.html");
		}
		else if(pat_id>9888)
			{
				pat="adminid";
				setCookie(pat,pat_id,1);
				window.location.replace("adminprofile.html");
			}
		else {
			alertify.alert("<h4>Invalid Email Or Password<br>Click below to Register!!!</h4>");
			$("#email").val('');
			$("#password").val('');
		}
	}
}

function SendAsync_PostRequest(post_xmlHttp, post_url, post_params, registration_resp) {
	try {
		post_xmlHttp.onreadystatechange = registration_resp;
		post_xmlHttp.open("POST", post_url, true);
		post_xmlHttp.setRequestHeader("Content-type", "application/json");
		post_xmlHttp.send(post_params);
	} catch (e) {
		alertify.alert('<h3>Server is not Responding... some Problem in server</h3>');
	}
}
function GetXmlHttpObject() {

	var xmlHttp = null;
	try {
		// Firefox, Opera 8.0+, Safari
		xmlHttp = new XMLHttpRequest();

	} catch (e) {
		// Internet Explorer
		try {
			xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}

	return xmlHttp;
}

$(document).ready(function() {
	 $("#regsuccess").hide();
});

function getParam(name)
{  
    name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");  
    var regexS = "[\\?&]"+name+"=([^&#]*)";  
    var regex = new RegExp( regexS );  
    var results = regex.exec(window.location.href);
    if(results == null)
        return "";  
    else    
        return results[1];
}
function getUrlData()
{
    var patid = getParam("patid");
    //alert(patid);
    if(patid!="")
  	  {
  	  $("#regsuccess").show();
    	document.getElementById("pid").innerHTML=patid;
  	  }
}