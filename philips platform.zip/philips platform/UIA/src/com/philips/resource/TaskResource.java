package com.philips.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.philips.model.Task;
import com.philips.service.TaskService;

@Path("/task")
public class TaskResource {

	@Path("/{patid}/{cdate}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Task> getSpecificTask(@PathParam("patid") int patid,@PathParam("cdate") String cdate)
	{
		List<Task> list= null;
		TaskService ts= new TaskService();
		list=ts.getsecificpattask(patid,cdate);
		return list;
	}
	
	//insert and delete task based on medication service;;; create medication service for task...
	
	//get tasks of patient..
	@Path("/{pid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Task> gettasks(@PathParam("pid") int pid)
	{
		List<Task> list=null;
		TaskService service=new TaskService();
		list=service.gettask(pid);
		return list;
	}
	
}
