package com.philips.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.philips.model.ServiceProvider;
import com.philips.service.SpService;

@Path("/serviceprovider")
public class SpResource {
	
	//getting spid specific service provider profile information
	@Path("/{spid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<ServiceProvider> getSpInfomatiion(@PathParam("spid") int spid){
		SpService service = new SpService();
		List<ServiceProvider> list = service.getSpecificSpInfo(spid);
		return list;
	}
	
	//registering the service provider
	@Path("/spinsert")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public String setspInfomation(ServiceProvider sp)
	{
		SpService service = new SpService();
		String list = service.setSpInfo(sp);
		return list; //spid returns
	}
	
	@Path("/geturl/{sid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getspecificurl(@PathParam("sid") int sid)
	{
		String res;
		SpService service = new SpService();
		res=service.getmyurl(sid);
		return res;
	}
}
