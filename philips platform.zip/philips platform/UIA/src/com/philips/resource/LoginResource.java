package com.philips.resource;


import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.philips.model.Login;
import com.philips.service.LoginService;
@Path("/loginpatient")
public class LoginResource {
	
//	@GET
//	@Produces(MediaType.APPLICATION_JSON)
//	public List<Login> getPatient1Information() {
//		LoginService service = new LoginService();
//		List<Login> list = service.getPatientInformation();
//		return list;
//	}

	@Path("/login")
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)
	public  int PatientLogin(Login login){
		//List<Login> List = null;						//list is used for?
		LoginService service = new LoginService();
		//List<Login> res=
		//int res=service.setPatientLogin(login);
		int res=service.setLogin(login);
		return res;
		//return List;
		/*
		 * User user = new User("Philips", "PHI", "pic@philips.com");
		 * list.add(user); list.add(new User("Philips1", "PHI",
		 * "pic@philips.com"));
		 */
		
	}
	
}
