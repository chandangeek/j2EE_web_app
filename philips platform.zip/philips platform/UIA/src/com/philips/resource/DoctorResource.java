package com.philips.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.philips.model.Appoint;
import com.philips.model.Doctor;
import com.philips.model.PatientRecord;
import com.philips.service.AppointService;
import com.philips.service.DoctorService;

@Path("/doctor")
public class DoctorResource {
	
	//get all doctor details
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Doctor> getAllDoctors()
	{
		DoctorService service=new DoctorService();
		List<Doctor> list = service.getAllDoctor();
		return list;
	}
	//get specific doctor infomation
	@Path("/{docId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Doctor> getSpecificDoctor(@PathParam("docId") int docid)
	{
		DoctorService service = new DoctorService();
		List<Doctor> list = service.getSpecificDoctor(docid);
		return list;
	}
	
	//insert doctor information
	@Path("/adddoctor")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String createDoctor(Doctor doctor) {
		//List<Patient> List = null;
		DoctorService service = new DoctorService();
		service.setDoctorParamater(doctor);
		return doctor.getDoc_name();
	}
	
	@Path("/appointment/{docId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Appoint> getMyAppointment(@PathParam("docId") int docid)
	{
		List<Appoint> list=null;
		AppointService service=new AppointService();
		list=service.getDocAppointments(docid);
		return list;
	}
	
	@Path("/appointment/update/{appid}/{status}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String setappointment(@PathParam("appid") int appid,@PathParam("status") String status)
	{
		AppointService service=new AppointService();
		service.setDocAppointments(appid, status);
		return "success";
	}
	
	@Path("/addpatientrecord")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public int setpatientrecord(PatientRecord patientrecord) {
		//List<Patient> List = null;
		DoctorService service = new DoctorService();
		service.setPatientRecord(patientrecord);
		return patientrecord.getPr_id();
	}
	
	
	@Path("/patientrecord/{docid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<PatientRecord> getprecord(@PathParam("docid") int docid)
	{
		List<PatientRecord> list=null;
		DoctorService service=new DoctorService();
		list=service.getPatientRecord(docid);
		return list;
	}
	
	
}