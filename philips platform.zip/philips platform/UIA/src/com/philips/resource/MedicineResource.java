package com.philips.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.philips.model.Medicine;
import com.philips.service.MedicineService;


@Path("/medicine")
public class MedicineResource {
	
	//specifing pat id and get medication list
	@Path("/{patid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Medicine> getMedicine(@PathParam("patid") int patid)
	{
		List<Medicine> list= null;
		MedicineService service = new MedicineService();
		list=service.getSpcificMedicineInfo(patid);
		return list;
	}
//	@Produces(MediaType.APPLICATION_JSON)
//	public List<Medicine> getMedicineInformation(){
//		MedicineService service = new MedicineService();
//		List<Medicine> list = service.getMedicineInformation();
//		return list;
//	}
	
	@Path("/addmedicine")
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)
	public String createMedicine(Medicine medicine){
		//List<Medicine> List = null ;
		MedicineService service = new MedicineService();
		service.setMedicineParamater(medicine);
		return medicine.getMedName();

}
	
}