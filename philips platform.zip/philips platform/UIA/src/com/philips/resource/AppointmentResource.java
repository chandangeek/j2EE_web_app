package com.philips.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.philips.model.Appoint;
import com.philips.service.AppointService;

@Path("/appointment")
public class AppointmentResource {
	
	@Path("/{patid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Appoint> getAppointment(@PathParam("patid") int patid)
	{
		List<Appoint> list= null;
		AppointService as=new AppointService();
		list=as.getPatAppointments(patid);
		return list;
	}
	
	@Path("/update/{appid}/{status}")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String setAppointment(@PathParam("appid") int appid,@PathParam("status") String status)
	{
		//int list;
		AppointService as=new AppointService();
		as.setDocAppointments(appid,status);
		return "success";
	}

}
