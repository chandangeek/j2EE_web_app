package com.philips.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.philips.model.User;
import com.philips.service.UserService;

@Path("/user")
public class UserResource {

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> getUserInformation() {
		UserService service = new UserService();
		List<User> list = service.getUserInformation();
		return list;
	}

	@Path("/login")
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)
	public  String PatientLogin(User user){
		String List = null;						//list is used for?
		UserService service = new UserService();
		List=service.setPatientInsertParameter(user);
		return List;
		/*
		 * User user = new User("Philips", "PHI", "pic@philips.com");
		 * list.add(user); list.add(new User("Philips1", "PHI",
		 * "pic@philips.com"));
		 */
		
	}
	
	@Path("/add")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String createPatient(User user){
		//List<User> List = null ;
		UserService service = new UserService();
		service.setPatientParamater(user);
		return user.getUsername();
		
		
	}

	
	
}
