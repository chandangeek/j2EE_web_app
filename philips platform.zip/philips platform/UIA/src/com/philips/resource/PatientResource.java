package com.philips.resource;

import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.philips.model.Appoint;
import com.philips.model.Discount;
import com.philips.model.DiscountList;
import com.philips.model.Doctor;
import com.philips.model.Login;
import com.philips.model.Patient;
import com.philips.model.PatientRecord;
import com.philips.model.ServiceProvider;
import com.philips.model.Subscriber;
import com.philips.service.AppointService;
import com.philips.service.DiscountService;
import com.philips.service.LoginService;
import com.philips.service.PatientService;
import com.philips.service.SpService;
import com.philips.service.TaskService;

@Path("/patient")
public class PatientResource {
	
	//get specific patient infomation
	@Path("/{patId}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List <Patient> getSpecificPatient(@PathParam("patId") int patid)
	{
		PatientService service = new PatientService();
		List<Patient> list = service.setLoginPatient(patid);
		return list;
	}
	
	@Path("/addpatient")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String createPatient(Patient patient) {
		//List<Patient> List = null;
		PatientService service = new PatientService();
		service.setPatientParamater(patient);
		return patient.getPatName();
	}
	
	//Login patient 
	@Path("/login")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public int loginePatient(Login patient) {
		//List<Patient> List = null;
		int patid;
		LoginService service = new LoginService();
		patid=service.setLogin(patient);
		return patid;
	}
	
	@Path("/patientrecord/{patid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<PatientRecord> getpr(@PathParam("patid") int patid)
	{
		PatientService service = new PatientService();
		List<PatientRecord> list = service.getPatientRecord(patid);
		return list;
	}
	
	@Path("/updatemedicine/{patname}/{medname}/{meddosage}/{medquantity}")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String setQunatity(@PathParam("patname") String patname,@PathParam("medname") String medname,@PathParam("meddosage") String meddosage,@PathParam("medquantity") String medquantity)
	{
		String res;
		PatientService service=new PatientService();
		res=service.setmedicineqty(patname,medname,meddosage,medquantity);
		return res;
	}
	@Path("/doctorsearch/{docspec}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Doctor> getdoctordetails(@PathParam("docspec") String docspec)
	{
		List<Doctor> list=null;
		PatientService service=new PatientService();
		list=service.getdoctor(docspec);
		return list;
	}
	
	@Path("/appointinsert")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public int getappoint(Appoint appoint)
	{
		int res;
		AppointService service=new AppointService();
		res=service.setappoint(appoint);
		return res;
	}
	
	@Path("/patientname/{patid}")
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String getpatientname(@PathParam("patid") int patid)
	{
		String res;
		PatientService service=new PatientService();
		res=service.getname(patid);
		return res;
	}
	
	@Path("/patientid/{patname}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public int getpatientid(@PathParam("patname") String patname)
	{
		int res;
		PatientService service=new PatientService();
		res=service.getid(patname);
		return res;
	}
	
	@Path("/docname/{docid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getdocname(@PathParam("docid") int docid)
	{
		String res;
		PatientService service=new PatientService();
		res=service.getdname(docid);
		return res;
	}
	
	@Path("/docid/{docname}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getdocname(@PathParam("docname") String docname)
	{
		String res;
		PatientService service=new PatientService();
		res=service.getdid(docname);
		return res;
	}
	
	@Path("/searchdocs/{docspec}/{docdept}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Doctor> getdocdetails(@PathParam("docspec") String spec,@PathParam("docdept") String dept)
	{
	List<Doctor> list=null;
	PatientService service=new PatientService();
	list=service.getdoctordetails(spec,dept);
	return list;
	}
	
	@Path("/deleterecord/{ppid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String deleterecords(@PathParam("ppid") String patid)
	{
		String res="failure";
		PatientService service= new PatientService();
		res=service.setdeleterecord(patid);
		return res;
	}
	
	@Path("/deleteappointment/{appid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String deleteappoint(@PathParam("appid") int appid)
	{
		String res="failure";
		AppointService service =new AppointService();
		res=service.setdeleteappoint(appid);
		return res;
	}
	
	@Path("/deletetask/{taskid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String deletetasks(@PathParam("taskid") int taskid)
	{
		String res="failure";
		TaskService service= new TaskService();
		res=service.deletetask(taskid);
		return res;
	}
	
	@Path("/getservice/{servicetype}/{arrtitype}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getmedurl(@PathParam("servicetype") String mservice,@PathParam("arrtitype") String attritype)
	{
		String url;
		SpService service=new SpService();
		url=service.getsingleurl(mservice,attritype);
		return url;
	}
	
	@Path("/getserviceattri/{servicetype}/{patid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Subscriber> getattri(@PathParam("servicetype") String stype,@PathParam("patid") int patid)
	{
		List<Subscriber> res;
		SpService service=new SpService();
		res=service.getattributes(stype,patid);
		return res;
	}
	
	@Path("/setdiscount/{pid}/{discountid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public int getdiscount(@PathParam("pid") int pid,@PathParam("discountid") int discountid) throws SQLException
	{
		int list;
		DiscountService service=new DiscountService();
		list=service.setDiscounts(pid,discountid);
		return list;
	}
	
//	@Path("/getservicetask/{discountid}")
//	@GET
//	@Produces(MediaType.APPLICATION_JSON)
//	public List<DiscountList> getdiscounts(@PathParam("discountid") int did) throws SQLException
//	{
//		List<DiscountList> list;
//		DiscountService service=new DiscountService();
//		list=service.getdiscounts(did);
//		return list;
//	}
//	
	@Path("/getmydiscounts/{patid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Discount> getspecificdiscount(@PathParam("patid") int patid) throws SQLException
	{
		List<Discount> list;
		DiscountService service = new DiscountService();
		list=service.getmydiscount(patid);
		return list;
	}
	
	@Path("/getservicetask")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<DiscountList> getdiscounts() throws SQLException
	{
		List<DiscountList> list;
		DiscountService service=new DiscountService();
		list=service.getdiscounts();
		return list;
	}
	
	@Path("/getallspurl")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<ServiceProvider> getallurls()
	{
		List<ServiceProvider> list;
		SpService service= new SpService();
		list=service.getallspurls();
		return list;
	}
	
	@Path("/mydiscount")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public String setdiscount(Discount dis)
	{
		String res="failure";
		DiscountService service = new DiscountService();
		res=service.setmydiscount(dis);
		return res;
	}
	
	@Path("/gettotalmedicinesreq/{pid}/{mname}/{mdosage}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public int getmedicineqty(@PathParam("pid") int pid,@PathParam("mname") String mname,@PathParam("mdosage") String mdosage)
	{
		int res;
		TaskService service = new TaskService();
		res=service.getmediqty(pid,mname,mdosage);
		return res;
	}
	
	@Path("/gettotalmedicines/{pid}/{mname}/{mdosage}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public int getttmedicines(@PathParam("pid") int pid,@PathParam("mname") String mname,@PathParam("mdosage") String mdosage)
	{
		int res;
		TaskService service=new TaskService();
		res=service.gettotalmedicinesremain(pid, mname,	 mdosage);
		return res;
	}
	
	@Path("/setsubcription")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public String setsubscriber(Subscriber sub)
	{
		String res="failure";
		PatientService service=new PatientService();
		res=service.setsubscribe(sub);
		return res;
	}
	
	@Path("/setpsubcription/{a}/{b}/{c}/{d}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String setpsubscriber(@PathParam("a") int a,@PathParam("b") String b,@PathParam("c") String c,@PathParam("d") String d)
	{
		String res="failure";
		PatientService service=new PatientService();
		res=service.setpsubscribe(a,b,c,d);
		return res;
		
	}
	
	@Path("/fitsubcriberlist/{service}/{pid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Subscriber> getsubscriber(@PathParam("pid") int pid,@PathParam("service") String servic)
	{
		List<Subscriber> res=null;
		PatientService service=new PatientService();
		res=service.getsubscriberlist(pid,servic);
		return res;
	}
	@Path("/getserviceattrionly/{service}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Subscriber> getonlyatrri(@PathParam("service") String serv)
	{
		List<Subscriber> res=null;
		SpService service=new SpService();
		res=service.getonlyatrribute(serv);
		return res;
	}
	
	@Path("/getsubscribelist/{service}/{pid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Subscriber> getonlyatrri(@PathParam("service") String serv,@PathParam("pid") int pid)
	{
		List<Subscriber> res=null;
		PatientService service=new PatientService();
		res=service.getsubscriberlist1(pid,serv);
		return res;
	}
	
}
