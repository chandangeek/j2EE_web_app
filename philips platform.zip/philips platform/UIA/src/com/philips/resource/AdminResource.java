package com.philips.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.philips.model.Admin;
import com.philips.model.Emergency;
import com.philips.service.AdminService;

@Path("/admin")
public class AdminResource {
	
	@Path("/{aid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Admin> getprofile(@PathParam("aid") int aid)
	{
		List<Admin> list=null;
		AdminService service=new AdminService();
		list=service.getadmin(aid);
		//System.out.print(list);
		return list;
	}
	
	@Path("/emergencylist")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Emergency> getemdetails()
	{
		List<Emergency> list=null;
		AdminService service= new AdminService();
		list=service.getemergencypostion();
		return list;
	}
	
	@Path("/emergencyinsert")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public String setemergency(Emergency em)
	{
		String res="failure";
		AdminService service = new AdminService();
		res=service.setpatemergency(em);
		return res;
	}
	
	@Path("/eminsert/{pid}/{pname}/{lat}/{log}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String setem(@PathParam("pid") int pid,@PathParam("pname") String pname ,@PathParam("lat") String lat ,@PathParam("log") String log)
	{
		String res="failure";
		AdminService service=new AdminService();
		res=service.setpatem(pid, pname,lat,log);
		return res;
	}
	
	@Path("/clearemergency/{pid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String clear(@PathParam("pid") int pid)
	{
		String res="failure";
		AdminService service= new AdminService();
		res=service.clearemservice(pid);
		return res;
	}
	
}
