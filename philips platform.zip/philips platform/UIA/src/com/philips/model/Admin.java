package com.philips.model;

public class Admin {
	int h_id;
	int admin_Id;
	String admin_email;
	String admin_password;
	
	public Admin(int admin_id,String admin_email)
	{
		this.admin_Id=admin_id;
		this.admin_email=admin_email;
	}
	
	public Admin(String admin_email,String admin_password)
	{
		this.admin_email=admin_email;
		this.admin_password=admin_password;
	}
	
	public Admin(String admin_email)
	{
		this.admin_email=admin_email;
	}
	public Admin(int h_id,int admin_id,String admin_email,String admin_password)
	{
		this.h_id=h_id;
		this.admin_Id=admin_id;
		this.admin_email=admin_email;
		this.admin_password=admin_password;
	}

	public int getH_id() {
		return h_id;
	}

	public void setH_id(int h_id) {
		this.h_id = h_id;
	}

	public int getAdmin_Id() {
		return admin_Id;
	}

	public void setAdmin_Id(int admin_Id) {
		this.admin_Id = admin_Id;
	}

	public String getAdmin_email() {
		return admin_email;
	}

	public void setAdmin_email(String admin_email) {
		this.admin_email = admin_email;
	}

	public String getAdmin_password() {
		return admin_password;
	}

	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	
}