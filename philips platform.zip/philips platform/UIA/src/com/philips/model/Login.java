package com.philips.model;


public class Login {
	
	private String pat_email;
	private String pat_password;
	//private String pat_name;
	private int pat_id;
	
	public void setPat_id(int pat_id) {
		this.pat_id = pat_id;
	}
	public int getPat_id() {
		return pat_id;
	}
	public Login(int pat_id,String pat_email,String pat_password)
	{
		this.pat_id=pat_id;
		this.pat_email=pat_email;
		this.pat_password=pat_password;
	}
	public Login(String pat_email,String pat_password)
	{
		this.pat_email=pat_email;
		this.pat_password=pat_password;
	}
	public Login()
	{
		super();
	}
	public Login(int pat_id)
	{
		this.pat_id=pat_id;
	}
	public String getPat_email() {
		return pat_email;
	}
	public void setPat_email(String pat_email) {
		this.pat_email = pat_email;
	}
	public String getPat_password() {
		return pat_password;
	}
	public void setPat_password(String pat_password) {
		this.pat_password = pat_password;
	}
//	public String getPat_name() {
//		return pat_name;
//	}
//	public void setPat_name(String pat_name) {
//		this.pat_name = pat_name;
//	}
		// TODO Auto-generated method stub
		
}
