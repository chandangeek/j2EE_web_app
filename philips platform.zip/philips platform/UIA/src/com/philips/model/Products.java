package com.philips.model;

public class Products {
	
	int product_id;
	String product_name;
	String product_dosage;
	String stock;
	String status;
	String price;
	
	public Products()
	{
		super();
	}
	
	public Products(int product_id,String product_name,String product_dosage,String stock,String status,String price){
		
		this.product_id=product_id;
		this.product_name=product_name;
		this.product_dosage=product_dosage;
		this.stock=stock;
		this.status=status;
		this.price=price;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProduct_name() {
		return product_name;
	}

	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}

	public String getProduct_dosage() {
		return product_dosage;
	}

	public void setProduct_dosage(String product_dosage) {
		this.product_dosage = product_dosage;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	
	
}
