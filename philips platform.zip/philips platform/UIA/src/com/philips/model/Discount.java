package com.philips.model;

public class Discount {
	
	int disid;
	int patid;
	String offer;
	String values;
	String status;
	int discount_id;
	
	public Discount(int disid,int patid,int discount_id,String offer,String values,String status)
	{
		this.disid=disid;
		this.patid=patid;
		this.discount_id=discount_id;
		this.offer=offer;
		this.values=values;
		this.status=status;
	}
	
	public Discount(int patid,int discount_id,String offer,String values,String status)
	{
		this.patid=patid;
		this.discount_id=discount_id;
		this.offer=offer;
		this.values=values;
		this.status=status;
	}

	public int getDiscount_id() {
		return discount_id;
	}


	public void setDiscount_id(int discount_id) {
		this.discount_id = discount_id;
	}


	public int getDisid() {
		return disid;
	}

	public void setDisid(int disid) {
		this.disid = disid;
	}

	public int getPatid() {
		return patid;
	}

	public void setPatid(int patid) {
		this.patid = patid;
	}

	public String getOffer() {
		return offer;
	}

	public void setOffer(String offer) {
		this.offer = offer;
	}

	public String getValues() {
		return values;
	}

	public void setValues(String values) {
		this.values = values;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	

}
