package com.philips.model;

public class PatientRecord {
	int pr_id;
	int doc_id;
	int pat_id;
	String symtoms;
	String disease;
	String status;
	String docName;
	public PatientRecord()
	{
		super();
	}
	
	public PatientRecord(int pr_id,int doc_id,int pat_id,String symtoms,String disease,String status)
	{
		this.pr_id=pr_id;
		this.doc_id=doc_id;
		this.pat_id=pat_id;
		this.symtoms=symtoms;
		this.disease=disease;
		this.status=status;
	}
	
	public PatientRecord(int pr_id,int doc_id,int pat_id,String symtoms,String disease,String status,String docName)
	{
		this.pr_id=pr_id;
		this.doc_id=doc_id;
		this.pat_id=pat_id;
		this.symtoms=symtoms;
		this.disease=disease;
		this.status=status;
		this.docName=docName;
	}
	
	public PatientRecord(String doc_id,String pat_id,String symtoms,String disease,String status)
	{
		this.doc_id=Integer.parseInt(doc_id);
		this.pat_id=Integer.parseInt(pat_id);
		this.symtoms=symtoms;
		this.disease=disease;
		this.status=status;
	}

	public int getPr_id() {
		return pr_id;
	}

	public void setPr_id(int pr_id) {
		this.pr_id = pr_id;
	}

	public int getDoc_id() {
		return doc_id;
	}

	public void setDoc_id(int doc_id) {
		this.doc_id = doc_id;
	}

	public int getPat_id() {
		return pat_id;
	}

	public void setPat_id(int pat_id) {
		this.pat_id = pat_id;
	}

	public String getSymtoms() {
		return symtoms;
	}

	public void setSymtoms(String symtoms) {
		this.symtoms = symtoms;
	}

	public String getDisease() {
		return disease;
	}

	public void setDisease(String disease) {
		this.disease = disease;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}
	
	
	
}
