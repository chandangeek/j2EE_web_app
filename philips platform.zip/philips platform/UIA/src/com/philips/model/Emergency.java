package com.philips.model;

public class Emergency {
	int em_id;
	int pat_id;
	String pat_name;
	String em_lat;
	String em_log;
	public Emergency(int pat_id,String pat_name,String em_lat,String em_log)
	{
		this.pat_id=pat_id; //
		this.pat_name=pat_name;
		this.em_lat=em_lat;
		this.em_log=em_log;
	}
	
	public Emergency(int em_id,int pat_id,String pat_name,String em_lat,String em_log)
	{
		this.em_id=em_id;
		this.pat_id=pat_id;
		this.pat_name=pat_name;
		this.em_lat=em_lat;
		this.em_log=em_log;
	}

	public int getEm_id() {
		return em_id;
	}

	public void setEm_id(int em_id) {
		this.em_id = em_id;
	}

	public int getPat_id() {
		return pat_id;
	}

	public void setPat_id(int pat_id) {
		this.pat_id = pat_id;
	}

	public String getEm_lat() {
		return em_lat;
	}

	public void setEm_lat(String em_lat) {
		this.em_lat = em_lat;
	}

	public String getEm_log() {
		return em_log;
	}

	public void setEm_log(String em_log) {
		this.em_log = em_log;
	}

	public String getPat_name() {
		return pat_name;
	}

	public void setPat_name(String pat_name) {
		this.pat_name = pat_name;
	}
}
