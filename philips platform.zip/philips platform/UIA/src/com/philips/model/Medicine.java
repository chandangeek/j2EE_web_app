package com.philips.model;



public class Medicine {
	
	int medId;
	int patId ;
	String medName = "";
	String medDosage = "";
	String medFrequency="";
	String medStartDate ="";
	String medEndDate ="";
	int qty;
	String medAvail = "";
	

	public Medicine() {
		super();
	}
	
	public Medicine(int patid,String medStartDate, String medEndDate, String medName, String medDosage,String medFrequency, String qty){
		this.patId = patid; //Integer.parseInt()
		this.medName = medName;
		this.medDosage = medDosage;
		this.medFrequency=medFrequency;
		this.medStartDate = medStartDate;
		this.medEndDate = medEndDate;
		this.qty=Integer.parseInt(qty);
	}
	public Medicine(String patid,String medStartDate, String medEndDate, String medName, String medDosage,String medFrequency, String qty){
		this.patId = Integer.parseInt(patid);
		this.medName = medName;
		this.medDosage = medDosage;
		this.medFrequency=medFrequency;
		this.medStartDate = medStartDate;
		this.medEndDate = medEndDate;
		this.qty=Integer.parseInt(qty);
	}
	
	public Medicine(int medId,int patid, String medName, String medDosage,String medFrequency,String medStartDate, String medEndDate,int qty, String medAvail){
		this.medId=medId;
		this.patId = patid;
		this.medName = medName;
		this.medDosage = medDosage;
		this.medFrequency=medFrequency;
		this.medStartDate = medStartDate;
		this.medEndDate = medEndDate;
		this.qty=qty;
		this.medAvail = medAvail;
	}
	
	public String getMedFrequency() {
		return medFrequency;
	}

	public void setMedFrequency(String medFrequency) {
		this.medFrequency = medFrequency;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}
	public int getPatId() {
		return patId;
	}

	public void setPatId(int patId) {
		this.patId = patId;
	}

	public String getMedName() {
		return medName;
	}

	public void setMedName(String medName) {
		this.medName = medName;
	}

	public String getMedDosage() {
		return medDosage;
	}

	public void setMedDosage(String medDosage) {
		this.medDosage = medDosage;
	}

	public String getMedStartDate() {
		return medStartDate;
	}

	public void setMedStartDate(String medStartDate) {
		this.medStartDate = medStartDate;
	}

	public String getMedEndDate() {
		return medEndDate;
	}

	public void setMedEndDate(String medEndDate) {
		this.medEndDate = medEndDate;
	}

	public String getMedAvail() {
		return medAvail;
	}

	public void setMedAvail(String medAvail) {
		this.medAvail = medAvail;
	}
	public int getMedId() {
		return medId;
	}

	public void setMedId(int medId) {
		this.medId = medId;
	}

}
