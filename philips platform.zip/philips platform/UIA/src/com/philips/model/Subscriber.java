package com.philips.model;

public class Subscriber {
	
	int s_id;
	int patid;
	int sp_id;
	String s_type;
	String atrri_type;
	String sp_url;
	String sp_atrri;
	public Subscriber()
	{
		super();
	}
	
	
	public Subscriber(String sp_atrri)
	{
		this.sp_atrri=sp_atrri;
	}
	public Subscriber(int patid,String s_type,String atrri_type,String sp_url)
	{
		this.patid=patid;
		this.s_type=s_type;
		this.atrri_type=atrri_type;
		this.sp_url=sp_url;
//		this.sp_atrri=spattri;
	}
	
	public Subscriber(int s_id,int patid,int sp_id,String s_type,String atrri_type,String sp_url)
	{
		this.s_id=s_id;
		this.sp_id=sp_id;
		this.patid=patid;
		this.s_type=s_type;
		this.atrri_type=atrri_type;
		this.sp_url=sp_url;
	}
	
	public Subscriber(int s_id,int patid,int sp_id,String s_type,String atrri_type,String sp_url,String sp_atrri)
	{
		this.s_id=s_id;
		this.sp_id=sp_id;
		this.patid=patid;
		this.s_type=s_type;
		this.atrri_type=atrri_type;
		this.sp_url=sp_url;
		this.sp_atrri=sp_atrri;
	}
	
	public int getS_id() {
		return s_id;
	}

	public void setS_id(int s_id) {
		this.s_id = s_id;
	}

	public int getPatid() {
		return patid;
	}

	public void setPatid(int patid) {
		this.patid = patid;
	}

	public int getSp_id() {
		return sp_id;
	}

	public void setSp_id(int sp_id) {
		this.sp_id = sp_id;
	}

	public String getS_type() {
		return s_type;
	}

	public void setS_type(String s_type) {
		this.s_type = s_type;
	}

	public String getAtrri_type() {
		return atrri_type;
	}

	public void setAtrri_type(String atrri_type) {
		this.atrri_type = atrri_type;
	}

	public String getSp_url() {
		return sp_url;
	}

	public void setSp_url(String sp_url) {
		this.sp_url = sp_url;
	}

	public String getSp_atrri() {
		return sp_atrri;
	}

	public void setSp_atrri(String sp_atrri) {
		this.sp_atrri = sp_atrri;
	}
	
}
