package com.philips.model;

public class Doctor {
	
	int doc_id;
	String doc_name;
	String doc_spec;
	String doc_dept;
	String doc_phone;
	String doc_email;
	String doc_password;
	String docrp;
	public String getDocrp() {
		return docrp;
	}

	public void setDocrp(String docrp) {
		this.docrp = docrp;
	}

	public Doctor()
	{
		super();
	}
	
	public Doctor(int doc_id,String doc_name,String doc_spec,String doc_dept,String doc_phone,String doc_email,String doc_password,String docrp)
	{
		this.doc_id=doc_id;
		this.doc_name=doc_name;
		this.doc_spec=doc_spec;
		this.doc_dept=doc_dept;
		this.doc_phone=doc_phone;
		this.doc_email=doc_email;
		this.doc_password=doc_password;
		this.docrp=docrp;
	}
	
	public Doctor(int doc_id,String doc_name,String doc_spec,String doc_dept,String doc_phone,String doc_email,String doc_password)
	{
		this.doc_id=doc_id;
		this.doc_name=doc_name;
		this.doc_spec=doc_spec;
		this.doc_dept=doc_dept;
		this.doc_phone=doc_phone;
		this.doc_email=doc_email;
		this.doc_password=doc_password;
	}
	public Doctor(int doc_id,String doc_name)
	{
		this.doc_id=doc_id;
		this.doc_name=doc_name;
	}
	public int getDoc_id() {
		return doc_id;
	}
	public void setDoc_id(int doc_id) {
		this.doc_id = doc_id;
	}
	public String getDoc_name() {
		return doc_name;
	}
	public void setDoc_name(String doc_name) {
		this.doc_name = doc_name;
	}
	public String getDoc_spec() {
		return doc_spec;
	}
	public void setDoc_spec(String doc_spec) {
		this.doc_spec = doc_spec;
	}
	public String getDoc_dept() {
		return doc_dept;
	}
	public void setDoc_dept(String doc_dept) {
		this.doc_dept = doc_dept;
	}
	public String getDoc_phone() {
		return doc_phone;
	}
	public void setDoc_phone(String doc_phone) {
		this.doc_phone = doc_phone;
	}
	public String getDoc_email() {
		return doc_email;
	}
	public void setDoc_email(String doc_email) {
		this.doc_email = doc_email;
	}
	public String getDoc_password() {
		return doc_password;
	}
	public void setDoc_password(String doc_password) {
		this.doc_password = doc_password;
	}
	

}
