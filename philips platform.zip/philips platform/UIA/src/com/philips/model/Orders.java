package com.philips.model;

public class Orders {
	
	int o_id;
	int pat_id;
	String med_name;
	String med_dosage;
	String med_quantity;
	String med_price;
	
	public Orders()
	{
		super();
	}
	
	public Orders(int o_id,int pat_id,String med_name,String med_dosage,String med_quantity,String med_price)
	{
		this.o_id=o_id;
		this.pat_id=pat_id;
		this.med_name=med_name;
		this.med_dosage=med_dosage;
		this.med_quantity=med_quantity;
		this.med_price=med_price;
	}

	public int getO_id() {
		return o_id;
	}

	public void setO_id(int o_id) {
		this.o_id = o_id;
	}

	public int getPat_id() {
		return pat_id;
	}

	public void setPat_id(int pat_id) {
		this.pat_id = pat_id;
	}

	public String getMed_name() {
		return med_name;
	}

	public void setMed_name(String med_name) {
		this.med_name = med_name;
	}

	public String getMed_dosage() {
		return med_dosage;
	}

	public void setMed_dosage(String med_dosage) {
		this.med_dosage = med_dosage;
	}

	public String getMed_quantity() {
		return med_quantity;
	}

	public void setMed_quantity(String med_quantity) {
		this.med_quantity = med_quantity;
	}

	public String getMed_price() {
		return med_price;
	}

	public void setMed_price(String med_price) {
		this.med_price = med_price;
	}
	
}
