package com.philips.model;

public class ServiceProvider {
	
	int spId;
	String spName;
	String spType;  
	String spUrl;
	String spPhone;
	String spEmail;
	String spPassword;
	String sprp;
	String spAttri;
	public String getSprp() {
		return sprp;
	}

	public void setSprp(String sprp) {
		this.sprp = sprp;
	}

	public ServiceProvider()
	{
		super();		
	}
	
	public ServiceProvider(int spId,String spName,String spType,String spUrl,String spPhone,String spEmail,String spPassword, String spAttri)
	{
		this.spId=spId;
		this.spName=spName;
		this.spType=spType;
		this.spUrl=spUrl;
		this.spPhone=spPhone;
		this.spEmail=spEmail;
		this.spPassword=spPassword;
		this.spAttri=spAttri;
	}
	
	public ServiceProvider(String spName,String spType,String spUrl,String spPhone,String spEmail,String spPassword,String sprp)
	{
		//this.spId=spId;
		this.spName=spName;
		this.spType=spType;
		this.spUrl=spUrl;
		this.spPhone=spPhone;
		this.spEmail=spEmail;
		this.spPassword=spPassword;
		this.sprp=sprp;
	}
	
	public ServiceProvider(int spId,String spName,String spType,String spUrl,String spPhone,String spEmail,String spAttri)
	{
		this.spId=spId;
		this.spName=spName;
		this.spType=spType;
		this.spUrl=spUrl;
		this.spPhone=spPhone;
		this.spEmail=spEmail;
		this.spAttri=spAttri;
 	}
	public ServiceProvider(String spName,String spUrl,String spAttri)
	{
		this.spName=spName;
		this.spUrl=spUrl;
		this.spAttri=spAttri;
	}
	
	public ServiceProvider(String spAttri)
	{
		this.spAttri=spAttri;
	}
	
	public int getSpId() {
		return spId;
	}

	public void setSpId(int spId) {
		this.spId = spId;
	}

	public String getSpName() {
		return spName;
	}

	public void setSpName(String spName) {
		this.spName = spName;
	}

	public String getSpType() {
		return spType;
	}

	public void setSpType(String spType) {
		this.spType = spType;
	}

	public String getSpUrl() {
		return spUrl;
	}

	public void setSpUrl(String spUrl) {
		this.spUrl = spUrl;
	}

	public String getSpPhone() {
		return spPhone;
	}

	public void setSpPhone(String spPhone) {
		this.spPhone = spPhone;
	}

	public String getSpEmail() {
		return spEmail;
	}

	public void setSpEmail(String spEmail) {
		this.spEmail = spEmail;
	}

	public String getSpPassword() {
		return spPassword;
	}

	public void setSpPassword(String spPassword) {
		this.spPassword = spPassword;
	}

	public String getSpAttri() {
		return spAttri;
	}

	public void setSpAttri(String spAttri) {
		this.spAttri = spAttri;
	}
	
}
