package com.philips.model;

public class Task {
	int taskId;
	int patId;
	String taskDescription;
	String Status;
	String medname;
	
	public Task(int taskId,int patId,String taskDescription,String Status,String medname)
	{
		this.taskId=taskId;
		this.patId=patId;
		this.taskDescription=taskDescription;
		this.Status=Status;
		this.medname=medname;
	}
	public Task(int patId,String taskDescription,String Status)
	{
		this.patId=patId;
		this.taskDescription=taskDescription;
		this.Status=Status;
	}
	
	
	public String getMedname() {
		return medname;
	}
	public void setMedname(String medname) {
		this.medname = medname;
	}
	public int getTaskId() {
		return taskId;
	}
	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}
	public int getPatId() {
		return patId;
	}
	public void setPatId(int patId) {
		this.patId = patId;
	}
	public String getTaskDescription() {
		return taskDescription;
	}
	public void setTaskDescription(String taskDescription) {
		this.taskDescription = taskDescription;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
}
