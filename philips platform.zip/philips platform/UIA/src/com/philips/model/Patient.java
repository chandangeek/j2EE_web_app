package com.philips.model;

public class Patient {
	
	int patId;
	String patName ="";
	String patDob ="";
	String patBloodGroup ="";
	String patAddress ="";
	String patCity ="";
	String patState ="";
	String patPhone;
	String patEmail ="";
	String patPassword ="";
	String rp;
	public String getRp() {
		return rp;
	}
	public void setRp(String rp) {
		this.rp = rp;
	}
	private String patGender;
	public String getPatGender() {
		return patGender;
	}
	public void setPatGender(String patGender) {
		this.patGender = patGender;
	}
	public int getPatId() {
		return patId;
	}
	public void setPatId(int patId) {
		this.patId = patId;
	}
	public String getPatName() {
		return patName;
	}
	public void setPatName(String patName) {
		this.patName = patName;
	}
	public String getPatDob() {
		return patDob;
	}
	public void setPatDob(String patDob) {
		this.patDob = patDob;
	}
	public String getPatBloodGroup() {
		return patBloodGroup;
	}
	public void setPatBloodGroup(String patBloodGroup) {
		this.patBloodGroup = patBloodGroup;
	}
	public String getPatAddress() {
		return patAddress;
	}
	public void setPatAddress(String patAddress) {
		this.patAddress = patAddress;
	}
	public String getPatCity() {
		return patCity;
	}
	public void setPatCity(String patCity) {
		this.patCity = patCity;
	}
	public String getPatState() {
		return patState;
	}
	public void setPatState(String patState) {
		this.patState = patState;
	}
	public String getPatPhone() {
		return patPhone;
	}
	public void setPatPhone(String patPhone) {
		this.patPhone = patPhone;
	}
	public String getPatEmail() {
		return patEmail;
	}
	public void setPatEmail(String patEmail) {
		this.patEmail = patEmail;
	}
	public String getPatPassword() {
		return patPassword;
	}
	public void setPatPassword(String patPassword) {
		this.patPassword = patPassword;
	}
	
	public Patient() {
		super();
	}
	
	public Patient(int patID,String patName, String patDob, String patBloodGroup,String patAddress, String patCity, String patState,String patPhone,String patEmail,String patPassword,String rp){
		this.patId = patID;
		this.patName = patName;
		this.patDob = patDob;
		this.patBloodGroup = patBloodGroup;
		this.patAddress = patAddress;
		this.patCity = patCity;
		this.patState = patState;
		this.patPhone = patPhone;
		this.patEmail = patEmail;
		this.patPassword = patPassword;
		this.rp=rp;
	}
	public Patient(int patID,String patName, String patDob, String patBloodGroup,String patAddress, String patCity, String patState,String patPhone,String patEmail,String patPassword){
		this.patId = patID;
		this.patName = patName;
		this.patDob = patDob;
		this.patBloodGroup = patBloodGroup;
		this.patAddress = patAddress;
		this.patCity = patCity;
		this.patState = patState;
		this.patPhone = patPhone;
		this.patEmail = patEmail;
		this.patPassword = patPassword;
	}
	public Patient(String patName) {
		// TODO Auto-generated constructor stub
		this.patName=patName;
	}
	

}
