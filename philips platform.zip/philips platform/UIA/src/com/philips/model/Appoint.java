package com.philips.model;

public class Appoint {
	
	int appointId;
	int patId;
	int docId;
	String appointDersc;
	String appointTimming;
	String appointDate;
	String appointStatus;
	String docName;
	public Appoint()
	{
		super();
	}
	public Appoint(int appointId,int patId,int docId,String appointDersc,String appointTimming,String appointDate,String appointStatus)
	{
		this.appointId=appointId;
		this.patId=patId;
		this.docId=docId;
		this.appointDersc=appointDersc;
		this.appointTimming=appointTimming;
		this.appointDate = appointDate;
		this.appointStatus=appointStatus;
	}
	
	public Appoint(int patId,int docId,String appointDersc,String appointTimming,String appointDate,String appointStatus)
	{
		this.patId=patId;
		this.docId=docId;
		this.appointDersc=appointDersc;
		this.appointTimming=appointTimming;
		this.appointDate = appointDate;
		this.appointStatus=appointStatus;
	}
	
	public Appoint(int appointId,int patId,int docId,String appointDersc,String appointTimming,String appointDate,String appointStatus,String docName)
	{
		this.appointId=appointId;
		this.patId=patId;
		this.docId=docId;
		this.appointDersc=appointDersc;
		this.appointTimming=appointTimming;
		this.appointDate = appointDate;
		this.appointStatus=appointStatus;
		this.docName=docName;
	}
	
	
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public int getDocId() {
		return docId;
	}
	public void setDocId(int docId) {
		this.docId = docId;
	}
	public int getAppointId() {
		return appointId;
	}
	public void setAppointId(int appointId) {
		this.appointId = appointId;
	}
	public int getPatId() {
		return patId;
	}
	public void setPatId(int patId) {
		this.patId = patId;
	}
	public String getAppointDersc() {
		return appointDersc;
	}
	public void setAppointDersc(String appointDersc) {
		this.appointDersc = appointDersc;
	}
	public String getAppointTimming() {
		return appointTimming;
	}
	public void setAppointTimming(String appointTimming) {
		this.appointTimming = appointTimming;
	}
	public String getAppointDate() {
		return appointDate;
	}
	public void setAppointDate(String appointDate) {
		this.appointDate = appointDate;
	}
	public String getAppointStatus() {
		return appointStatus;
	}
	public void setAppointStatus(String appointStatus) {
		this.appointStatus = appointStatus;
	}
}
