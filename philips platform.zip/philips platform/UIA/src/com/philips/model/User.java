package com.philips.model;


public class User {

	
	String username = "";
	String password = "";
	String PatName;

	
	public String getPatName() {
		return PatName;
	}

	public void setPatName(String patName) {
		this.PatName = patName;
	}

	public User() {
		super();
	}

	public String getUsername() {
		return username;
	}

//	public void setUsername(String username) {
//		this.username = username;
//	}

	public User(String username, String password) {
		this.username = username;
		this.password = password;
		
	}

	public User(String PatName){
		this.PatName=PatName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
}
