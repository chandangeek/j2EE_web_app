package com.philips.model;

public class TaskTotal {
	int tt_id;
	int pat_id;
	String med_name;
	String med_dosage;
	String med_frequency;
	int totalmedicines;
	
	public TaskTotal(int tt_id,int pat_id,String med_name,String med_dosage,String med_frequency,int totalmedicines)
	{
		this.tt_id=tt_id;
		this.pat_id=pat_id;
		this.med_name=med_name;
		this.med_dosage=med_dosage;
		this.med_frequency=med_frequency;
		this.totalmedicines=totalmedicines;
	}
	
	public TaskTotal(int pat_id,String med_name,String med_dosage,String med_frequency,int totalmedicines)
	{
//		this.tt_id=tt_id;
		this.pat_id=pat_id;
		this.med_name=med_name;
		this.med_dosage=med_dosage;
		this.med_frequency=med_frequency;
		this.totalmedicines=totalmedicines;
	}

	public int getTt_id() {
		return tt_id;
	}

	public void setTt_id(int tt_id) {
		this.tt_id = tt_id;
	}

	public int getPat_id() {
		return pat_id;
	}

	public void setPat_id(int pat_id) {
		this.pat_id = pat_id;
	}

	public String getMed_name() {
		return med_name;
	}

	public void setMed_name(String med_name) {
		this.med_name = med_name;
	}

	public String getMed_dosage() {
		return med_dosage;
	}

	public void setMed_dosage(String med_dosage) {
		this.med_dosage = med_dosage;
	}

	public String getMed_frequency() {
		return med_frequency;
	}

	public void setMed_frequency(String med_frequency) {
		this.med_frequency = med_frequency;
	}

	public int getTotalmedicines() {
		return totalmedicines;
	}

	public void setTotalmedicines(int tataldays) {
		this.totalmedicines = tataldays;
	}
	
	
}
