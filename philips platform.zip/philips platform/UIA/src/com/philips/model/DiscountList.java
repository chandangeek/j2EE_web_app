package com.philips.model;

public class DiscountList {
	
	int discount_id;
	String discount_desc;
	String expire_date;
	
	public DiscountList(int discount_id,String discount_desc,String expire_date)
	{
		this.discount_id=discount_id;
		this.discount_desc=discount_desc;
		this.expire_date=expire_date;
	}

	public int getDiscount_id() {
		return discount_id;
	}

	public void setDiscount_id(int discount_id) {
		this.discount_id = discount_id;
	}

	public String getDiscount_desc() {
		return discount_desc;
	}

	public void setDiscount_desc(String discount_desc) {
		this.discount_desc = discount_desc;
	}

	public String getExpire_date() {
		return expire_date;
	}

	public void setExpire_date(String expire_date) {
		this.expire_date = expire_date;
	}
	
	
	

}
