package com.philips.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

	private static Connection mConnection = null;

	public static final String DB_URL = "jdbc:mysql://localhost:3306/";
	public static final String DB_NAME = "uia"; //demo
	public static final String DRIVER_NAME = "com.mysql.jdbc.Driver";

	public static Connection getDBConnection() {
		try {
			Class.forName(DRIVER_NAME);
			mConnection = DriverManager.getConnection(DB_URL + DB_NAME, "admin","password" );
	
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mConnection;
	}

	public static void closeDBConnection() {
		try {
			mConnection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
