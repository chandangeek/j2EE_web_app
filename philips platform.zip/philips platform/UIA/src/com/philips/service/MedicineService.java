package com.philips.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.philips.model.Medicine;
import com.philips.util.DBConnection;

public class MedicineService {
	
	private String FETCH_MEDICINE_QUERY = "SELECT * FROM medicine";
	
	Connection mConnection =  null;
	private Statement stmt = null;
	private PreparedStatement ps= null;
	ResultSet rs= null;
	
	public List<Medicine> getMedicineInformation() {
		List<Medicine> medicineInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			ResultSet rs = stmt.executeQuery(FETCH_MEDICINE_QUERY);
			medicineInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return medicineInfo;
	}
	
public String setMedicineParamater(Medicine medicine) {
		
		final String FETCH_USER_QUERY = "INSERT INTO medicine values(?,?,?,?,?,?,?,?,?)";
		Connection mConnection = null;
		TaskService mytasks= new TaskService();
			String medicineInfo = null;
			try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				stmt = mConnection.createStatement();
				int medid;
				ResultSet rs = stmt.executeQuery("select max(med_id) from medicine;");
				if(rs.next())
				{
					medid=rs.getInt(1);
					medid+=1;
					medicine.setMedId(medid);
				}
				ps.setInt(1, medicine.getMedId());
				ps.setInt(2, medicine.getPatId());
				ps.setString(3,medicine.getMedName());
				ps.setString(4,medicine.getMedDosage());
				ps.setString(5, medicine.getMedFrequency());
				ps.setString(6,medicine.getMedStartDate());
				ps.setString(7,medicine.getMedEndDate());
				ps.setInt(8,0);
				ps.setInt(9, medicine.getQty());
				ps.executeUpdate();
				mytasks.setTasks(medicine.getPatId(),medicine.getMedName(),medicine.getMedDosage(),medicine.getMedFrequency(),medicine.getMedStartDate(),medicine.getMedEndDate());
			//	userInfo = convertPojoList(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return medicineInfo;
	}
	
		
	public List<Medicine> getSpcificMedicineInfo(int patid) {
		List<Medicine> medicineInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
//			stmt = mConnection.createStatement();
			//Medicine medicine = null;
			//medicine.setPatId(patid);
			final String FETCH_USER_QUERY = "select * from medicine where pat_id="+patid+";";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			//ps.setInt(1, medicine.getPatId());
			ResultSet rs = ps.executeQuery(FETCH_USER_QUERY);
			medicineInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return medicineInfo;
	}

	private List<Medicine> convertPojoList1(ResultSet rs) throws SQLException {

		List<Medicine> medicineList = new ArrayList<Medicine>();
		while (rs.next()) {
			Medicine medicine = new Medicine(rs.getInt(1),rs.getInt(2), rs.getString(3), rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getInt(8),rs.getString(9));
			medicineList.add(medicine);
		}
		return medicineList;
	}
}
	
	


