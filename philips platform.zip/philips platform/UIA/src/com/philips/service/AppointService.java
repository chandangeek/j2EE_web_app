package com.philips.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.philips.model.Appoint;
import com.philips.util.DBConnection;

public class AppointService {
	
	Connection mConnection =  null;
	private Statement stmt = null;
	private PreparedStatement ps= null;
	ResultSet rs= null;
	public List<Appoint> getPatAppointments(int patid)
	{
		List<Appoint> appointInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			final String FETCH_USER_QUERY = "select * from appointment where pat_id="+patid+";";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			ResultSet rs = ps.executeQuery(FETCH_USER_QUERY);
			appointInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return appointInfo;
	}

	private List<Appoint> convertPojoList1(ResultSet rs) throws SQLException {
		Statement stmt;
		stmt = mConnection.createStatement();
		List<Appoint> appointList = new ArrayList<Appoint>();
		while (rs.next()) {
			int docid=rs.getInt(3);
			String query="select doc_name from doctor where doc_id="+docid+";";
			ResultSet rs21=stmt.executeQuery(query);
			if(rs21.next())
			{
			Appoint appoint = new Appoint(rs.getInt(1),rs.getInt(2),docid,rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),rs21.getString(1));
			appointList.add(appoint);
			}
		}
//		mConnection.close();
		return appointList;
	}
	
	private List<Appoint> convertPojoList21(ResultSet rs) throws SQLException {
		Statement stmt;
		stmt = mConnection.createStatement();
		List<Appoint> appointList = new ArrayList<Appoint>();
		while (rs.next()) {
			int patid=rs.getInt(2);
			String query="select pat_name from patient where pat_id="+patid+";";
			ResultSet rs21=stmt.executeQuery(query);
			if(rs21.next())
			{
			Appoint appoint = new Appoint(rs.getInt(1),patid,rs.getInt(3),rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7),rs21.getString(1));
			appointList.add(appoint);
			}
		}
//		mConnection.close();
		return appointList;
	}
	
	public List<Appoint> setAppointParamater(Appoint appoint) {
		
		final String FETCH_USER_QUERY = "INSERT INTO appointment values(?,?,?,?,?,?,?)";

		Connection mConnection = null;

			List<Appoint> appointInfo = null;
			try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				stmt = mConnection.createStatement();
				int appid;
				ResultSet rs = stmt.executeQuery("select max(appointment_id) from appointment;");
				if(rs.next())
				{
					appid=rs.getInt(1);
					appid+=1;
					appoint.setAppointId(appid);
				}
				ps.setInt(1, appoint.getAppointId());
				ps.setInt(2, appoint.getPatId());
				ps.setInt(3, appoint.getDocId());
				ps.setString(4,appoint.getAppointDersc());
				ps.setString(5, appoint.getAppointTimming());
				ps.setString(6, appoint.getAppointDate());
				ps.setString(7, appoint.getAppointStatus());
				ps.executeUpdate();
			//	userInfo = convertPojoList(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return appointInfo;
	}
	
	public List<Appoint> getDocAppointments(int docid)
	{
		List<Appoint> appointInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			final String FETCH_USER_QUERY = "select * from appointment where doc_id="+docid+";";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			ResultSet rs = ps.executeQuery(FETCH_USER_QUERY);
			appointInfo = convertPojoList21(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return appointInfo;
	}
	
	public int setDocAppointments(int appid,String status)
	{
//		List<Appoint> appointInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			final String FETCH_USER_QUERY = "update appointment set status='"+status+"' where appointment_id="+appid+";";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			ps.executeUpdate(FETCH_USER_QUERY);
			//appointInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return 0;
	}
	
	public int setappoint(Appoint appoint)
	{
		int res=0;
		String query="insert into appointment values(?,?,?,?,?,?,?);";
		try{
			mConnection=DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(query);
			stmt=mConnection.createStatement();
			String q2="select max(appointment_id) from appointment;";
			ResultSet rs1=stmt.executeQuery(q2);
			if(rs1.next())
			{
				res=rs1.getInt(1);
				res+=1;
				appoint.setAppointId(res);
			}
			ps.setInt(1, appoint.getAppointId());
			ps.setInt(2, appoint.getPatId());
			ps.setInt(3, appoint.getDocId());
			ps.setString(4, appoint.getAppointDersc());
			ps.setString(5, appoint.getAppointTimming());
			ps.setString(6, appoint.getAppointDate());
			ps.setString(7, appoint.getAppointStatus());
			ps.executeUpdate();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return res;
	}
	
	public String setdeleteappoint(int appid)
	{
		String res="failure";
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			final String FETCH_USER_QUERY = "delete from appointment where appointment_id="+appid;
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			int re=ps.executeUpdate(FETCH_USER_QUERY);
			if(re==1)
			{
				res="success";
			}
			//appointInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
}
