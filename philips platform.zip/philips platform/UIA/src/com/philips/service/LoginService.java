package com.philips.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.philips.model.Login;
import com.philips.util.DBConnection;

public class LoginService {
	public int setPatientLogin(Login login) {
		final String FETCH_USER_QUERY = "select pat_id from patient where pat_email=? and pat_password=?;";

		Connection mConnection = null;
		//List<User> userList = new ArrayList<User>();
			//List<User> userInfo = null;
		int res = 0;
		try {
				mConnection = DBConnection.getDBConnection();
				PreparedStatement ps;
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				ps.setString(1,(login.getPat_email()));
				ps.setString(2,(login.getPat_password()));
				ResultSet rs = ps.executeQuery();
				if(rs.next())
				{
				login.setPat_id((rs.getInt(1)));
				}
			//	userInfo = convertPojoList(rs);
				
//				while (rs.next()) {
//					User user1 = new User(rs.getString(1));
//					userList.add(user1);
//				}
				res=login.getPat_id();
				//Login result=new Login(rs.getString(1));
				//result1.add(result);
				//System.out.println(result);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return res;
	}


	
	
	
	public int setLogin(Login login) {
		final String FETCH_PATIENT_QUERY = "select pat_id from patient where pat_email=? and pat_password=?;";
		Connection mConnection = null;
		//List<User> userList = new ArrayList<User>();
			//List<User> userInfo = null;
		int res = 0;
		try {
				mConnection = DBConnection.getDBConnection();
				PreparedStatement ps;
				ps = mConnection.prepareStatement(FETCH_PATIENT_QUERY);
				ps.setString(1,(login.getPat_email()));
				ps.setString(2,(login.getPat_password()));
				ResultSet rs = ps.executeQuery();
				if(rs.next())
				{
				login.setPat_id((rs.getInt(1)));
				}
				else
				{
					res=setDoctorLogin(login);
					return res;
					
				}
				res=login.getPat_id();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return res;
	}
	public int setDoctorLogin(Login login)
	{
		final String FETCH_DOCTOR_QUERY= "select doc_id from doctor where doc_email=? and doc_password=?;";
		Connection mConnection = null;
		int res = 0;
		try {
				mConnection = DBConnection.getDBConnection();
				PreparedStatement ps;
				ps = mConnection.prepareStatement(FETCH_DOCTOR_QUERY);
				ps.setString(1,(login.getPat_email()));
				ps.setString(2,(login.getPat_password()));
				ResultSet rs = ps.executeQuery();
				if(rs.next())
				{
				login.setPat_id((rs.getInt(1)));
				}
				else
				{
					res=setSpLogin(login);
					return res;
				}
				res=login.getPat_id();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return res;
	}
	
	public int setSpLogin(Login login)
	{
		final String FETCH_SP_QUERY= "select sp_id from sp where sp_email=? and sp_password=?";
		Connection mConnection = null;
		int res = 0;
		try {
				mConnection = DBConnection.getDBConnection();
				PreparedStatement ps;
				ps = mConnection.prepareStatement(FETCH_SP_QUERY);
				ps.setString(1,(login.getPat_email()));
				ps.setString(2,(login.getPat_password()));
				ResultSet rs = ps.executeQuery();
				if(rs.next())
				{
				login.setPat_id((rs.getInt(1)));
				}
				else
				{
					res=setAdminLogin(login);
					return res;
				}
				res=login.getPat_id();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return res;
	}
	
	public int setAdminLogin(Login login)
	{
		final String FETCH_SP_QUERY= "select admin_id from hospital where admin_email=? and admin_password=?";
		Connection mConnection = null;
		int res = 0;
		try {
				mConnection = DBConnection.getDBConnection();
				PreparedStatement ps;
				ps = mConnection.prepareStatement(FETCH_SP_QUERY);
				ps.setString(1,(login.getPat_email()));
				ps.setString(2,(login.getPat_password()));
				ResultSet rs = ps.executeQuery();
				if(rs.next())
				{
				login.setPat_id((rs.getInt(1)));
				}
				res=login.getPat_id();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		
		return res;
	}
}
