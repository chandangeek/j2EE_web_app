package com.philips.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.philips.model.Doctor;
import com.philips.model.Patient;
import com.philips.model.PatientRecord;
import com.philips.model.Subscriber;
import com.philips.util.DBConnection;

public class PatientService {
	
	
	Connection mConnection =  null;
	private Statement stmt = null;
	private Statement stmt5 =null;
	private PreparedStatement ps= null;
	ResultSet rs= null;
	
	public List<Patient> getPatientInformation() 
	{
			final String FETCH_MEDICINE_QUERY = "SELECT * FROM patient";
			List<Patient> patientInfo = null;
			try {
					mConnection = DBConnection.getDBConnection();
					stmt = mConnection.createStatement();
					ResultSet rs = stmt.executeQuery(FETCH_MEDICINE_QUERY);
					patientInfo = convertPojoList1(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return patientInfo;
}
public List<Patient> setPatientParamater(Patient patient) {
		
		final String FETCH_USER_QUERY = "INSERT INTO patient values(?,?,?,?,?,?,?,?,?,?)";

		Connection mConnection = null;

			List<Patient> patientInfo = null;
			try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				stmt = mConnection.createStatement();
				int patid;
				ResultSet rs = stmt.executeQuery("select max(pat_id) from patient;");
				if(rs.next())
				{
					patid=rs.getInt(1);
					patid+=1;
					patient.setPatId(patid);
				}
				ps.setInt(1, patient.getPatId());
				ps.setString(2,patient.getPatName());
				ps.setString(3,patient.getPatDob());
				ps.setString(4,patient.getPatBloodGroup());
				ps.setString(5,patient.getPatAddress());
				ps.setString(6,patient.getPatCity());
				ps.setString(7,patient.getPatState());
				ps.setString(8,patient.getPatPhone());
				ps.setString(9,patient.getPatEmail());
				ps.setString(10,patient.getPatPassword());
				ps.executeUpdate();
			//	userInfo = convertPojoList(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return patientInfo;
	}

	private List<Patient> convertPojoList1(ResultSet rs) throws SQLException {

		List<Patient> patientList = new ArrayList<Patient>();
		while (rs.next()) {
			Patient patient = new Patient(rs.getInt(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10));
			patientList.add(patient);
		}
		return patientList;
	}

	public int loginPatientParamater(Patient patient) {
		// TODO Auto-generated method stub
		
		final String FETCH_USER_QUERY = "SELECT pat_id FROM patient where pat_email=? and pat_password=?";
		int res = 0;
		Connection mConnection =  null;
		Statement stmt = null;
		PreparedStatement ps= null;
			//List<Patient> patientInfo = null;
			try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				ps.setString(1, patient.getPatEmail());
				ps.setString(2,patient.getPatPassword());
				ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
				if(rs.next())
				{
				res=rs11.getInt(1);
				}
				//patientInfo.add(res); //convertPojoList(rs11);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return res;
	}
		public List<Patient> setLoginPatient(int patid)
		{
			
			final String FETCH_USER_QUERY = "SELECT * FROM patient where pat_id="+patid+";";
			List<Patient> patientInfo = null;
			try {
					mConnection = DBConnection.getDBConnection();
					ps = mConnection.prepareStatement(FETCH_USER_QUERY);
					//Patient patient=null;
					//patient.setPatId(patid);
					//ps.setInt(1,patient.getPatId());
					ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
					patientInfo = convertPojoList1(rs11);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return patientInfo;
		}
		
		public List<PatientRecord> getPatientRecord(int patid)
		{
			List<PatientRecord> returninfo=null;
			final String FETCH_USER_QUERY = "SELECT * FROM patientrecord where pat_id="+patid+";";
			try {
					mConnection = DBConnection.getDBConnection();
					ps = mConnection.prepareStatement(FETCH_USER_QUERY);
					ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
					
					returninfo = convertPojoList12(rs11);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return returninfo;
		}
		
		private List<PatientRecord> convertPojoList12(ResultSet rs) throws SQLException {
			Statement stmt;
			stmt = mConnection.createStatement();
			List<PatientRecord> patientList = new ArrayList<PatientRecord>();
			while (rs.next()) {
				int docid=rs.getInt(2);
				String query="select doc_name from doctor where doc_id="+docid+";";
				ResultSet rs21=stmt.executeQuery(query);
				if(rs21.next())
				{
				PatientRecord patientr = new PatientRecord(rs.getInt(1),docid , rs.getInt(3), rs.getString(4),rs.getString(5),rs.getString(6),rs21.getString(1));
				patientList.add(patientr);
				}
			}
			mConnection.close();
			return patientList;
		}
		
		public String getname(int patid)
		{
			String res = null;
			final String FETCH_USER_QUERY = "SELECT pat_name FROM patient where pat_id="+patid+";";
			try {
					mConnection = DBConnection.getDBConnection();
					ps = mConnection.prepareStatement(FETCH_USER_QUERY);
					//Patient patient=null;
//					ps.setInt(1,patid);
					ResultSet rs11 = ps.executeQuery();
					//res = convertPojoList13(rs11);
					if(rs11.next())
					{
						res=rs11.getString(1);
					}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return res;
		}
//		private List<Patient> convertPojoList13(ResultSet rs) throws SQLException {
//
//			List<Patient> patientList = new ArrayList<Patient>();
//			while (rs.next()) {
//				Patient patient = new Patient(rs.getString(1));
//				patientList.add(patient);
//			}
//			return patientList;
//		}
		public int getid(String patname)
		{
			int res = 0;
			final String FETCH_USER_QUERY = "SELECT pat_id FROM patient where pat_name='"+patname+"';";
			try {
					mConnection = DBConnection.getDBConnection();
					ps = mConnection.prepareStatement(FETCH_USER_QUERY);
					//Patient patient=null;
//					ps.setInt(1,patid);
					ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
					//res = convertPojoList13(rs11);
					if(rs11.next())
					{
						res=rs11.getInt(1);
					}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return res;
		}
		
		public String setmedicineqty(String patname,String medname,String meddosage,String medquantity)
		{
			int patid=-1;
			String result="failure";
			Statement stt=null;
			try {
				mConnection = DBConnection.getDBConnection();
				stmt = mConnection.createStatement();
				stt=mConnection.createStatement();
				ResultSet rs1=stt.executeQuery("select pat_id from patient where pat_name='"+patname+"';");
				if(rs1.next())
				{
				patid=rs1.getInt(1);
				int medav = 0;
				int qty=Integer.parseInt(medquantity);
				String query="select med_availability from medicine where pat_id='"+patid+"' and med_name='"+medname+"';";
				ResultSet rs=stmt.executeQuery(query);
				if(rs.next())
				{
					medav=Integer.parseInt(rs.getString(1));
					qty=Integer.parseInt(medquantity);
					qty=qty+Integer.parseInt(rs.getString(1));
				}
//				String medavail=Integer.toString(medav);
//				medquantity=Integer.toString(qty);
//				qty+=medquantity;
				 String FETCH_USER_QUERY = "update medicine set med_availability='"+qty+"' where pat_id='"+patid+"' and med_name='"+medname+"' and med_dosage='"+meddosage+"';";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				ps.executeUpdate();
//				if(res>0)
//				{
					result="success";
//				}
				//appointInfo = convertPojoList1(rs);
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return result;
		}
		
		public List<Doctor> getdoctor(String docspec)
		{
//			String query="select doc_id,doc_name from doctor where doc_spec='"+docspec+"';";
			String query="select doc_id,doc_name from doctor where doc_spec='"+docspec+"' or doc_dept='"+docspec+"' or doc_name='"+docspec+"' or doc_name='"+docspec+"';";
			List<Doctor> res=null;
			try {
				mConnection =DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(query);
				//Patient patient=null;
//				ps.setInt(1,patid);
				ResultSet rs11 = ps.executeQuery();
				res = convertPojoList14(rs11);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
			return res;
		}
		
		private List<Doctor> convertPojoList14(ResultSet rs) throws SQLException {

			List<Doctor> doctorList = new ArrayList<Doctor>();
			while (rs.next()) {
				Doctor doctor = new Doctor(rs.getInt(1), rs.getString(2));
				doctorList.add(doctor);
			}
			return doctorList;
		}
		
		public String getdname(int docid)
		{
			String res = null;
			String query="select doc_name from doctor where doc_id="+docid+";";
			try {
				mConnection =DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(query);
				//Patient patient=null;
//				ps.setInt(1,patid);
				ResultSet rs12 = ps.executeQuery();
				if(rs12.next())
				{
					res=rs12.getString(1);
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
			return res;
		}
		
		public String getdid(String docname)
		{
			String res = null;
			String query="select doc_id from doctor where doc_name='"+docname+"';";
			try {
				mConnection =DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(query);
				//Patient patient=null;
//				ps.setInt(1,patid);
				ResultSet rs12 = ps.executeQuery();
				if(rs12.next())
				{
					res=Integer.toString(rs12.getInt(1));
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
			return res;
		}
		
		public List<Doctor>getdoctordetails(String spec,String dept)
		{
			String query="select doc_id,doc_name from doctor where doc_spec='"+spec+"' and doc_dept='"+dept+"';";
			List<Doctor> res=null;
			try {
				mConnection =DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(query);
				//Patient patient=null;
//				ps.setInt(1,patid);
				ResultSet rs11 = ps.executeQuery();
				res = convertPojoList14(rs11);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
			return res;
		}
		
		public String setdeleterecord(String patid)
		{
			String res="failure";
			String query="delete from patientrecord where pat_id="+patid+";";
			try {
				mConnection =DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(query);
				//Patient patient=null;
//				ps.setInt(1,patid);
				int rs11 = ps.executeUpdate();
				if(rs11==1)
				{
					res="success";
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
			return res;
		}
		
		
		public String setsubscribe(Subscriber sub)
		{
			String res="faliure";
			int re=0;
			final String FETCH_USER_QUERY = "INSERT INTO subscribe values(?,?,?,?,?,?)";
			Statement stmt1=null;
			Connection mConnection = null;

				try {
					mConnection = DBConnection.getDBConnection();
					stmt1= mConnection.createStatement();
					System.out.println(sub.getS_type()+" "+sub.getSp_url()+" "+sub.getAtrri_type());
					ResultSet rs1=stmt1.executeQuery("select sp_id from sp where s_type='"+sub.getS_type()+"' and sp_url='"+sub.getSp_url()+"' and attri_type='"+sub.getAtrri_type()+"';");
					if(rs1.next())
					{
						sub.setSp_id(rs1.getInt(1));
						System.out.println("seting sp_id "+sub.getSp_id());
					}
					//mConnection = DBConnection.getDBConnection();
					ps = mConnection.prepareStatement(FETCH_USER_QUERY);
					stmt = mConnection.createStatement();
					int sid;
					ResultSet rs = stmt.executeQuery("select max(s_id) from subscribe;");
					if(rs.next())
					{
						sid=rs.getInt(1);
						sid+=1;
						sub.setS_id(sid);
					}
					System.out.println(sub);
					ps.setInt(1, sub.getS_id());
					ps.setInt(2, sub.getPatid());
					ps.setInt(3, sub.getSp_id());
					ps.setString(4, sub.getS_type());
					ps.setString(5, sub.getAtrri_type());
					ps.setString(6, sub.getSp_url());
					re=ps.executeUpdate();
					if(re==1)
					{
						res="success";
					}
				//	userInfo = convertPojoList(rs);
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						if (stmt != null) {
							stmt.close();
						}
						if (mConnection != null) {
							mConnection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			return res;
		}
		
		public String setpsubscribe(int a,String b,String c,String d)
		{
			Subscriber sub=new Subscriber();
			Statement stmt1=null;
			String res="failure";
			int re=0;
			final String FETCH_USER_QUERY = "INSERT INTO subscribe values(?,?,?,?,?,?)";
			//Subscriber sub=new Subscriber(a,b,c,d);
			System.out.println("setting :"+d);
			Connection mConnection = null;
				try {
					mConnection = DBConnection.getDBConnection();
					ps = mConnection.prepareStatement(FETCH_USER_QUERY);
					stmt = mConnection.createStatement();
					stmt1 = mConnection.createStatement();
					ResultSet rs1=stmt1.executeQuery("select sp_id from sp where s_type='"+b+"' and sp_url='"+c+"' and attri_type='"+d+"';");
					if(rs.next())
					{
						sub.setS_id(rs1.getInt(1));
						System.out.println("seting s id");
					}
					int sid;
					ResultSet rs = stmt.executeQuery("select max(s_id) from subscribe;");
					if(rs.next())
					{
						sid=rs.getInt(1);
						sid+=1;
						sub.setS_id(sid);
						System.out.println("got new id");
					}
					ps.setInt(1, sub.getS_id());
					ps.setInt(2, a);
					ps.setInt(3, sub.getSp_id());
					ps.setString(4, b);
					ps.setString(5, c);
					ps.setString(6,d);
					re=ps.executeUpdate();
					if(re==1)
					{
						res="success";
						System.out.println(res);
					}
				//	userInfo = convertPojoList(rs);
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						if (stmt != null) {
							stmt.close();
						}
						if (mConnection != null) {
							mConnection.close();
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			return res;
		}
		
		public List<Subscriber> getsubscriberlist(int pid,String servic)
		{
			List<Subscriber> res=null;
			Connection mConnection = null;
			try {
				mConnection = DBConnection.getDBConnection();
				stmt = mConnection.createStatement();
				ResultSet rs = stmt.executeQuery("select * from subscribe where pat_id="+pid+" and s_type='"+servic+"';");
				res=convertPojoList2(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return res;
		}
		
		
		public List<Subscriber> getsubscriberlist1(int pid,String service)
		{
			List<Subscriber> res=null;
			Connection mConnection = null;
			try {
				mConnection = DBConnection.getDBConnection();
				stmt = mConnection.createStatement();
				ResultSet rs = stmt.executeQuery("select * from subscribe where pat_id="+pid+" and s_type='"+service+"';");
				res=convertPojoList2(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return res;
		}
		List<Subscriber> sublist = new ArrayList<Subscriber>();
		private List<Subscriber> convertPojoList2(ResultSet rs) throws SQLException {

			ArrayList<String> attributesubs=new ArrayList<String>();
//			int pid=0;
			while (rs.next()) {
				attributesubs.add(rs.getString(5));
				System.out.println(attributesubs);
				Subscriber sub = new Subscriber(rs.getInt(1), rs.getInt(2), rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6));
				sublist.add(sub);
			}
			if(attributesubs.size()>0)
			{
				mConnection = DBConnection.getDBConnection();
				stmt5= mConnection.createStatement();
				ResultSet rs1=stmt5.executeQuery("select * from sp where attri_type!='"+attributesubs+"';");
				convertPojoList3(rs1,attributesubs);
			}
			return sublist;
		}
		
		private List<Subscriber> convertPojoList3(ResultSet rs,ArrayList<String> attributesubs) throws SQLException {

			//List<Subscriber> sublist = new ArrayList<Subscriber>();
			while(rs.next()) {
				if(!attributesubs.equals(rs.getString(8)))
				{
				Subscriber sub = new Subscriber(-1,-1,rs.getInt(1),rs.getString(3),rs.getString(8),rs.getString(4),rs.getString(8));
				sublist.add(sub);
				}
			}
			return sublist;
		}
//		private Subscriber getunscribed(String attributesubs,int pid) {
//			// TODO Auto-generated method stub
//			Subscriber  sub=null;
//			try {
//				mConnection = DBConnection.getDBConnection();
//				stmt = mConnection.createStatement();
//				ResultSet rs = stmt.executeQuery("select * from subscribe where pat_id="+pid+" and atrri_type!='"+attributesubs+"';");
//				sub=convertPojoList2(rs);
//			} catch (Exception e) {
//				e.printStackTrace();
//			} finally {
//				try {
//					if (stmt != null) {
//						stmt.close();
//					}
//					if (mConnection != null) {
//						mConnection.close();
//					}
//				} catch (SQLException e) {
//					e.printStackTrace();
//				}
//			}
//			return sub;
//		}
		
//		public List<Subscriber> getsubscriberlist(String serv,int pid)
//		{
//			List<Subscriber> res=null;
//			
//			
//			return res;
//		}
}

