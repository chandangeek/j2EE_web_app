package com.philips.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.philips.model.ServiceProvider;
import com.philips.model.Subscriber;
import com.philips.util.DBConnection;

public class SpService {
	
private String FETCH_SP_QUERY = "SELECT * FROM sp";
	
	Connection mConnection =  null;
	private Statement stmt = null;
	private PreparedStatement ps= null;
	ResultSet rs= null;
	
	public List<ServiceProvider> getSpInfo() {
		List<ServiceProvider> medicineInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			ResultSet rs = stmt.executeQuery(FETCH_SP_QUERY);
			medicineInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return medicineInfo;
	}
	
	private List<ServiceProvider> convertPojoList1(ResultSet rs) throws SQLException {

		List<ServiceProvider> spList = new ArrayList<ServiceProvider>();
		while (rs.next()) {
			ServiceProvider sp = new ServiceProvider(rs.getInt(1),rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(8));
			spList.add(sp);
		}
		return spList;
	}
	
	public String setSpInfo(ServiceProvider sp)
	{
		String spname = null;
		int spid=0;
		final String FETCH_USER_QUERY = "INSERT INTO sp values(?,?,?,?,?,?,?,?)";

		Connection mConnection = null;

			try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				stmt = mConnection.createStatement();
				ResultSet rs = stmt.executeQuery("select max(sp_id) from sp;");
				if(rs.next())
				{
					spid=rs.getInt(1);
					spid+=1;
					sp.setSpId(spid);
				}
				ps.setInt(1, sp.getSpId());
				spname=sp.getSpName();
				ps.setString(2, sp.getSpName());
				ps.setString(3,sp.getSpType());
				ps.setString(4,sp.getSpUrl());
				ps.setString(5, sp.getSpPhone());
				ps.setString(6,sp.getSpEmail());
				ps.setString(7,sp.getSpPassword());
				ps.setString(8, sp.getSpAttri());
				ps.executeUpdate();
			//	userInfo = convertPojoList(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		return spname;
	}
	
	public List<ServiceProvider> getSpecificSpInfo(int spid) {
		List<ServiceProvider> spInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			//ServiceProvider sp = null;
			//sp.setSpId(spid);
			final String FETCH_USER_QUERY = "select * from sp where sp_id="+spid+";";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			//ps.setInt(1,spid); //sp.getSpId()
			ResultSet rs = ps.executeQuery(FETCH_USER_QUERY);
			spInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return spInfo;
	}
	
	public String getsingleurl(String mservice,String attritype)
	{
		String result = null;
		int i=0,torows=0,count=0;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			//ServiceProvider sp = null;
			//sp.setSpId(spid);
			System.out.println(attritype+" "+mservice);
			final String FETCH_USER_QUERY = "select sp_url from sp where s_type='"+mservice+"' and attri_type='"+attritype+"' ;";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			//ps.setInt(1,spid); //sp.getSpId()
			ResultSet rs = ps.executeQuery(FETCH_USER_QUERY);
			Random rand = new Random();
			while(rs.next()){
			torows++;
			result=rs.getString(1);
			}
			System.out.println(torows);
			i = rand.nextInt(torows);
//			while(rs.next() && count==i)
//			{
//			result=rs.getString(1);
//			count++;
//			}
			System.out.println(result);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	String atrribute;
	public List<Subscriber> getattributes(String stype,int patid)
	{
		List<Subscriber> res=null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			ResultSet rs1=stmt.executeQuery("select * from subscribe where s_type='"+stype+"' and pat_id='"+patid+"';");
			final String FETCH_USER_QUERY = "select attri_type from sp where s_type='"+stype+"';";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			//ps.setInt(1,spid); //sp.getSpId()
			ResultSet rs = ps.executeQuery();
			res=convertPojoList2(rs1,rs);
//			res=convertPojoList13(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
	String spatrri=null,subatrri=null;
	private List<Subscriber> convertPojoList2(ResultSet rs1,ResultSet rs) throws SQLException {

		List<Subscriber> sublist = new ArrayList<Subscriber>();
		Subscriber sub=null;
		if (rs1.next()) {
			Subscriber ss=new Subscriber(rs1.getInt(1), rs1.getInt(2), rs1.getInt(3),rs1.getString(4),rs1.getString(5),rs1.getString(6));
			subatrri=rs1.getString(5);
			System.out.println(rs1.getInt(1));
			while(rs.next()) {
				//Subscriber sub = new Subscriber(rs.getInt(1));
				spatrri=rs.getString(1);
				System.out.println(spatrri+" "+subatrri);
				spatrri=spatrri.trim();
				subatrri=subatrri.trim();
					if(subatrri.equals(spatrri))
					{
						System.out.println("inside ss");
						sublist.add(ss);
					}
					else
					{
						sub=new Subscriber(spatrri);
						sublist.add(sub);
					}
//					spatrri="";
			}
		}
		return sublist;
	}
	
	private List<Subscriber> convertPojoList13(ResultSet rs) throws SQLException {

		List<Subscriber> spList = new ArrayList<Subscriber>();
		while (rs.next()) {
			Subscriber sp = new Subscriber(rs.getString(1));
			spList.add(sp);
		}
		return spList;
	}
	
	public String getmyurl(int sid)
	{
		String myurl=null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			ResultSet rs = stmt.executeQuery("select sp_url from sp where sp_id="+sid+";");
			if(rs.next())
			{
				myurl=rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return myurl;
	}
	
	
	public List<ServiceProvider> getallspurls()
	{
		List<ServiceProvider> res=null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			ResultSet rs = stmt.executeQuery("select sp_name,sp_url,attri_type from sp");
			res=convertPojoList3(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
	
	private List<ServiceProvider> convertPojoList3(ResultSet rs) throws SQLException {

		List<ServiceProvider> spList = new ArrayList<ServiceProvider>();
		while (rs.next()) {
			ServiceProvider sp = new ServiceProvider(rs.getString(1),rs.getString(2),rs.getString(3));
			spList.add(sp);
		}
		return spList;
	}
	
	public List<Subscriber> getonlyatrribute(String serv)
	{
		List<Subscriber> res=null; 
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			ResultSet rs = stmt.executeQuery("select * from sp where s_type='"+serv+"';");
			res=convertPojoList2(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
	
	private List<Subscriber> convertPojoList2(ResultSet rs) throws SQLException {

		List<Subscriber> sublist = new ArrayList<Subscriber>();
		while (rs.next()) {
			Subscriber sub = new Subscriber(-1, -1, rs.getInt(1),rs.getString(3),rs.getString(8),rs.getString(4));
			sublist.add(sub);
		}
		return sublist;
	}
	
	
}

