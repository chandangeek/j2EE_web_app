package com.philips.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.philips.model.User;
import com.philips.util.DBConnection;

public class UserService {

	

	Connection mConnection = null;
	private Statement stmt = null;
	private PreparedStatement ps= null;
	//ResultSet rs=null;

	public List<User> getUserInformation() {
		final String FETCH_USER_QUERY = "SELECT * FROM login";
		List<User> userInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			ResultSet rs = stmt.executeQuery(FETCH_USER_QUERY);
			userInfo = convertPojoList(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userInfo;

	}
	
	public List<User> setPatientParamater(User user) {
		
		final String FETCH_USER_QUERY = "INSERT INTO login (username,password) values(?,?)";

		Connection mConnection = null;

			List<User> userInfo = null;
			try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				ps.setString(1,user.getUsername());
				ps.setString(2,user.getPassword());
				ps.executeUpdate();
			//	userInfo = convertPojoList(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return userInfo;

		
	}

	private List<User> convertPojoList(ResultSet rs) throws SQLException {

		List<User> userList = new ArrayList<User>();
		while (rs.next()) {
			User user = new User(rs.getString(2), rs.getString(3));
			userList.add(user);
		}
		return userList;
	}

	public String setPatientInsertParameter(User user) {
		final String FETCH_USER_QUERY = "select pat_name from patient where pat_email=? and pat_password=?;";

		Connection mConnection = null;
		//List<User> userList = new ArrayList<User>();
			//List<User> userInfo = null;
		String result="";
			try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				ps.setString(1,user.getUsername());
				ps.setString(2,user.getPassword());
				ResultSet rs = ps.executeQuery();
			//	userInfo = convertPojoList(rs);
				
//				while (rs.next()) {
//					User user1 = new User(rs.getString(1));
//					userList.add(user1);
//				}
				
				result =rs.getString(1);
				System.out.println(result);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return result;
	}
}

