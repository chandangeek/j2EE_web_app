package com.philips.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.philips.model.Admin;
import com.philips.model.Emergency;
import com.philips.util.DBConnection;

public class AdminService {
	
	public List<Admin> getadmin(int aid)
	{
		List<Admin> res= new ArrayList<Admin>();
		Connection mConnection =  null;
		Statement stmt = null;
		ResultSet rs= null;
		final String FETCH_MEDICINE_QUERY = "SELECT admin_id,admin_email FROM hospital where admin_id="+aid+";";
		try {
				mConnection = DBConnection.getDBConnection();
				stmt = mConnection.createStatement();
				rs = stmt.executeQuery(FETCH_MEDICINE_QUERY);
				if(rs.next())
				{
					Admin ad= new Admin(rs.getInt(1),rs.getString(2));
					res.add(ad);
				}
				System.out.print(res);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
	
	public List<Emergency> getemergencypostion()
	{
		List<Emergency> res=null;
		Connection mConnection =  null;
		Statement stmt = null;
		ResultSet rs= null;
		PreparedStatement ps=null;
		final String FQ = "SELECT * from emergency;";
		try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FQ);
				rs = ps.executeQuery();
				res=convertintopojo(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return res;
	}
	
	
	public List<Emergency> convertintopojo(ResultSet rs) throws SQLException
	{
		List<Emergency> mylist=new  ArrayList<Emergency>();
		while(rs.next())
		{
			Emergency em= new Emergency(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getString(5));
			mylist.add(em);
		}
		return mylist;
	}
	
	
	public String setpatemergency(Emergency em)
	{
		Connection mConnection =  null;
		Statement stmt=null;
		String res="failure";
		int row,emid = 0;
		ResultSet rs= null;
		PreparedStatement ps=null;
		final String FQ = "insert into emergency values(?,?,?,?,?);";
		try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FQ);
				stmt= mConnection.createStatement();
				rs=stmt.executeQuery("select max(em_id) from emergency;");
				if(rs.next())
				{
					emid=rs.getInt(1);
					emid+=1;
					em.setEm_id(emid);
				}
				ps.setInt(1, emid);
				ps.setInt(2, em.getPat_id());
				ps.setString(3, em.getPat_name());
				ps.setString(4, em.getEm_lat());
				ps.setString(5, em.getEm_log());
				row = ps.executeUpdate();
				if(row>0)
				{
					res="success";
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
//				if (stmt != null) {
//					stmt.close();
//				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return res;
	}
	
	public String clearemservice(int pid)
	{
		int row=0;
		String res="failure";
		Connection mConnection =  null;
		Statement stmt = null;
		//ResultSet rs= null;
		final String FETCH_MEDICINE_QUERY = "delete from emergency where pat_id="+pid+";";
		try {
				mConnection = DBConnection.getDBConnection();
				stmt = mConnection.createStatement();
				row = stmt.executeUpdate(FETCH_MEDICINE_QUERY);
				if(row>0)
				{
					res="success";
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
	
	
	public String setpatem(int pid,String pname,String lat,String log)
	{
		String res="failure";
		Connection mConnection =  null;
		Statement stmt=null;
		int row,emid = 0;
		ResultSet rs= null;
		PreparedStatement ps=null;
		Emergency em = new Emergency(pid,pname,lat,log);
		final String FQ = "insert into emergency values(?,?,?,?,?);";
		try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FQ);
				stmt= mConnection.createStatement();
				rs=stmt.executeQuery("select max(em_id) from emergency;");
				if(rs.next())
				{
					emid=rs.getInt(1);
					emid+=1;
					em.setEm_id(emid);
				}
				ps.setInt(1, emid);
				ps.setInt(2, em.getPat_id());
				ps.setString(3, em.getPat_name());
				ps.setString(4, em.getEm_lat());
				ps.setString(5, em.getEm_log());
				row = ps.executeUpdate();
				if(row>0)
				{
					res="success";
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
//				if (stmt != null) {
//					stmt.close();
//				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return res;
	}
}
