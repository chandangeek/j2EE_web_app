package com.philips.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.philips.model.Discount;
import com.philips.model.DiscountList;
import com.philips.util.DBConnection;

public class DiscountService {
	
	Connection mConnection =  null;
	private Statement stmt = null;
	private PreparedStatement ps= null;
	ResultSet rs= null;
//	public List<DiscountList> getDiscounts(int patid,int discount_id)
//	{
//		List<DiscountList> res;
//		List<DiscountList> dislist;
//		int did;
//		String offer;
//		String e_date;
//		try {
//			mConnection = DBConnection.getDBConnection();
//			stmt = mConnection.createStatement();
//			final String FETCH_USER_QUERY = "select * from discountlist where discount_id="+discount_id+";";
//			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
//			ResultSet rs = ps.executeQuery();
//			if(rs.next())
//			{
//				did=rs.getInt(1);
//				offer=rs.getString(2);
//				e_date=rs.getString(3);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			try {
//				if (stmt != null) {
//					stmt.close();
//				}
//				if (mConnection != null) {
//					mConnection.close();
//				}
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		}
//		
//		return res;
//	}
	
	private List<Discount> convertPojoList1(ResultSet rs) throws SQLException {

		List<Discount> disList = new ArrayList<Discount>();
		while (rs.next()) {
			Discount dis = new Discount(rs.getInt(1), rs.getInt(2),rs.getInt(3), rs.getString(4), rs.getString(5),rs.getString(6));
			disList.add(dis);
		}
		return disList;
	}
	
	private List<DiscountList> convertPojoList12(ResultSet rs) throws SQLException {

		List<DiscountList> disList = new ArrayList<DiscountList>();
		Random r = new Random();
		int i;
		//System.out.println(i);
		while(rs.next()) {
			i=r.nextInt(10);
			System.out.println(i);
			DiscountList dis =null;
			dis= new DiscountList(rs.getInt(1), rs.getString(2),rs.getString(3));
			if((i%4)==0)
			{
			disList.add(dis);
			break;
			}
			else if((i%5)==0 && rs.next())
			{
				disList.add(dis);
				break;
			}
			else if((i%3)==0)
			{
				continue;
			}
			else if(rs.next() && (i%7)==0)
			{
				disList.add(dis);
				break;
			}
			else if(!rs.next())
			{
				disList.add(dis);
				break;
			}
		}
		return disList;
	}
	
	
	public int SetPatientDiscount(Discount disc)
	{
		int res=0;
		final String FETCH_USER_QUERY = "INSERT INTO discount values(?,?,?,?,?,?)";

		Connection mConnection = null;

			List<Discount> discountinfo = null;
			try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				stmt = mConnection.createStatement();
				int disid;
				ResultSet rs = stmt.executeQuery("select max(dis_id) from discount;");
				if(rs.next())
				{
					disid=rs.getInt(1);
					disid+=1;
					disc.setDisid(disid);
				}
				ps.setInt(1, disc.getDisid());
				ps.setInt(2,disc.getPatid());
				ps.setInt(3,disc.getDiscount_id());
				ps.setString(4,disc.getOffer());
				ps.setString(5,disc.getValues());
				ps.setString(6,disc.getStatus());
				res=ps.executeUpdate();
			//	userInfo = convertPojoList(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			// create a pdf file with the details of the discount and generete barcode for the discount here using itext....
		return res;
	}
	
	public int setDiscounts(int patid,int discid) throws SQLException
	{
		int res;
		int did = 0;
		String offer = null;
		String e_date = null;
		mConnection = DBConnection.getDBConnection();
		stmt = mConnection.createStatement();
		final String FETCH_USER_QUERY = "select * from discountlist where discount_id="+discid+";";
		ps = mConnection.prepareStatement(FETCH_USER_QUERY);
		ResultSet rs = ps.executeQuery();
		if(rs.next())
		{
			did=rs.getInt(1);
			offer=rs.getString(2);
			e_date=rs.getString(3);
		}
		Discount disc=new Discount(patid,did,offer,e_date,"Offered to patient");
		res=SetPatientDiscount(disc);
		return res;
	}
	
	
//	@SuppressWarnings("null")
	public List<DiscountList> getdiscounts() throws SQLException
	{
		List<DiscountList> res = null;
//		int count=0;
		mConnection = DBConnection.getDBConnection();
		stmt = mConnection.createStatement();
		final String FETCH_USER_QUERY = "select * from discountlist;";
		ps = mConnection.prepareStatement(FETCH_USER_QUERY);
		ResultSet rs = ps.executeQuery();
		//System.out.println(i);
			res=convertPojoList12(rs);
//		Random r =new Random();
//		while(rs.next())
//		{
//			count++;
//		}
		//int i=r.nextInt(count);
		//this will get one discount list service to the patid patient.....
		//System.out.println(i+" "+count);
		//System.out.println(i%2);
//		res=convertPojoList12(rs);
		return res;
	}

	public List<Discount> getmydiscount(int patid) throws SQLException
	{
		List<Discount> res;
		mConnection = DBConnection.getDBConnection();
		stmt = mConnection.createStatement();
		final String FETCH_USER_QUERY = "select * from discount where pat_id="+patid+";";
		ps = mConnection.prepareStatement(FETCH_USER_QUERY);
		ResultSet rs = ps.executeQuery();
		res=convertPojoList1(rs);
		return res;
	}
	
	public String setmydiscount(Discount dis)
	{
		String res="failure";
		final String FETCH_USER_QUERY = "INSERT INTO discount values(?,?,?,?,?,?)";
		int disid=0;
		int updated=0;
		Connection mConnection = null;

			try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				stmt = mConnection.createStatement();
				ResultSet rs = stmt.executeQuery("select max(dis_id) from discount;");
				if(rs.next())
				{
					disid=rs.getInt(1);
					disid+=1;
					dis.setDisid(disid);
				}
				ps.setInt(1, dis.getDisid());
				ps.setInt(2, dis.getPatid());
				ps.setInt(3,dis.getDiscount_id());
				ps.setString(4,dis.getOffer());
				ps.setString(5, dis.getValues());
				ps.setString(6,dis.getStatus());
				updated=ps.executeUpdate();
				if(updated==1)
				{
					res="sucsess";
				}
			//	userInfo = convertPojoList(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			// create a pdf file with the details of the discount and generete barcode for the discount here using itext....

		return res;
	}
}
