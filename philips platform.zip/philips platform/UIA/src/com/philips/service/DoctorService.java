package com.philips.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.philips.model.Doctor;
import com.philips.model.PatientRecord;
import com.philips.util.DBConnection;

public class DoctorService {

	Connection mConnection = null;
	private Statement stmt = null;
	private PreparedStatement ps = null;
	ResultSet rs = null;

	public List<Doctor> setDoctorParamater(Doctor doctor) {

		final String FETCH_USER_QUERY = "INSERT INTO doctor values(?,?,?,?,?,?,?)";

		Connection mConnection = null;

		List<Doctor> doctorInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			stmt = mConnection.createStatement();
			int docid;
			ResultSet rs = stmt
					.executeQuery("select max(doc_id) from doctor;");
			if (rs.next()) {
				docid = rs.getInt(1);
				docid += 1;
				doctor.setDoc_id(docid);
			}
			ps.setInt(1, doctor.getDoc_id());
			ps.setString(2, doctor.getDoc_name());
			ps.setString(3, doctor.getDoc_spec());
			ps.setString(4, doctor.getDoc_dept());
			ps.setString(5, doctor.getDoc_phone());
			ps.setString(6, doctor.getDoc_email());
			ps.setString(7, doctor.getDoc_password());
			ps.executeUpdate();
			// userInfo = convertPojoList(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return doctorInfo;
	}

	public List<Doctor> getSpecificDoctor(int doc_id) {
		List<Doctor> list = null;
		final String FETCH_USER_QUERY = "SELECT * FROM doctor where doc_id="+ doc_id + ";";
		try {
			mConnection = DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
			list = convertPojoList1(rs11);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return list;
	}
	
	
	public List<Doctor> getAllDoctor() {
		List<Doctor> list = null;
		final String FETCH_USER_QUERY = "SELECT * FROM doctor;";
		try {
			mConnection = DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
			list = convertPojoList1(rs11);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return list;
	}
	private List<Doctor> convertPojoList1(ResultSet rs) throws SQLException {

		List<Doctor> doctorList = new ArrayList<Doctor>();
		while (rs.next()) {
			Doctor doctor = new Doctor(rs.getInt(1), rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6), rs.getString(7));
			doctorList.add(doctor);
		}
		return doctorList;
	}
	
	public List<PatientRecord> setPatientRecord(PatientRecord patientrecord) {

		final String FETCH_USER_QUERY = "INSERT INTO patientrecord values(?,?,?,?,?,?)";

		Connection mConnection = null;

		List<PatientRecord> patietnrecordInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			stmt = mConnection.createStatement();
			int prid;
			ResultSet rs = stmt
					.executeQuery("select max(pr_id) from patientrecord;");
			if (rs.next()) {
				prid = rs.getInt(1);
				prid += 1;
				patientrecord.setPr_id(prid);
			}
			ps.setInt(1, patientrecord.getPr_id());
			ps.setInt(2, patientrecord.getDoc_id());
			ps.setInt(3, patientrecord.getPat_id());
			ps.setString(4, patientrecord.getSymtoms());
			ps.setString(5, patientrecord.getDisease());
			ps.setString(6, patientrecord.getStatus());
			ps.executeUpdate();
			// userInfo = convertPojoList(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return patietnrecordInfo;
	}
	
	public List<PatientRecord> getPatientRecord(int docid) {
		List<PatientRecord> list = null;
		final String FETCH_USER_QUERY = "SELECT * FROM patientrecord where doc_id="+ docid + ";";
		try {
			mConnection = DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
			list = convertPojoList11(rs11);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return list;
	}
	
	private List<PatientRecord> convertPojoList11(ResultSet rs) throws SQLException {
		Statement stmt;
		stmt = mConnection.createStatement();
		List<PatientRecord> prList = new ArrayList<PatientRecord>();
		while (rs.next()) {
			int patid=rs.getInt(3);
			String query="select pat_name from patient where pat_id="+patid+";";
			ResultSet rs21=stmt.executeQuery(query);
			if(rs21.next())
			{
			PatientRecord pr = new PatientRecord(rs.getInt(1), rs.getInt(2), patid , rs.getString(4), rs.getString(5),rs.getString(6),rs21.getString(1));
			prList.add(pr);
			}
		}
		return prList;
	}
}
