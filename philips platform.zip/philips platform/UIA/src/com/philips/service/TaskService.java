package com.philips.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.philips.model.Task;
import com.philips.model.TaskTotal;
import com.philips.util.DBConnection;

public class TaskService {

	Connection mConnection = null;
	private Statement stmt = null;
	private PreparedStatement ps = null;
	private PreparedStatement ps1=null;
	ResultSet rs = null;
	static int counttt=0;
	static int medquantity=0;
	// public List<Task> getsecificpattask(int patid)
	// {
	// List<Task> taskInfo = null;
	// try {
	// mConnection = DBConnection.getDBConnection();
	// stmt = mConnection.createStatement();
	// final String FETCH_USER_QUERY =
	// "select * from task where pat_id="+patid+";";
	// ps = mConnection.prepareStatement(FETCH_USER_QUERY);
	// ResultSet rs = ps.executeQuery(FETCH_USER_QUERY);
	// taskInfo = convertPojoList1(rs);
	// } catch (Exception e) {
	// e.printStackTrace();
	// } finally {
	// try {
	// if (stmt != null) {
	// stmt.close();
	// }
	// if (mConnection != null) {
	// mConnection.close();
	// }
	// } catch (SQLException e) {
	// e.printStackTrace();
	// }
	// }
	// return taskInfo;
	// }
//	static int indx = 0;
	static int cudatecount=0;
	static String tdate=null;
	public List<Task> getsecificpattask(int patid, String cudate) {
		List<Task> taskInfo = null;
		// List<TaskTotal> ttinfo=null;
//		System.out.println(cudatecount+" and "+tdate+" "+cudate);
//		if(tdate!=cudate && cudatecount>0)
//		{
//			cudatecount=0;
			System.out.println(cudatecount+" and "+tdate);
//		}
//		if(cudatecount==0)
//		{
//		tdate=cudate;
//		}
		if(tdate==null)
		{
			tdate=cudate;
			cudatecount=0;
		}
		if(tdate==cudate && cudatecount==0) //cudatecount == 1 &&
		{
		try {
				cudatecount++;
				//tdate="";
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			Statement stmt1 = mConnection.createStatement();
			String query = "select * from tasktotal where pat_id=" + patid;
			ResultSet rs13 = stmt.executeQuery(query);
//			if (rs13.next()) {
			int check=0;
				while(rs13.next())
				{
					check=1;
				// ttinfo=convertPojoList13(rs13);
				// logic for today task....
				String mname = rs13.getString(3);
				String freq = rs13.getString(5);
				System.out.println(mname + " " + patid);
				System.out.println(cudate);
				String mediquery = "select med_enddate from medicine where pat_id='"
						+ patid + "' and med_name='" + mname + "';";
				ResultSet rs14 = stmt1.executeQuery(mediquery);
				String enddate = null;
				if(rs14.next())
				{
				enddate = rs14.getString(1);
				System.out.println(enddate + " ");
				}
				// check for erroe in ccasting string to date
				// SimpleDateFormat formatter = new
				// SimpleDateFormat("yyyy-MM-dd");
				// String dateInString = "07/06/2013";
				DateTime cdate = null;
				DateTime edate = null;
				try {
					DateTimeFormatter formatter = DateTimeFormat.forPattern("MM-dd-yyyy");
					cdate = formatter.parseDateTime(cudate);
					DateTimeFormatter formatter1 = DateTimeFormat.forPattern("yyyy-MM-dd");
					edate = formatter1.parseDateTime(enddate);
				} catch (Exception e) {
					e.printStackTrace();
				}

				// if(cdate.before(edate)){
				// long diff = edate.getTime() - cdate.getTime();
				// int diffDays = (int) (diff / (24 * 60 * 60 * 1000));
				// String[] fre=getDate(freq);
				int diffDays = Days.daysBetween(new LocalDate(cdate),
						new LocalDate(edate)).getDays();
				System.out.println(diffDays);
				// check for error due to pattern maching in getnoon.....
				getNoon(freq);
				// int count=0;
				// for(int i=0;i<3;i++)
				// {
				// if(fre[i]=="1")
				// {
				// count++;
				// }
				// }
//				String[] stringnoon=(String[]) noon.toArray();
//				for(int z=0;z<stringnoon.length;z++)
//				{
				if(mor!=null)
				{
					settasks(patid,mname,mor);
					mor=null;
				}
				if(aft!=null)
				{
					settasks(patid,mname,aft);
					aft=null;
				}
				if(nyt!=null)
				{
					settasks(patid,mname,nyt);
					nyt=null;
				}
				final String FETCH_USER_QUERY = "select * from task where pat_id="+ patid + ";";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				ResultSet rs11 = ps.executeQuery();
				taskInfo =convertPojoList1(rs11);
				}
				if(check == 0) {
					final String query1 = "update task set status=\"task expired on done delete will delete medication list and task list\";";
					ps = mConnection.prepareStatement(query1);
					ps.executeUpdate();
					final String FETCH_USER_QUERY1 = "select * from task where pat_id="
							+ patid + ";";
					ps = mConnection.prepareStatement(FETCH_USER_QUERY1);
					ResultSet rs12 = ps.executeQuery();
					taskInfo = convertPojoList1(rs12);
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		}
		return taskInfo;
	}
		
		private void settasks(int patid,String mname,String noon)
		{
			String taskderc = "Take " + mname + " during "+noon;
			Task task = new Task(patid, taskderc, "in course");
			setTaskParamater(task,mname);
		}

	public List<Task> setTaskParamater(Task task,String medname) {

		final String FETCH_USER_QUERY = "INSERT INTO task values(?,?,?,?,?)";

		Connection mConnection = null;

		List<Task> taskInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			stmt = mConnection.createStatement();
			int taskid = 0;
			ResultSet rs = stmt.executeQuery("select max(task_id) from task;");
			if (rs.next()) {
				taskid = rs.getInt(1);
				taskid += 1;
				//taskid+=counttt;
				task.setTaskId(taskid);
//				counttt++;
			}
			//System.out.println("after adding "+taskid);
			ps.setInt(1, task.getTaskId());
			ps.setInt(2, task.getPatId());
			ps.setString(3, task.getTaskDescription());
			ps.setString(4, task.getStatus());
			ps.setString(5, medname);

			ps.executeUpdate();
			// userInfo = convertPojoList(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return taskInfo;
	}

	// private List<TaskTotal> convertPojoList13(ResultSet rs) throws
	// SQLException
	// {
	// List<TaskTotal> tasklist = new ArrayList<TaskTotal>();
	// while (rs.next()) {
	// TaskTotal tto=new
	// TaskTotal(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getInt(6));
	// tasklist.add(tto);
	// }
	// return tasklist;
	// }
	private List<Task> convertPojoList1(ResultSet rs) throws SQLException {

		List<Task> taskList = new ArrayList<Task>();
		while (rs.next()) {
			Task task = new Task(rs.getInt(1), rs.getInt(2), rs.getString(3),rs.getString(4),rs.getString(5));
			taskList.add(task);
		}
		return taskList;
	}

	// called by medicineservice while insertion of medication list
	// here bellow it will update the medication details in the tasktotal and
	// task tables;;
	static int index = 0;

	public void setTasks(int patid, String mname, String meddosage,
			String freq, String sdate, String edate) throws ParseException, SQLException {
		System.out.println(sdate + " " + edate);
		// SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
		// Date dates = (Date) new SimpleDateFormat("mm-dd-yyyy",
		// Locale.ENGLISH).parse(sdate);
		// Date datee = (Date) new SimpleDateFormat("mm-dd-yyyy",
		// Locale.ENGLISH).parse(edate);
		DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd");
		DateTime dates = null;
		DateTime datee = null;
		try {
			dates = formatter.parseDateTime(sdate);
			datee = formatter.parseDateTime(edate);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(dates + " " + datee);
		// long diff = datee.getTime() - dates.getTime();
		int diffDays = Days.daysBetween(new LocalDate(dates),
				new LocalDate(datee)).getDays();
		// int diffDays = (int) (diff / (24 * 60 * 60 * 1000));
		System.out.println(diffDays);
		String[] fre = getDate(freq);
		// String[] noon=getNoon(freq);
		int count = 0;
		for (int i = 0; i < index; i++) {
			System.out.println(fre[i] + " " + index);
			count++;
			System.out.println(count);
		}
		// String taskderc="Take "+mname+" in the ";
		// //count contains single medicine consumed per day...
		// //the below gives total no of medicines required for entire course...
		// //task at patient js should send pat_id and current date
		int totalcoursemedicine = diffDays * count;
		System.out.println(totalcoursemedicine);
		// //get morning or afternoon or night to take medicines.... to add for
		// task description..
		// for(int i=0;i<3;i++)
		// {
		// if(noon[i]=="morning")
		// {
		// taskderc+=noon[i];
		// }
		// if(noon[i]=="afternoon")
		// {
		// taskderc+=","+noon[i];
		// }
		// if(noon[i]=="night")
		// {
		// taskderc+=","+noon[i];
		// }
		// }
		medquantity=totalcoursemedicine;
//		System.out.println(medquantity);
		String q="update medicine set med_quntity='"+medquantity+"' where pat_id='"+patid+"';";
		mConnection = DBConnection.getDBConnection();
		ps1 = mConnection.prepareStatement(q);
		ps1.executeUpdate();
		
		TaskTotal tt = new TaskTotal(patid, mname, meddosage, freq,totalcoursemedicine);
		final String FETCH_USER_QUERY = "INSERT INTO tasktotal values(?,?,?,?,?,?)";

		Connection mConnection = null;
		// List<Task> taskInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			stmt = mConnection.createStatement();
			int ttid=0;
			System.out.println("before tt id max value"+ttid);
			ResultSet rs = stmt	.executeQuery("select max(tt_id) from tasktotal;");
			if (rs.next()) {
				ttid = rs.getInt(1);
				ttid += 1;
				ttid+=counttt;
				counttt++;
				tt.setTt_id(ttid);
				System.out.println("tt id is "+ttid);
			}
			ps.setInt(1, tt.getTt_id());
			ps.setInt(2, tt.getPat_id());
			ps.setString(3, tt.getMed_name());
			ps.setString(4, tt.getMed_dosage());
			ps.setString(5, tt.getMed_frequency());
			ps.setInt(6, tt.getTotalmedicines());
			ps.executeUpdate();
//			if(counttt ==1){
//				medquantity=totalcoursemedicine;	
//			}
//			else if(counttt>1)
//			{
//				medquantity=totalcoursemedicine;
//			}
			
			// userInfo = convertPojoList(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		// Task ts=new Task(patid,taskderc,"awaited");
		// setTaskParamater(ts);

	}

	private static String[] getDate(String desc) {
		int count = 0;
		index=0;
		String[] allMatches = new String[2];
		Matcher m = Pattern.compile("([1]{1}-|-[1]{1}|-[1]{1}-)").matcher(desc);
		while (m.find()) {
			allMatches[count] = m.group();
			count++;
			index++;
		}
		return allMatches;
	}
	static int count1=0;
	static String mor=null;
	static String aft=null;
	static String nyt=null;
	private static void getNoon(String desc) {
		count1 = 0;
//		List<String> allMatches=new ArrayList<String>();
//		String[] allMatches;
//		System.out.println(desc);
		Matcher m = Pattern.compile("([1]{1}-[0]{1}-[0]{1})").matcher(desc);
		Matcher a = Pattern.compile("([0]{1}-[1]{1}-[0]{1})").matcher(desc);
		Matcher n = Pattern.compile("([0]{1}-[0]{1}-[1]{1})").matcher(desc);
		Matcher an = Pattern.compile("([0]{1}-[1]{1}-[1]{1})").matcher(desc);
		Matcher ma = Pattern.compile("([1]{1}-[1]{1}-[0]{1})").matcher(desc);
		Matcher mn = Pattern.compile("([1]{1}-[0]{1}-[1]{1})").matcher(desc);
		Matcher man = Pattern.compile("([1]{1}-[1]{1}-[1]{1})").matcher(desc);
//		indx=0;
		if (m.find()) {
//			allMatches.add(" Morning");
			mor=" Morning";
			count1++;
//			indx++;
		}
		else if (a.find()) {
//			allMatches.add(" Afternoon");
			aft=" Afternoon";
			count1++;
//			indx++;
		}
		else if (n.find()) {
//			allMatches.add(" Night");
			nyt=" Night";
			count1++;
//			indx++;
		}
		else if (mn.find()) {
//			allMatches.add(" Morning");
//			allMatches.add(" Night");
			mor=" Morning";
			nyt=" Night";
			count1++;
			count1++;
//			indx++;
		}
		else if (an.find()) {
//			allMatches.add(" Afternoon");
//			allMatches.add(" Night");
			aft=" Afternoon";
			nyt=" Night";
			count1++;
			count1++;
//			indx++;
		}
		else if (ma.find()) {
//			allMatches.add(" Morning");
//			allMatches.add(" Afternoon");
			mor=" Morning";
			aft=" Afternoon";
			count1++;
			count1++;
//			System.out.println(allMatches);
//			indx++;
		}
		else if (man.find()) {
//			allMatches.add(" Morning");
//			allMatches.add(" Afternoon");
//			allMatches.add(" Night");
			mor=" Morning";
			aft=" Afternoon";
			nyt=" Night";
			count1++;
			count1++;
			count1++;
//			indx++;
		}
//		return allMatches;
	}

	// delete tasks
	public String deletetask(int taskid) {
		String res = "failure";
		try {
		//get task details here
		String query1="select pat_id,med_name from task where task_id="+taskid;
		mConnection = DBConnection.getDBConnection();
		ps = mConnection.prepareStatement(query1);
		ResultSet rs22=ps.executeQuery();
		if(rs22.next())
		{
			int pid=rs22.getInt(1);
			String mname=rs22.getString(2);
			System.out.println(mname);
			String query2="select totalmedicines,med_frequency from tasktotal where pat_id='"+pid+"' and med_name='"+mname+"';";
			ps = mConnection.prepareStatement(query2);
			ResultSet rs23=ps.executeQuery();
			if(rs23.next())
			{
				int tm=rs23.getInt(1);
//				String fre=rs23.getString(2);
//				String mname=rs23.getString(3);
//				getNoon(fre);
//				tm =tm-count1;
//				System.out.println(mname+" "+pid);
				tm=tm-1;
				String query3="select med_availability from medicine where med_name='"+mname+"' and pat_id='"+pid+"' ;";
				ps = mConnection.prepareStatement(query3);
				ResultSet rs2a = ps.executeQuery();
				if(rs2a.next())
				{
				int rs11 = 0,rs12 = 0,rs13 = 0;
				String ma=rs2a.getString(1);
//				System.out.println(ma);
				int avail=Integer.parseInt(ma);
//				avail=avail-count1;
				avail=avail-1;
//				System.out.println(avail);
				query3 = "delete from task where task_id='" + taskid + "';";
				ps = mConnection.prepareStatement(query3);
				// Patient patient=null;
				// ps.setInt(1,patid);
				rs11 = ps.executeUpdate();
				if(tm>0)
				{
				query3="update tasktotal set totalmedicines="+tm+" where pat_id='"+pid+"' and med_name='"+mname+"';";
				ps = mConnection.prepareStatement(query3);
				rs12 = ps.executeUpdate();
				}
				else
				{
					query3="delete from tasktotal where totalmedicines="+tm+" and pat_id='"+pid+"' and med_name='"+mname+"';";
					ps = mConnection.prepareStatement(query3);
					int rs221 = ps.executeUpdate();
				}
				if(avail>0)
				{
				query3="update medicine set med_availability='"+avail+"' where pat_id='"+pid+"' and med_name='"+mname+"';";
				ps = mConnection.prepareStatement(query3);
				rs13 = ps.executeUpdate();
				}
				else if(tm<0)
				{
					query3="dalete from medicine where med_availability='"+avail+"' and pat_id='"+pid+"' and med_name='"+mname+"';";
					ps = mConnection.prepareStatement(query3);
					int rs223 = ps.executeUpdate();
				}
				if (rs11 == 1 && rs12 == 1 && rs13 == 1) {
					//done-decrement totalmedicines depends on frequency.... in query
					//done--decrement medavailablicty.....
					res = "success";
				}
				}
			}
		}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}

	// task at patient js should send pat_id and current date
	
	public List<Task> gettask(int pid)
	{
		List<Task> list=null;
		System.out.println(pid);
		String query = "select * from task where pat_id='"+pid+"';";
		Statement stmt1=null;
		try {		
			mConnection = DBConnection.getDBConnection();
			stmt1=mConnection.createStatement();
		ResultSet rs11 = stmt1.executeQuery(query);
//		if(rs11.next())
//		{
		list = convertPojoList1(rs11);
//		}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt1 != null) {
					stmt1.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public int getmediqty(int pid,String mname,String mdosage)
	{
		int res = 0,ttmedicines = 0,medavail = 0;
		String query = "select totalmedicines from tasktotal where pat_id='"+pid+"' and med_name='"+mname+"' and med_dosage='"+mdosage+"';";
		Statement stmt1=null,stmt2=null;
		try {		
			mConnection = DBConnection.getDBConnection();
			stmt1=mConnection.createStatement();
		ResultSet rs11 = stmt1.executeQuery(query);
		if(rs11.next())
		{
		ttmedicines=rs11.getInt(1);
		}
		stmt2=mConnection.createStatement();
		ResultSet rs12 = stmt2.executeQuery("select med_availability from medicine where pat_id='"+pid+"' and med_name='"+mname+"' and med_dosage='"+mdosage+"';");
		if(rs12.next())
		{
		medavail=rs12.getInt(1);
		}
		res=ttmedicines-medavail;
		System.out.println(res);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt1 != null) {
					stmt1.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
	
	public int gettotalmedicinesremain(int pid,String medname,String meddosage)
	{
		int res=0;
		String query = "select totalmedicines from tasktotal where pat_id='"+pid+"' and med_name='"+medname+"' and med_dosage='"+meddosage+"';";
		Statement stmt1=null,stmt2=null;
		try {		
			mConnection = DBConnection.getDBConnection();
			stmt1=mConnection.createStatement();
		ResultSet rs11 = stmt1.executeQuery(query);
		if(rs11.next())
		{
		res=rs11.getInt(1);
		}
		System.out.println(res);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt1 != null) {
					stmt1.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
}
