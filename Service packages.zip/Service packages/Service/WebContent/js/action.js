var ipaddr="http://192.168.10.33:8080/Service"; 
var myipaddr="http://ingbtcpic2nb3nb:8080/UIA/";
$(document).on('click', 'a.resize', function() {
		$cn = $('.container');
		var width = 600, onComplete;
		if (!$cn.data('fullWidth')) {
			$cn.data('fullWidth', $cn.width());
			$cn.css('maxWidth', $cn.width());
		} else {
			width = $cn.data('fullWidth');
			$cn.data('fullWidth', null);
			onComplete = function() {
				$cn.css('maxWidth', null);
			};
		}
		$cn.animate({
			maxWidth : width
		}, {
			complete : onComplete
		});
		$(window).trigger('resize');
		return false;
	});
$(function() {
	$('.tabcordion').tabcordion();
});
window.brunch = window.brunch || {};
window.brunch['auto-reload'] = {
	enabled : true
};
$("#taskmsg").hide();
function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
  }
return "";
}

function deletecookies(){
	var cookies = document.cookie.split(";");

	for (var i = 0; i < cookies.length; i++) {
		var cookie = cookies[i];
		var eqPos = cookie.indexOf("=");
		var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		window.location.replace(myipaddr);
	}
}
function sphomeopen()
{
window.open(serviceipaddr+"");
}
// $(document).ready(function() {
// $("#sphome").click(function(event){
// $("#col2").show();
// $("#noservice").hide();
// loc=ipaddr+"/Service/index.html";
// //checkloc(value.patId,value.medName);
// NoServices(loc,function(status){
// if((status == 200)){// dynamiciframe!= null
// $('#dynamiciframe').attr('src', loc);
// $("iframe").show();
// }
// else if(status == 404 || status == 503 ){
// // alertify.alert('<h1>Sorry, Service is not available for this
// profile</h1>');
// $("#noservice").show();
// $("#strt").hide();
// $("#jstorder").hide();
// }
// });
// });
// });
// config.EnableCors(new EnableCorsAttribute(Properties.Settings.Default.Cors,
// "", ""));
// app.UseCors(CorsOptions.AllowAll);
var patid,pid,patdob,patname;
var firsttime=0;
	 	$("#showTable").click(function(event){
	          getpatientdetails();
	      	resetservicedisplay();
	   });      
//	});
function getpatientdetails()
{
	resetservicedisplay();
	 $.get('rest/patient/'+patid,function(responseJson) {
         if(responseJson!=null){
             $("#patienttable").find("tr:gt(0)").remove();
             var table1 = $("#patienttable");
             $.each(responseJson, function(key,value) { 
             	pid=value.patId;
             	patname=value.patName;
             	patdob=value.patDob;
             	document.getElementById("paid").innerHTML=pid;
             	document.getElementById("paname").innerHTML=value.patName;
             	document.getElementById("dob").innerHTML=value.patDob;
             	document.getElementById("bg").innerHTML=value.patBloodGroup;
             	document.getElementById("addr").innerHTML=value.patAddress;
             	document.getElementById("cty").innerHTML=value.patCity;
             	document.getElementById("sta").innerHTML=value.patState;
             	document.getElementById("ph").innerHTML=value.patPhone;
             	document.getElementById("ei").innerHTML=value.patEmail;
             });
             }
         });
         $("#tablediv").show();
        // $("#col2").hide();
}
function checkcookie()
{
	patid=getCookie("patid");
		if(patid=='')
			{
			window.location.replace(myipaddr);
			}
		else
			{
			getpatientdetails();
			}
}
var medNam,medDosag,loc,medcount=0,qty,reqty=100,mededate;
//var theshold=31,;
$(document).ready(function() {
	// medname="medName",meddosage="medDosage";
	var not;
	resetservicedisplay();
	     $("#showMedication").click(function(event){
	    	 resetservicedisplay();
	    	 patdisease="";
	    	 patid=getCookie("patid");
	    	 medcount++;
	    	 var myth;
	           $.get('rest/medicine/'+patid,function(responseJson) {
	        	   iservice="Pharmacy";
	            if(responseJson!=null){
	                $("#medicinetable").find("tr:gt(0)").remove();
	                var table1 = $("#medicinetable");
	                var check=0;
	                $.each(responseJson, function(key,value) {
	                	qty=value.medAvail;
//	                	alert(qty);
	                	not=qty;
	                	myth=theshold;
                		mededate=value.medEndDate;
                		//alert(qty+" "+myth);
	                	//$("#col2").show();
	                	if(qty<myth)
	            		{
//	                		alert("inside condition thes");
	                		reqty=qty;
	                		medNam=value.medName;
	                		medDosag=value.medDosage;
	                		gettotalmedicine(patid,value.medName,value.medDosage);
//	                		getmedicinesno(patid,medNam,medDosag);
//	                		alert(reqty);
	            		}
	                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
// rowNew.children().eq(0).text(value['medId']);
// rowNew.children().eq(0).text(value['patId']);
	                        rowNew.children().eq(0).text(value['medName']); 
	                        rowNew.children().eq(1).text(value['medDosage']);
	                        rowNew.children().eq(2).text(value['medFrequency']);
	                        rowNew.children().eq(3).text(value['medStartDate']); 
	                        rowNew.children().eq(4).text(value['medEndDate']); 
	                        rowNew.children().eq(5).text(value['qty']); 
	                        rowNew.children().eq(6).text(value['medAvail']); 
	                        rowNew.appendTo(table1);
	                        //alert(mededate);
	                        getremainingdays(mededate);
//	                        alert(remaindays);
	                        $.notific8('Hi,	 Your '+medNam+' course will end in '+remaindays+' days' , {
	          	    		  life: 5000,
	          	    		  heading: 'Medication Course',
	          	    		  theme: 'amethyst',
	          	    		  horizontalEdge: 'bottom',
	          	    		  verticalEdge: 'right',
	          	    		  zindex: 1500
	          	    		});
	                        $("#tablediv2").show();
	                        if(reqty==100)
	                        	{
	                        	getmedserviceattri();
	                        	}
	                        if(reqty<myth)
		            		{
	                        	$("#col2").show();
		                		 $("#myservices").show();
		                		 $("#strt").show();
		                		 $("#cond").show();
	                        getserviceurl("Medication Supplier");
		            		}
	                        
	                });
	                $("#nothing").hide();
	                }
	            if(typeof not == 'undefined')
	            	{
	            	$("#col2").hide();
	            	$("#nothing").show();
            		$("#tablediv2").hide();
            		}
	            else if(qty>theshold) 
	            	{
	            	$("#col2").show();
	            	$("#myservices").show();
	            	$("#cond").show();
//	            	$("#ps").show();
	            	getmedserviceattri();
	            	}
	            });
	            // $("#tablediv2").show();
	  });      
	});

var iservice,inx;
function  getmedserviceattri()
{
	//set get request to getserviceattri service
//	xmlHttp  = GetXmlHttpObject();
//	var req_url = 'rest/patient/getserviceattri/Pharmacy';
//	SendAsync_GETRequest(xmlHttp,req_url,null,allattributes);
	resetservicedisplay();
	$("#col2").show();
	$("#strt").show();
	$("#cond").show();
	 $.get('rest/patient/getserviceattri/Pharmacy',function(responseJson) {
		 iservice="Pharmacy";
		 inx=0;
         if(responseJson!=null){
            // $("#plist").find("tr:gt(0)").remove(); //get the div where to display attributes
             var table1 = $("#plist"); //get the div where to display attributes
             var dispattri=$("<div></div>");
             var atvalue;
             $.each(responseJson, function(key,value) {
            	 atvalue=value.spAttri;
//            	 alert(atvalue);
            	 inx++;
            	 dispattri.append("<div><input type=\"button\" value=\""+value.spAttri+"\" id='med"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></div><hr />"); 
            	 dispattri.appendTo(table1);
             });
             $("#plist").show(); //get the div where to display attributes
             $("#ps").show();
         }
	 });
}


//dscnks' get getonediscount service to create with discount id and its description returning' and alseo check the ipaddr for required medication form its not coorect....
function getfitserviceattri(ct)
{
//	if(ct==1)
//		{
		resetservicedisplay();
		$("#col2").show();
		$("#strt").show();
		$("#cond").show();
	$.get('rest/patient/getserviceattri/Fitness',function(responseJson) {
		iservice="Fitness";
		inx=0;
        if(responseJson!=null){
        	//$("#hlist").find("tr:gt(0)").remove();//get the div where to display attributes
        	$("#hlist").empty();
            var table1 = $("#hlist"); //get the div where to display attributes
            var dispattri=$("<div></div>");
            var atvalue;
            $.each(responseJson, function(key,value) {
            	 atvalue=value.spAttri;
            	 inx++;
            	 if((patdisease=='heart ' && value.spAttri=='music') || (patdisease=='diabetic' && value.spAttri=='excersice ') || (patdisease=='heart ' || patdisease=='diabeties' && value.spAttri=='yoga') )
            	{
            		dispattri.append("<div>Special Service</div><hr>");
            	}
            	 dispattri.append("<div><input type=\"button\" value=\""+value.spAttri+"\" id='fit"+inx+"' width='100%' onclick=\"getserviceurl(this.value)\" /></div><hr />"); //.fit"+inx+"
            	 dispattri.appendTo(table1);
            });
            $("#hlist").show(); //get the div where to display attributes
            $("#hs").show();
        }
	 });
//		}
//	else
//		{
//	iservice="Fitness";
//	$("#hlist").hide();
//		}
		
}
var ex_date,discountderc;
function gettaskservice()
{
	//resetservicedisplay();
		$.get('rest/patient/getservicetask',function(responseJson) {
    if(responseJson!=null){
       // $("#dcdiv").find("tr:gt(0)").remove(); //get the div where to display attributes
//        var table1 = $("#dcdiv"); //get the div where to display attributes
//        var dispattri=$("<div></div>");
//        var dis;
        $.each(responseJson, function(key,value) {
        	discountderc=value.discount_desc;
       	 document.getElementById("discountders").innerHTML=value.discount_desc;
       	 document.getElementById("discountders").value=value.discount_id;
       	 document.getElementById("discountcode").innerHTML=value.discount_id;
       	 ex_date=value.expire_date;
        });
        $("#col2").show();
        $("#myservices").show();
        $("#strt").show();
        $("#taskcom").show();
        $("#dcdiv").show(); //get the div where to display attributes
        $("iframe").hide();
    }
});
}

var serviceipaddr;
function getserviceurl(attris) 
{
	//get router here.....
	
	xmlHttp  = GetXmlHttpObject();
//	alert(iservice+" "+attris);
	var req_url = 'rest/patient/getservice/'+iservice+'/'+attris;
	SendAsync_GETRequest(xmlHttp,req_url,null,singleurl);
}

function singleurl()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	// Json response
		if(json_resp!=null)
			{
			serviceipaddr=json_resp;
			 //display home page of the 3rd partiy service using serviceurl...
			if(reqty<theshold)
				{
				respipaddr=json_resp;
//				alert(respipaddr);
				loc=respipaddr+"/rest/medicationservice/imdjson/"+patname+"/"+medNam+"/"+medDosag;
//        		alert(loc);
        		getorderlist(loc);
        		reqty=100;
				}
			else if(patdisease!="")
        	{
				getfitnessservice();
				patdisease="";
        	}
			else
				{
				displayservice();
				}
			}
		else
			{
			alertify.alert("<h3>Service Not Found for this service type and attribute</h3>");
			}
	}
}
function resetservicedisplay()
{
	$("col2").hide();
	$("#myservices").hide();
	$("#strt").hide();
	$("#spserving").hide();
	$("#noservice").hide();
	$("#ps").hide();
	$("#hs").hide();
	$("#dc").hide();
	$("#om").hide();
	$("#plist").hide();
	$("#hlist").hide();
	$("#dcdiv").hide();
	$("#taskyet").hide();
	$("#taskcom").hide();
	$("#orderform").hide();
	$("#customo").hide();
	$("iframe").hide();
	$("#muteservice").hide();
	$("#demo").hide();
	$("#mapholder").hide();
	//$("#closeimage").hide();
}
function displayservice()
{
	resetservicedisplay();
	loc=serviceipaddr;
	NoServices(loc,function(status){
		if(status==204)
			{
			$('#dynamiciframe').attr('src', loc);
			$("iframe").show();
			}
		else if(status == 404 || status == 503){  // 503 Service Unavailable
			// alertify.alert('<h1>Sorry, Service is not available for this profile</h1>');
						$("#noservice").show();
						$("#strt").hide();
		}
     		 });
}
function getorderlist(locc)
{
	resetservicedisplay();
	$("#col2").show();
	$("#strt").show();
	$("#cond").show();
	$("#myservices").show();
	$("iframe").hide();
	NoServices(locc,function(status){
		var notg;
			 $.get(locc,function(rJson) {
  	            if(rJson!=null){
  	            	$.each(rJson, function(key,value) {
  	            		gettotalmedicine(patid,value.med_name,value.med_dosage);
  	            		notg=value.med_name;
  	            		//alert(value.ppname);
//  	            		alert(notg);
 	            		document.getElementById("ppname").value=patname;
	                	document.getElementById("mmname").value=value.med_name;
	                	document.getElementById("mdos").value=value.med_dosage;
	                	document.getElementById("price").value=value.med_price;
//	                	alert(value.med_price);
  	            	});
  	            	$("#strt").show();
  	            	$("#spserving").show();
  	            }
  	            else
  	            	{
  	            	notg=null;
  	            	}
     		 });
		//}
		if(notg==null)
			{
			$("#strt").show();
			}
		else if(status == 404 || status == 503){  // 503 Service Unavailable
// alertify.alert('<h1>Sorry, Service is not available for this profile</h1>');
			$("#noservice").show();
			$("#strt").hide();
		}
	});
}
var theshold=31;
function getmedication()
{
	resetservicedisplay();
	$.get('rest/medicine/'+patid,function(responseJson) {
		var myth;
        if(responseJson!=null){
            $("#medicinetable").find("tr:gt(0)").remove();
            var table1 = $("#medicinetable");
            iservice="Pharmacy";
            var check=0;
            $.each(responseJson, function(key,value) {
            	qty=value.medAvail;
            	not=qty;
            	myth=theshold;
            	if(qty<myth)
        		{
            		$("#col2").show();
            		$("#cond").show();
            		$("#myservices").show();
            		$("#strt").show();
            		$("#spserving").show();
            		reqty=qty;
            		medNam=value.medName;
            		medDosag=value.medDosage;
            		mededate=value.medEndDate;
//            		getmedicinesno(patid,medNam,medDosag);
            		gettotalmedicine(patid,value.medName,value.medDosage);
        		}
        		
                 var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
                 // rowNew.children().eq(0).text(value['medId']);
                 // rowNew.children().eq(0).text(value['patId']);
                    rowNew.children().eq(0).text(value['medName']); 
                    rowNew.children().eq(1).text(value['medDosage']);
                    rowNew.children().eq(2).text(value['medFrequency']);
                    rowNew.children().eq(3).text(value['medStartDate']); 
                    rowNew.children().eq(4).text(value['medEndDate']); 
                    rowNew.children().eq(5).text(value['qty']); 
                    rowNew.children().eq(6).text(value['medAvail']); 
                    rowNew.appendTo(table1);
                    $("#tablediv2").show();
                    getremainingdays(mededate);
//                    alert(remaindays);
                    $.notific8('Hi Your '+medNam+' course will end in next '+remaindays+' days' , {
      	    		  life: 5000,
      	    		  heading: 'Medication Course Duration',
      	    		  theme: 'amethyst',
      	    		  horizontalEdge: 'bottom',
      	    		  verticalEdge: 'right',
      	    		  zindex: 1500
      	    		});
            });
//            $("iframe").show();
            if(reqty<myth)
    		{
            getserviceurl("Medication Supplier");
//            $("#ps").show();
    		}
            $("nothing").hide();
            $("#orderform").hide();
            if(qty>theshold)
    		{
            	getmedserviceattri();
    		}
            }
        if(typeof not == 'undefined')
        	{
        	$("#nothing").show();
    		$("#tablediv2").hide();
    		}
        });
}

var remaindays;

function getremainingdays(edate)
{
	var currentdate=getdate();
	 //Total time for one day
    var one_day=1000*60*60*24; 
//    alert(currentdate+" "+edate);
//Here we need to split the inputed dates to convert them into standard format
    var x=edate.split("-");     
    var y=currentdate.split("-");

    var date1=new Date(x[0],(x[1]-1),x[2]);

    var date2=new Date(y[2],(y[0]-1),y[1]);
    var month1=x[1]-1;
    var month2=y[0]-1;
    
    //Calculate difference between the two dates, and convert to days
           
    remaindays=Math.ceil((date1.getTime()-date2.getTime())/(one_day)); 
//	alert(remaindays);
}
var respipaddr;

function settingspurl()
{
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText; 
		json_resp=respiaddr;
	}
	else
		{
		alertify.alert("<h3>Server not Responding</h3>");
		}
}
function gettpriceg()
{
	var mediname=document.getElementById("mmnameg").value;
	var medidos=document.getElementById("mdosg").value;
	$.get(respipaddr+"/rest/medicationservice/setprice/"+mediname+"/"+medidos,function(rJson) {
          if(rJson!=null){
          	$.each(rJson, function(key,value) {
          		document.getElementById("priceg").value=value.med_price;
          	});
          }
          	});
}
function gettotal()
{
	var mediqty=document.getElementById("mqtyg").value;
	var uprice=document.getElementById("priceg").value;
	document.getElementById("tpriceg").value=mediqty*uprice;
}
function gettprice()
{
	var qqty=document.getElementById("mqty").value;
//	alert(qqty);
	var uprice=document.getElementById("price").value;
//	alert(uprice);
	document.getElementById("tprice").value=qqty*uprice;
}
function suborder()
{
	validateorder();
	
}
function validateorder()
{
	var a=validateopname();
	var b=validateomedname();
	var c=validateomeddosage();
	var d=validatemedoqty();
	var e=validateotprice();
	if(a == true || b == true || c == true || d == true || e == true)
		{
		insertorder();
		}
	else
		{
		alertify.alert("<h3>All the fields are compulsory</h3>");
		return false;
		}
}

function insertorderg()
{
	var formData = form2object('fgo', '.', true, function(node) {
		if (node.id && node.id.match(/ggg/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	var json = JSON.stringify(formData, null, '\t');
// alert(json);
	result = json;
	sendorder();
}

function insertorder()
{
	var formData = form2object('fo', '.', true, function(node) {
		if (node.id && node.id.match(/ooo/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	var json = JSON.stringify(formData, null, '\t');
// alert(json);
	result = json;
	sendorder();
}
var result;
function sendorder()
{
	xmlHttp = GetXmlHttpObject();
	var req_url = serviceipaddr+'/rest/medicationservice/orderinsert';
	var params = result;
// alert(result);
	SendAsync_PostRequest(xmlHttp, req_url, params, order_resp);
}

function order_resp()
{
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText;
		if(json_resp!=null)
			{
				alertify.alert("<h3>order placed successfully, your order id is:"+json_resp+"</h3>");
				if(medcount>0){
				//getmedication();
				}
			}
		else
		{
			alertify.alert("<h3>Order not placed internal server error<br>sorry, we will repair it shortly sorry, for the inconvience, thank you</h3>");
		}
	}
}
function validateopname()
{
	var ppname=document.getElementById("ppname").value;
	if(ppname !="" || ppname !=null)
		{
		alertify.alert("<h3>please enter patient name</h3>");
		return false;
		}
	return true;
}

function validateomedname()
{
	var ppname=document.getElementById("mmname").value;
	if(ppname !="" || ppname !=null)
		{
		alertify.alert("<h3>please enter medication name</h3>");
		return false;
		}
	return true;
}
function validateomeddosage()
{
	var ppname=document.getElementById("mdos").value;
	if(ppname !="" || ppname !=null)
		{
		alertify.alert("<h3>please enter medicine dosage</h3>");
		return false;
		}
	return true;
}
function validatemedoqty()
{
	var ppname=document.getElementById("mqty").value;
	if(ppname !="" || ppname !=null)
		{
		alertify.alert("<h3>please enter medicine quantity</h3>");
		return false;
		}
	return true;
}
function validateotprice()
{
	var ppname=document.getElementById("tprice").value;
	if(ppname !="" || ppname !=null)
		{
		alertify.alert("<h3>please enter quantity to get total price</h3>");
		return false;
		}
	return true;
}
var cdate,todaytaskcount=0;
$(document).ready(function() {
	 $("#tablediv3").hide();
	 $("#nothing1").hide();
	 var not;
	     $("#showTask").click(function(event){
	    	 $("#taskmsg").hide();
	    	 resetservicedisplay();
    		 //gettaskservice();
	    	 if(todaytaskcount==0)
	    		 {
	    		 todaytaskcount++;
	    	 patid=getCookie("patid");
	    	 cdate=getdate();
	           $.get('rest/task/'+patid+'/'+cdate,function(responseJson) {
	            if(responseJson!=null){
	                $("#tasktable").find("tr:gt(0)").remove();
	                var table1 = $("#tasktable");
	                $.each(responseJson, function(key,value) {
	                	not=value.taskId;
	                     var rowNew = $("<tr><td></td><td></td></tr>");
// rowNew.children().eq(0).text(value['taskId']);
// rowNew.children().eq(0).text(value['patId']);
	                        rowNew.children().eq(0).text(value['taskDescription']); 
	                        rowNew.children().eq(1).text(value['status']); 
	                        rowNew.append("<td><input type='button' value='Done' width='100%' id='drod' onclick='deletetask("+value.taskId+")'>");
	                        rowNew.appendTo(table1);
	                        $("#tablediv3").show();
	                });
	                }
	            if(typeof not == 'undefined')
            	{
            	$("#nothing1").show();
            	gettaskservice();
        		}
	            else{
	            	 $("#col2").show();
	            	 $("#myservices").show();
	            	$("#dc").show(); 
	            	$.notific8('Hi buddy,Special discount is waiting for you.Complete your tasks to grab the offer ', {
		  	    		  life: 5000,
		  	    		  heading: 'Discount Offer',
		  	    		  theme: 'ruby',
		  	    		  horizontalEdge: 'bottom',
		  	    		  verticalEdge: 'right',
		  	    		  zindex: 1500
		  	    		});
		    	 }
	            });
	    		 }
	  });      
	});

function getdate()
{
	var today = new Date();
	var dd = today.getDate();
	var mm = today.getMonth()+1; // January is 0!
	var yyyy = today.getFullYear();

	if(dd<10) {
	    dd='0'+dd;
	} 

	if(mm<10) {
	    mm='0'+mm;
	} 

	today = mm+'-'+dd+'-'+yyyy;
	return today;
}

function deletetask(tid)
{
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/patient/deletetask/'+tid;
	SendAsync_GETRequest(xmlHttp,req_url,null,conformdeleted);
}

function conformdeleted()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	// Json response
		if(json_resp!=null)
			{
			alertify.alert("<h3>Task Completed</h3>");
			gettasks();
			}
		else
			{
			alertify.alert("<h3>Wrong Operation</h3>");
			}
	}
}

function gettasks()
{
	var not;
	//resetservicedisplay();
	$.get('rest/task/'+patid,function(responseJson) {
		$("#col2").show();
		$("#myservices").show();
		$("#strt").show();
		$("#cond").show();
		$("#taskcom").show();
        if(responseJson!=null){
            $("#tasktable").find("tr:gt(0)").remove();
            var table1 = $("#tasktable");
            //gettaskservice();
            $.each(responseJson, function(key,value) {
            	not=value.taskId;
                 var rowNew = $("<tr><td></td><td></td></tr>");
// rowNew.children().eq(0).text(value['taskId']);
// rowNew.children().eq(0).text(value['patId']);
                    rowNew.children().eq(0).text(value['taskDescription']); 
                    rowNew.children().eq(1).text(value['status']); 
                    rowNew.append("<td><input type='button' value='Done' id='drod' width='100%' onclick='deletetask("+value.taskId+")'>");
                    rowNew.appendTo(table1);
                    $("#tablediv3").show();
            });
            }
        if(typeof not == 'undefined')
    	{
    	$("#nothing1").show();
		$("#tablediv3").hide();
		gettaskservice();
		}
        });
}
var docid,docname;
$(document).ready(function() {
	 $("#tablediv4").hide();
	  $("#nothing2").hide();
	  $("#addsuccess").hide();
	 var not;
	     $("#showSp").click(function(event){
	    	 resetservicedisplay();
	    	 patid=getCookie("patid");
	           $.get('rest/appointment/'+patid,function(responseJson) {
	            if(responseJson!=null){
	                $("#sptable").find("tr:gt(0)").remove();
	                var table1 = $("#sptable");
	                $.each(responseJson, function(key,value) { 
	                	not=value.appointId;
	                	docid=value.docId;
	                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td></tr>");
// rowNew.children().eq(0).text(value['appointId']);
// rowNew.children().eq(1).text(value['patId']);
// rowNew.children().eq(0).text(value['docId']);
	                     	rowNew.children().eq(0).text(value['docName']);
	                        rowNew.children().eq(1).text(value['appointDersc']);
	                        rowNew.children().eq(2).text(value['appointTimming']); 
	                        rowNew.children().eq(3).text(value['appointDate']); 
	                        rowNew.children().eq(4).text(value['appointStatus']);
	                        rowNew.append("<td><input type='button' value='Delete Record' id='drod' width='100%' onclick='deleteappointment("+value.appointId+")'>");
	                        rowNew.appendTo(table1);
	                        $("#tablediv4").show();          
	                });
	                }
	            
	            if(typeof not == 'undefined')
            	{
            	$("#nothing2").show();
        		$("#tablediv4").hide();
        		}
	            });
	  });      
	});

function deleteappointment(appoid)
{
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/patient/deleteappointment/'+appoid;
	SendAsync_GETRequest(xmlHttp,req_url,null,conformdelete);
}

function conformdelete()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	// Json response
		if(json_resp!=null)
			{
			alertify.alert("<h3>Deleted the Appointment</h3>");
			getappoints();
			}
		else
			{
			alertify.alert("<h3>Wrong Operation</h3>");
			}
	}
}

function getappoints()
{
	resetservicedisplay();
	$.get('rest/appointment/'+patid,function(responseJson) {
        if(responseJson!=null){
            $("#sptable").find("tr:gt(0)").remove();
            var table1 = $("#sptable");
            $.each(responseJson, function(key,value) { 
            	not=value.appointId;
            	docid=value.docId;
                 var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td></tr>");
// rowNew.children().eq(0).text(value['appointId']);
// rowNew.children().eq(1).text(value['patId']);
// rowNew.children().eq(0).text(value['docId']);
                 	rowNew.children().eq(0).text(value['docName']);
                    rowNew.children().eq(1).text(value['appointDersc']);
                    rowNew.children().eq(2).text(value['appointTimming']); 
                    rowNew.children().eq(3).text(value['appointDate']); 
                    rowNew.children().eq(4).text(value['appointStatus']);
                    rowNew.append("<td><input type='button' value='Delete Record' id='drod' width='100%' onclick='deleteappointment("+value.appointId+")'>");
                    rowNew.appendTo(table1);
                    $("#tablediv4").show();          
            });
            }
        $("#nothing").hide();
        $("#addsuccess").hide();
        if(typeof not == 'undefined')
    	{
    	$("#nothing2").show();
		$("#tablediv4").hide();
		}
        });
}
function SendAsync_GETRequest(post_xmlHttp, post_url, post_params, resFunction)
{
  try
  {
      post_xmlHttp.onreadystatechange = resFunction;
     // post_url = post_url.replace(/\|/g, "%7C");
      post_xmlHttp.open("GET",post_url,true);
      post_xmlHttp.setRequestHeader("Content-type", "application/json");
      // post_xmlHttp.setRequestHeader("Content-length", post_params.length);
      // post_xmlHttp.setRequestHeader("Connection", "close");
      post_xmlHttp.send();
  }
  catch(e)
  {
	  alertify.alert('<h4>Server is not Responding... some Problem in server</h4>');
  }
}
var patdisease,sts;
$(document).ready(function(){
	 $("#tablediv5").hide();
	 var not,ct=0;
     $("#showPR").click(function(event){
    	 resetservicedisplay();
    	 $("#col2").hide();
    	 $("#nothing3").hide();
    	 $("#noservice").hide();
    	 $("iframe").hide();
//    	 $("#orderform").hide();
    	 patid=getCookie("patid");
    	 ct++;
    	 getfitserviceattri(ct);
           $.get('rest/patient/patientrecord/'+patid,function(responseJson) {
            if(responseJson!=null){
                $("#prtable").find("tr:gt(0)").remove();
                var table1 = $("#prtable");
                $.each(responseJson, function(key,value) { 
                	not = value.pr_id;
                	sts=value.status;
                	patdisease=value.disease;
                     var rowNew = $("<tr><td></td><td></td><td></td><td></td></tr>");
                     	rowNew.children().eq(0).text(value['docName']);
                        rowNew.children().eq(1).text(value['symtoms']);
                        rowNew.children().eq(2).text(value['disease']); 
                        rowNew.children().eq(3).text(value['status']); 
                        rowNew.appendTo(table1);
                });
                }
            if(typeof not == 'undefined')
        	{
            $("#col2").hide();
        	$("#nothing3").show();
    		$("#tablediv5").hide();
    		}
            else 
            	{
            	 $("#tablediv5").show();
                 $("#col2").show();
                 $("#myservices").show();
                 $("#strt").show();
                 $("#hs").show();
            	}
            
            });
  });    
});

function getfitnessservice()
{
	//getfitserviceattri();
	if(sts=='Critical' || sts=='Normal' || sts=='First Stage' || sts=='2nd stage')
	{
	//getserviceurl("Fitness tips");
	myAgeValidation();
	resetservicedisplay();
    $("#col2").show();
    $("#myservices").show();
    $.notify("New Service");
//    alert(serviceipaddr);
		loc=serviceipaddr+"/abc.html?patid="+patid+"&patage="+age+"&patdisease="+patdisease+"&patname="+patname; // service name on of them /FitnessService
		// checkloc(value.patId,value.medName);
		NoServices(loc,function(status){
			if((status == 200)){// dynamiciframe!= null
				$('#dynamiciframe').attr('src', loc);	
//				alert("opening iframe");
				$("#strt").show();
				$("iframe").show();
			}
			else if(status == 404 || status == 503){  
//				alert("i am here");
				$("#noservice").show();
			}
		});
		}
	else
		{
		//patdisease=value.disease;
		//getserviceurl("Fitness tips");
//		alert("i am in else");
		resetservicedisplay();
    	myAgeValidation();
        $("#col2").show();
        $("#myservices").show();
    		loc=serviceipaddr+"/abc.html?patage="+age+"&patdisease="+patdisease;
    		NoServices(loc,function(status){
    			if(status == 200){
    				$('#dynamiciframe').attr('src', loc);	
                    $("iframe").show();
    			}
    			else if(status == 404 || status == 503 ){
                    $("#strt").show();
    				$("#noservice").show();
    			}
    		});
		}
}

$(document).ready(function(){
	$("#showAP").click(function(event){
		resetservicedisplay();
	});
});

$(document).ready(function(){
	$("#showDR").click(function(event){
		resetservicedisplay();
	});
});
var spname;
$(document).ready(function(){
	 $("#tablediv6").hide();
	 $("#nothing4").hide();
//	 $("#orderform").hide();
	 var nots;
    $("#showOR").click(function(event){
//    	alert("inside order table");
    	resetservicedisplay();
    	$("#col2").show();
    	$("#myservices").show();
   	 patid=getCookie("patid");
   	 //ToDo:we need to change to service url dyanmically to get all orders of the patient with differnt service provider....
   	 $("iframe").hide();
   	$("#strt").show();
   	$("#cond").show();
   	 $("#om").show();
   	 $("#orderform").show();
//   	 $("#orderform").show();
   	$.get(myipaddr+"rest/patient/getallspurl",function(rJson) {
   		
   		$.each(rJson, function(key,value) {
   			spname=value.spName;
   		 ipaddr=value.spUrl;
   		 
          $.get(ipaddr+"/rest/medicationservice/orderedlist/"+patname,function(responseJson) {
           if(responseJson!=null){
               $("#ordertable").find("tr:gt(0)").remove();
               var table1 = $("#ordertable");
               $.each(responseJson, function(key,value) { 
            	   nots = value.o_id;
                    var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
                       rowNew.children().eq(0).text(value['o_id']); 
                       rowNew.children().eq(1).text(value['pat_name']);
                       rowNew.children().eq(2).text(value['med_name']);
                       rowNew.children().eq(3).text(value['med_dosage']);
                       rowNew.children().eq(4).text(value['med_quantity']); 
                       rowNew.children().eq(5).text(value['med_price']); 
                       rowNew.children().eq(6).text(value['status']); 
                       rowNem.children().eq(7).text(spname);
                       rowNew.appendTo(table1);
                       $("#tablediv6").show();
               });
               }
           if(typeof nots == 'undefined')
       		{
        	   $("#nothing4").show();
        	   $("#tablediv6").hide();
       		}
           });
   	 });
   	});
 });    
});

function checkloc(patid,medname){
	xmlHttp = GetXmlHttpObject();
	var req_url = serviceipaddr+"/rest/medicationservice/checkreqmedicine/"+patid+"/"+medname;
	// var params = result;
	SendAsync_GetRequest(xmlHttp, req_url,null,check_resp);
}

function check_resp() {
	var loc=null;
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText; // Json response
			if (json_resp=='0') {
				loc = serviceipaddr+"/rest/medicationservice/imd/"+ medNam + "/" + medDosag;
				NoServices(loc,function(status){
        			if(status == 200){
        				$('#dynamiciframe').attr('src', loc);		
        			}
        			else if(status == 404  || status == 503){
// alertify.alert('<h1>Sorry, Service is not available for this profile</h1>');
        				$("#noservice").show();
//        				$("#strt").hide();
        			}
        		});
			} else {
				loc = serviceipaddr+"";
				NoServices(loc,function(status){
        			if(status == 200){
        				$('#dynamiciframe').attr('src', loc);		
        			}
        			else if(status == 404 || status == 503){ 
// alertify.alert('<h1>Sorry, Service is not available for this profile</h1>');
        				$("#noservice").show();
//        				$("#strt").hide();
        			}
        		});


			}
	}
	else
		{
		getPharmaService();
		}
// $('#dynamiciframe').attr('src', loc);
}

function SendAsync_GetRequest(post_xmlHttp, post_url, post_params, resFunction) {
	try {
		post_xmlHttp.onreadystatechange = resFunction;
		// post_url = post_url.replace(/\|/g, "%7C");
		post_xmlHttp.open("GET", post_url, true);
		post_xmlHttp.setRequestHeader("Content-type", "application/json");
		// post_xmlHttp.setRequestHeader("Content-length", post_params.length);
		// post_xmlHttp.setRequestHeader("Connection", "close");
		post_xmlHttp.send();
	} catch (e) {
		alertify.alert('<h3> Server is not Responding... some Problem in server</h3>');
	}
}

function chide()
{
	$("#tablediv3").hide();
	$("#taskmsg").show();
}

function setCookie(cname,cvalue,exdays)
{
	// deleteAllCookies();
var d = new Date();
d.setTime(d.getTime()+(exdays*24*60*60*1000));
var expires = "expires="+d.toGMTString();
document.cookie = cname + "=" + cvalue + "; " + expires;
}


$(document).ready(function(){
	resetservicedisplay();
	 $("#docname").show();
	 $("#deptdiv").hide();
	 $("#tablediv7").hide();
	 $("#docname").hide();
	 $("#noth").hide();
	 $("#appform").hide();
	 $("#showDR").click(function(event){
	resetservicedisplay();
	$("#searchdiv").show();
		 // $("#docser").show();
	$("#btnname").show();
	$("#hidespec").show();
});
});

$(document).ready(function(){
	 $("#showAP").click(function(event){
		 resetservicedisplay();
	$("#appointdiv8").show();
// getpatnam(patid);
// repeat();
	document.form1.patId.value=patname;
});
});

function showappoint(ddname,dddid)
{
	mydid=dddid;
	$("#searchdiv").hide();
	$("#appform").show();
// $("#appbtn").hide();
	// $("#sptable").show();
	// $("#appointdiv8").show();
	// $("#docser").hide();
	document.form2.patId.value=patname;
	document.form2.docId.value=ddname;
}
// $(document).ready(function(){
// $("#appoint").onclick(function(event){
// $("#sptable").show();
// $("#appointdiv8").hide();
// $("#searchdiv").hide();
// document.form1.patId.value=pid;
// document.form1.docId.value=docid;
// });
// });
// var docid;
// function shows()
// {
// $("#spec").show();
// $("#docname").hide();
// $("#dept").hide();
// }
//
// function showd()
// {
// $("#dept").show();
// $("#docname").hide();
// $("#spec").hide();
// }
// function test11()
// {
// var search=document.formss.dname.value;
// test1(search);
// }

var mydid;

function test12(spec,dept)
{
	if(spec==null || spec=='')
	{
	alertify.alert("<h3>please specify one of the specilization values</h3>");
	return false;
	}
	else if(dept==null || dept=='')
		{
		alertify.alert("<h3>please specify one of the department values</h3>");
		return false;
		}
	else
	{
		var not;
	$.get('rest/patient/searchdocs/'+spec+'/'+dept,function(responseJson) {
        if(responseJson!=null){
            $("#searchtable").find("tr:gt(0)").remove();
            var table1 = $("#searchtable");
            $.each(responseJson, function(key,value) { 
            	var dname1,ddid;
            	not =value.doc_id;
                 var rowNew = $("<tr><td></td><td></td></tr>");
                mydid=value.doc_id;
                docname=value.doc_name;
                dname1=docname;
                ddid=mydid;
                    rowNew.children().eq(0).text(value['doc_id']); 
                    rowNew.children().eq(1).text(value['doc_name']);
                    rowNew.append("<input type='button' value='appointment request' width='100%' onclick=\"showappoint('"+dname1+"','"+ddid+"')\">");
                    rowNew.appendTo(table1);
                    $("#tablediv7").show();
                    $("#searchdiv").hide();
// $("#appform").show();
                    $("#noth").hide();
            });
            }
        if(typeof not == 'undefined')
        	{
        	$("#noth").show();
        	$("#tablediv7").hide();
        	$("#hidespec").show();
        	$("#deptdiv").hide();
        	$("#searchdiv").show();
// $("#hidespec").hide();
        	}
        });
	}
}
function test01(search)
{
// $("#deptdiv").show();
	if(search==null || search=='')
		{
		alertify.alert("<h3>please specify one of the specialization values</h3>");
		return false;
		}
	else
		{
		var not;
	$.get('rest/patient/doctorsearch/'+search,function(responseJson) {
        if(responseJson!=null){
            $("#searchtable").find("tr:gt(0)").remove();
            var table1 = $("#searchtable");
            $.each(responseJson, function(key,value) { 
            	not =value.doc_id;
                 var rowNew = $("<tr><td></td><td></td></tr>");
                mydid=value.doc_id;
                docname=value.doc_name;
                var ddid=mydid;
                var dname1=docname;
                    rowNew.children().eq(0).text(value['doc_id']); 
                    rowNew.children().eq(1).text(value['doc_name']);
                    rowNew.append("<input type='button' value='appointment request' width='100%' onclick=\"showappoint('"+dname1+"','"+ddid+"')\">");
                    rowNew.appendTo(table1);
                    $("#tablediv7").show();
                    $("#searchdiv").show();
                    $("#deptdiv").show();
// $("#appbtn").show();
                    $("#noth").hide();
            });
            }
        if(typeof not == 'undefined')
        	{
        	$("#noth").show();
        	$("#tablediv7").hide();
        	$("#hidespec").show();
        	$("#deptdiv").hide();
        	$("#searchdiv").show();
// $("#hidespec").hide();
        	}
        
        });
// if(docid==null)
// {
// alert("Sorry,No Such Specilization");
// return false;
// }
		}
        return true;
}
function test1(search)
{
	// var search=document.getElementById("spec").value;
// $("#deptdiv").show();
	if(search==null || search=='')
		{
		alertify.alert("<h3>please specify one of the values</h3>");
		return false;
		}
	else
		{
		var not;
	$.get('rest/patient/doctorsearch/'+search,function(responseJson) {
        if(responseJson!=null){
            $("#searchtable").find("tr:gt(0)").remove();
            var table1 = $("#searchtable");
            $.each(responseJson, function(key,value) { 
            	not =value.doc_id;
                 var rowNew = $("<tr><td></td><td></td></tr>");
                mydid=value.doc_id;
                var ddid=mydid;
                docname=value.doc_name;
                var dname1=docname;
                    rowNew.children().eq(0).text(value['doc_id']); 
                    rowNew.children().eq(1).text(value['doc_name']);
                    rowNew.append("<input type='button' value='appointment request' width='100%' onclick=\"showappoint('"+dname1+"','"+ddid+"')\">");
                    rowNew.appendTo(table1);
                    $("#tablediv7").show();
                    $("#searchdiv").hide();
                    $("#noth").hide();
            });
            }
        if(typeof not == 'undefined')
        	{
        	$("#noth").show();
        	$("#tablediv7").hide();
        	$("#hidespec").show();
        	$("#deptdiv").hide();
        	$("#searchdiv").show();
// $("#hidespec").hide();
        	}
        
        });
		}
        return true;
}

function validatepatid()
{
	var num=document.form1.patId;
	if((num.value==null)||(num.value=="")){
		alertify.alert("<h3>Please Enter patient id</h3>");
		num.focus();
		return false;
	}
	return true;
}

function validatedocid()
{
	var num=document.form1.docId;
	if((num.value==null)||(num.value=="")){
		alertify.alert("<h3>Please Enter doctor id</h3>");
		num.focus();
		return false;
	}
	
	return true;
}

function validatedersc()
{
	var name=document.form1.appointDersc;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter Appointment Description field</h3>");
		name.focus();
		return false;
	}
	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets with space allowed</h3>');
		name.focus;
		return false;
		}
	return true;
}

function validatetimming()
{
	var num=document.form1.appointTimming;
	if((num.value==null)||(num.value=="")){
		alertify.alert("<h3>Please Enter timming</h3>");
		num.focus();
		return false;
	}
// var filter=/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/;
// if(!filter.test(num.value))
// {
// alertify.alert('Please provide 24 timming format-HH:MM');
// num.focus;
// return false;
// }
// return true;
	return true;
}

function validatedate()
{
	var dob=document.form1.appointDate;
	if((dob.value==null)||(dob.value==""))
	{
		alertify.alert("<h3>Please Enter date MM/DD/YY</h3>");
		dob.focus();
		return false;
	}
	return true;
}

function validatestatus()
{
	var name=document.form1.appointStatus;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h3>Please Enter Status field</h3>");
		name.focus();
		return false;
	}
	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h3>Please provide only aphabets with space allowed</h3>');
		name.focus;
		return false;
		}
	return true;
}
function validateall()
{
	var a=validatepatid();
	var b=validatedocid();
	var c=validatedersc();
	var d=validatetimming();
	var e=validatedate();
	// var f=validatestatus();
	if(a==true && b==true && c==true && d==true && e==true)
		{
		appointcall();
		}
	else
		{
		alertify.alert("<h3>all the fields are compulsory</h3>");
		return false;
		}
	return true;
}

function appointcall1()
{
	document.getElementById("ppid").value=patid;
	document.getElementById("ddid").value=mydid;
	var formData = form2object('ff', '.', true, function(node) {
		if (node.id && node.id.match(/zzz/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	var json = JSON.stringify(formData, null, '\t');
// alert(json);
	result = json;
	registerappoint();
}
// var did;
function appointcall()
{
	document.getElementById("patid1").value=pid;
	var dname=document.getElementById("docid1").value;
	mydocids(dname);
	
}
function sendjson()
{
	var formData = form2object('f', '.', true, function(node) {
		if (node.id && node.id.match(/qqq/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	var json = JSON.stringify(formData, null, '\t');
// alert(json);
	result = json;
	registerappoint();
} 
function registerappoint()
{
	xmlHttp = GetXmlHttpObject();
	var req_url = 'rest/patient/appointinsert';
	var params = result;
	SendAsync_PostRequest(xmlHttp, req_url, params, registration_resp);
}

function mydocids(dname)
{
	xmlHttp = GetXmlHttpObject();
	var req_url = 'rest/patient/docid/'+dname;
	SendAsync_GetRequest(xmlHttp, req_url, null, myres);
}
var xmlHttp;
function myres()
{
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText;
// did=json_resp;
// alert(json_resp);
// document.form1.docId.value=json_resp;
		document.getElementById("docid1").value=json_resp;
		sendjson();
	}
	
}

function registration_resp() {
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText; // Json response
		if (json_resp != null) {
			alertify.alert("<h3>Apoointment Request sent to Doctor.. <br>Doctor Repley, is  Displayed in the status of your appointment List.</h3>");
			document.form1.patId.value='';
			document.form1.docId.value='';
			document.form1.appointDersc.value='';
			document.form1.appointDate.value='';
			document.form1.appointTimming.value='';
			document.form1.appointStatus.value='';
			$("#disdate").val('');
		}
	}
}


function SendAsync_PostRequest(post_xmlHttp, post_url, post_params, resFunction) {
	try {
		post_xmlHttp.onreadystatechange = resFunction;
		// post_url = post_url.replace(/\|/g, "%7C");
		post_xmlHttp.open("POST", post_url, true);
		post_xmlHttp.setRequestHeader("Content-type", "application/json");
		// post_xmlHttp.setRequestHeader("Content-length", post_params.length);
		// post_xmlHttp.setRequestHeader("Connection", "close");
		post_xmlHttp.send(post_params);
	} catch (e) {
		alertify.alert('<h3>Server is not Responding... some Problem in server</h3>');
	}
}
function SendAsync_GetRequest(post_xmlHttp, post_url, post_params, resFunction) {
	try {
		post_xmlHttp.onreadystatechange = resFunction;
		// post_url = post_url.replace(/\|/g, "%7C");
		post_xmlHttp.open("GET", post_url, true);
		post_xmlHttp.setRequestHeader("Content-type", "application/json");
		// post_xmlHttp.setRequestHeader("Content-length", post_params.length);
		// post_xmlHttp.setRequestHeader("Connection", "close");
		post_xmlHttp.send();
	} catch (e) {
		alertify.alert('<h3>Server is not Responding... some Problem in server</h3>');
	}
}

function GetXmlHttpObject() {

	var xmlHttp = null;
	try {
		// Firefox, Opera 8.0+, Safari
		xmlHttp = new XMLHttpRequest();

	} catch (e) {
		// Internet Explorer
		try {
			xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}

	return xmlHttp;
}
function NoServices(url,cb)
{
	jQuery.ajax({
	url: url,
	datatype: 'text',
	type: 'GET',
	complete: function(xhr){
		if(typeof cb == 'function')
			cb.apply(this,[xhr.status]);
	}
	
	});
}	

function myAgeValidation() {
	 
    var lre = /^\s*/;
    var datemsg = "";
    
    var inputDate = patdob;
    inputDate = inputDate.replace(lre, "");
// document.as400samplecode.myDate.value = inputDate;
    datemsg = isValidDate(inputDate);
        if (datemsg != "") {
            alertify.alert(datemsg);
        }
        else {
            // Now find the Age based on the Birth Date
//        	alert(inputDate);
            getAge(new Date(inputDate));
        }
}
 var age;
function getAge(birth) {
 
    var today = new Date();
    var nowyear = today.getFullYear();
    var nowmonth = today.getMonth();
    var nowday = today.getDate();
 
    var birthyear = birth.getFullYear();
    var birthmonth = birth.getMonth();
    var birthday = birth.getDate();
 
    age = nowyear - birthyear;
    var age_month = nowmonth - birthmonth;
    var age_day = nowday - birthday;
    
    if(age_month < 0 || (age_month == 0 && age_day <0)) {
            age = parseInt(age) -1;
        }
// alert(age);
    
// if ((age == 18 && age_month <= 0 && age_day <=0) || age < 18) {
// }
// else {
// alert("You have crossed your 18th birthday !");
// }
}
 
function isValidDate(dateStr) {
 
    
    var msg = "";
    // Checks for the following valid date formats:
    // MM/DD/YY MM/DD/YYYY MM-DD-YY MM-DD-YYYY
    // Also separates date into month, day, and year variables
 
    // To require a 2 & 4 digit year entry, use this line instead:
    // var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{2}|\d{4})$/;
    // To require a 4 digit year entry, use this line instead:
    var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{4})$/;
 
    var matchArray = dateStr.match(datePat); // is the format ok?
    if (matchArray == null) {
        msg = "Date is not in a valid format.";
        return msg;
    }
 
    month = matchArray[1]; // parse date into variables
    day = matchArray[3];
    year = matchArray[4];
 
    
    if (month < 1 || month > 12) { // check month range
        msg = "Month must be between 1 and 12.";
        return msg;
    }
 
    if (day < 1 || day > 31) {
        msg = "Day must be between 1 and 31.";
        return msg;
    }
 
    if ((month==4 || month==6 || month==9 || month==11) && day==31) {
        msg = "Month "+month+" doesn't have 31 days!";
        return msg;
    }
 
    if (month == 2) { // check for february 29th
    var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
    if (day>29 || (day==29 && !isleap)) {
        msg = "February " + year + " doesn't have " + day + " days!";
        return msg;
    }
    }
 
    if (day.charAt(0) == '0') day= day.charAt(1);
    
    // Incase you need the value in CCYYMMDD format in your server program
    // msg = (parseInt(year,10) * 10000) + (parseInt(month,10) * 100) +
	// parseInt(day,10);
    
    return msg;  // date is valid
}

function form2valid()
{
	appointcall1();
}

function dispname(){
	$("#btnname").hide();
	$("#hidespec").hide();
	$("#deptdiv").hide();
	$("#docname").show();
	$("#tablediv7").hide();
}


var serviceip;

function getpharmaservices()
{
	$("#plist").hide();
	$("#hlist").hide();
	$("#dcdist").hide();
	$("#hs").hide();
	$("#om").hide();
}

$(document).ready(function(){
$("#pdiv").click(function(event){
	$("#plist").empty();
	serviceip=myipaddr+"getpaharmaservice";
 $.get(serviceipaddr,function(responseJson) {
	 if(responseJson!=null)
	 {
//		 $("#plist").find("tr:gt(0)").remove();
		 $("#plist").empty();
		 var table1 = $("#plist");
            $.each(responseJson, function(key,value) {
            	var oservice=$("");
            	oservice.append("<a href='#'>"+value.spAtrri+"</a>");
            	oservice.appendTo(table1);
            });
	 }
 });
 $("#plist").show();
});
});
function getfitservices()
{
	$("#plist").hide();
	$("#hlist").hide();
	$("#dcdist").hide();
	$("#ps").hide();
	$("#om").hide();
	$("#dc").hide();
}

//$(document).ready(function(){
////	$("#jstorder").hide();
//	 $("#hdiv").click(function(event){
//		 serviceip=myipaddr+"rest/getserviceattri";
//	 $.get(serviceip,function(responseJson) {
//		 if(responseJson!=null)
//			 {
//			 $("#hlist").find("tr:gt(0)").remove();
//			 var table1 = $("#hlist");
//	            $.each(responseJson, function(key,value) {
//	            	var oservice="<a href='#'>"+value.spAtrri+"</a>";
//	            	oservice.appendTo(table1);
//	            });
//			 }
//		 $("#customo").hide();
//		 $("#om").hide();
//	 });
//	 $("#hlist").show();
//	 });
//});

function getdiscountcoupons()
{
	$("#plist").hide();
	$("#hlist").hide();
	$("#dclist").hide();
	$("#ps").hide();
	$("#om").hide();
	$("#hs").hide();
}


function getfitservice()
{
//	$("#jstorder").hide();
	 $("#hdiv").click(function(event){
		 serviceip=serviceipaddr+"/gethealthservice";
	 $.get(serviceipaddr,function(responseJson) {
		 if(responseJson!=null)
			 {
			 $("#hlist").find("tr:gt(0)").remove();
			 var table1 = $("#hlist");
	            $.each(responseJson, function(key,value) {
	            	var oservice="<a href='#'>"+value.spAtrri+"</a>";
	            	oservice.append(table1);
	            });
			 }
	 });
	 $("#hlist").show();
	 });
}

function submitdiscount()
{
	var mydiscount;
	var formd={};
	formd["patid"]=patid;
	formd["discount_id"]=$('#discountders').val();
	formd["offer"]=$('#discountcode').val();
	formd["values"]=$("#disdate").val();
	formd["status"]="granted";
	mydiscount = JSON.stringify(formd);
	setappointment();
	//grantdiscount(mydiscount);
}

function grantdiscount(mydiscount)
{
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/patient/mydiscount';
	var params    = mydiscount;  
	$("#discountders").val('');
	$("#discountcode").val('');
	$("#disdate").val('');
	$("#distime").val('');
	resetservicedisplay();
	SendAsync_PostRequest(xmlHttp,req_url,params,conformdiscount);
}

function conformdiscount()
{
if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
	//var json_resp =  xmlHttp.responseText;	//Json response
	alertify.alert("<h3>Discount Granted</h3>");
	window.open(myipaddr+"dowload.html");
}
else
	{
	alertify.alert("<h3>Server Not Reachable or internal Server Error</h3>");
	}
}

function setappointment()
{
	//var mydiscount;
	var formd={};
	formd["patId"]=patid;
	formd["docId"]="111";
	formd["appointDersc"]=discountderc;
	formd["appointTimming"]=$("#distime").val();
	formd["appointDate"]=$("#disdate").val();
	formd["appointStatus"]="awaited";
	mydiscount = JSON.stringify(formd);
	result=mydiscount;
//	alert(result);
	registerappoint();
}

//var noreqmedicines;
//function getmedicinesno(ptid,mn,md)
//{
//	xmlHttp  = GetXmlHttpObject();
//	var req_url = 'rest/patient/gettotalmedicinesreq/'+ptid+'/'+mn+'/'+md;
//	SendAsync_GetRequest(xmlHttp,req_url,null,setreqmedicines);
//}
//
//function setreqmedicines()
//{
//	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
//		var json_resp = xmlHttp.responseText; // Json response
//		if (json_resp != null) {
//			
//		}
//	}
//}

function gettotalmedicine(ptid,mn,md)
{
//	alert(ptid+mn+md);
	xmlHttp  = GetXmlHttpObject();
//	alert(mn+" "+md);
	var req_url = 'rest/patient/gettotalmedicines/'+ptid+'/'+mn+'/'+md;
	SendAsync_GetRequest(xmlHttp,req_url,null,settheshold);
}

function settheshold()
{
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
//		alert("responce");
		//alert(xmlHttp.responseText);
		var json_resp = xmlHttp.responseText; // Json response
//		alert("got responce"+json_resp);
		if (json_resp != null) {
			//theshold=json_resp;
			json_resp=json_resp-qty;
//			alert(json_resp);
			document.getElementById("mqty").value=json_resp;
			gettprice();
			$("#myservices").show();
			$("#strt").show();
			$("#spserving").show();
		}
	}
	else
	{
		resetservicedisplay();
		
	}
//	else
//		{
//			alertify.alert("<h3>Server Not Responding</h3>");
//		}
}
// <div id="mapholder"></div> -- the cuurent location of urs ll display in this div...
//function gethospitals()
//	{
//	resetservicedisplay();
//	$("col2").show();
//	$("#demo").show();
//	$("#mapholder").show();
//	if (navigator.geolocation)
//    {
//    navigator.geolocation.watchPosition(showPosition);
//    }
//  else{
//	  alertify.alert("Geolocation is not supported by this browser.");
//  }
//	
//}
//	var x=document.getElementById("demo");
//	var lat,log;
//	function getLocation()
//	  {
//	  if (navigator.geolocation)
//	    {
//	    navigator.geolocation.getCurrentPosition(showPosition,showError);
//	    }
//	  else{x.innerHTML="Geolocation is not supported by this browser.";}
//	  }
//
//	function showPosition(position)
//	  {
//	  var latlon=position.coords.latitude+","+position.coords.longitude;
//	  lat=position.coords.latitude;
//	  log=position.coords.longitude;
////	  alert(latlon);
//	  var img_url="http://maps.googleapis.com/maps/api/staticmap?center="
//		  +latlon+"&zoom=14&size=400x300&sensor=false";
//		  document.getElementById("mapholder").innerHTML="<img src='"+img_url+"'>";
//	  $("#imdservice").hide();
//	  $("#mapholder").show();
//	  //create a service by geting the latitude and logitude of the patient to get immediate ambulance by admin profile granting the service on his profils tab immediate service(1st tab)....
//	  //setemergencycall();
//	  setemergency();
//	  }
//
//	function showError(error)
//	  {
//	  switch(error.code) 
//	    {
//	    case error.PERMISSION_DENIED:
//	      x.innerHTML="The request for Geolocation denied .";
//	      break;
//	    case error.POSITION_UNAVAILABLE:
//	      x.innerHTML="Location information is unavailable.";
//	      break;
//	    case error.TIMEOUT:
//	      x.innerHTML="The request to get user location timed out.";
//	      break;
//	    case error.UNKNOWN_ERROR:
//	      x.innerHTML="An unknown error occurred.";
//	      break;
//	    }
//	  }

	var time=100;
	function hideallservices()
	{
//		resetservicedisplay();
////		$("#myservices").show();
//		$("#col2").show();
////		$("#closeimage").hide();
//		$("#muteservice").show();
//		$("#imdservice").hide();
		setInterval(function(){resetservicedisplay();},time);
		time=50;
	}
//	$('#bdy').translate('en');
//	var myem;
//	function setemergencycall()
//	{
//		var formd={};
//		formd["pat_id"]=patid;
//		formd["pat_name"]=patname;
//		formd["em_lat"]=lat;
//		formd["em_log"]=log;
//		myem = JSON.stringify(formd);
//		result=myem;
////		alert(myem);
//		setemergency();
//	}
//	
//	function setemergency()
//	{
//		xmlHttp = GetXmlHttpObject();
//		var req_url = 'rest/admin/eminsert/'+patid+'/'+patname+'/'+lat+'/'+log+'/';
//		//var params = result;
//		SendAsync_GetRequest(xmlHttp, req_url, null, admin_conformation);
//	}
//	
//	function admin_conformation()
//	{
//		if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
//			var json_resp = xmlHttp.responseText; // Json response
////			alert(json_resp);
////			if (json_resp != null) {
//				alertify.alert("<h4>Dont Panic, <hr>Ambulance Coming At your Current Location</h4>");
//				$("#col2").show();
//				$("#myservices").show();
//				$("#mapholder").show();
//				
////					}
//			}
////		}
////		else
////			{
////			alertify.alert("<h3>Server not Responding");
////			}
//	}
//	