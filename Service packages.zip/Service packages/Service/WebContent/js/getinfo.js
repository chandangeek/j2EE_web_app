var medName,medDosage,xmlHttp,result,json;

function getdetails()
{
	$("#bdy").mouseover(function(event){
 		//patid=getCookie("patid");
 		//alert(patid);
           $.get('rest/medicationservice',function(responseJson) {
            if(responseJson!=null){
                $("#producttable").find("tr:gt(0)").remove();
                var table1 = $("#producttable");
                $.each(responseJson, function(key,value) { 
                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
                        rowNew.children().eq(0).text(value['productId']); 
                        rowNew.children().eq(1).text(value['productName']); 
                        rowNew.children().eq(2).text(value['productDosage']); 
                        rowNew.children().eq(3).text(value['stock']); 
                        rowNew.children().eq(4).text(value['status']);
                        rowNew.children().eq(5).text(value['price']);
                        rowNew.appendTo(table1);
                });
                }
            });
            $("#tablediv").show();          
   });      
	
//		                	document.getElementById("productId").innerHTML=value.productId;
//		                	document.getElementById("productName").innerHTML=value.productName;
//		                	document.getElementById("productDosage").innerHTML=value.productDosage;
//		                	// document.getElementById(stock).innerHTML=value.stock;
//		                	document.getElementById("status").innerHTML=value.status;
//		                	document.getElementById("price").innerHTML=value.price;
		              
}
//// for ordering form
//function test()
//{
//	var formData = form2object('fff', '.', true,
//			function(node)
//			{
//				if (node.id && node.id.match(/www/))
//				{
//					return { name: node.id, value: node.innerHTML };
//				}
//			});
//
//	result = JSON.stringify(formData, null, '\t');
//	// alert(result);
//	registerUser();
//}
//
//
//
//// get medName and medDosage by cookies make cookie get function
//function sendmeddata()
//{
//// var username = document.getElementById("email").value; //alert(username)
//xmlHttp  = GetXmlHttpObject();
//var req_url = 'rest/medicationservice/rmed/'+medName+"/"+medDosage;
//SendAsync_GetRequest(xmlHttp,req_url,null,registration_resp);
//}
//
//function registration_resp()
//{
//if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
//	var json_resp =  xmlHttp.responseText;	// Json response
//	if(json_resp!=null)
//	{
//	getdetails(json_resp);
//	}
//	}
//}
//
//function SendAsync_GetRequest(post_xmlHttp, post_url, post_params, resFunction)
//{
//try
//{
//    post_xmlHttp.onreadystatechange = resFunction;
//   // post_url = post_url.replace(/\|/g, "%7C");
//    post_xmlHttp.open("GET",post_url,true);
//    post_xmlHttp.setRequestHeader("Content-type", "application/json");
//    // post_xmlHttp.setRequestHeader("Content-length", post_params.length);
//    // post_xmlHttp.setRequestHeader("Connection", "close");
//    post_xmlHttp.send();
//}
//catch(e)
//{
//	alert(' Server is not Responding... some Problem in server');
//}
//}
//function GetXmlHttpObject(){
//
//var xmlHttp = null;
//try
//{
//    // Firefox, Opera 8.0+, Safari
//    xmlHttp = new XMLHttpRequest();
//	
//}
//catch (e)
//{
//    // Internet Explorer
//    try
//    {
//        xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
//    }
//    catch (e)
//    {
//        xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
//    }
//}
//
//return xmlHttp;
//}
//});
