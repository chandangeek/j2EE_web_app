var ipaddr="192.168.10.140"; 
var myipaddr="http://ingbtcpic2nb3nb:8080/";
$(document).on('click', 'a.resize', function() {
		$cn = $('.container');
		var width = 600, onComplete;
		if (!$cn.data('fullWidth')) {
			$cn.data('fullWidth', $cn.width());
			$cn.css('maxWidth', $cn.width());
		} else {
			width = $cn.data('fullWidth');
			$cn.data('fullWidth', null);
			onComplete = function() {
				$cn.css('maxWidth', null);
			};
		}
		$cn.animate({
			maxWidth : width
		}, {
			complete : onComplete
		});
		$(window).trigger('resize');
		return false;
	});
$(function() {
	$('.tabcordion').tabcordion();
});
window.brunch = window.brunch || {};
window.brunch['auto-reload'] = {
	enabled : true
};
function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
  }
return "";
}
function deletecookies(){
	var cookies = document.cookie.split(";");

	for (var i = 0; i < cookies.length; i++) {
		var cookie = cookies[i];
		var eqPos = cookie.indexOf("=");
		var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		window.location.replace(myipaddr+"UIA");
	}
}
function checkcookiedoc()
{
	docid=getCookie("docid");
	if(docid==='')
		{
		window.location.replace(myipaddr+"UIA");
		}
}

var docid,id,docnam;

$(document).ready(function() {
	 $("#tablediv2").hide();
	     $("#bdy").mouseover(function(event){
	    	 docid=getCookie("docid");
	    	 //alert(docid);
	           $.get('rest/doctor/'+docid,function(responseJson) {
	            if(responseJson!=null){
	                $("#doctortable").find("tr:gt(0)").remove();
	                var table1 = $("#doctortable");
	                $.each(responseJson, function(key,value) {
	                	id=value.doc_id;
//	                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
//	                        rowNew.children().eq(0).text(value['doc_id']); 
//	                        rowNew.children().eq(1).text(value['doc_name']); 
//	                        rowNew.children().eq(2).text(value['doc_spec']); 
//	                        rowNew.children().eq(3).text(value['doc_dept']);
//	                        rowNew.children().eq(4).text(value['doc_phone']);
//	                        rowNew.children().eq(5).text(value['doc_email']); 
//	                        rowNew.appendTo(table1);
	                	docnam=value.doc_name;
	                	document.getElementById("doid").innerHTML=id;
	                	document.getElementById("doname").innerHTML=value.doc_name;
	                	document.getElementById("dospec").innerHTML=value.doc_spec;
	                	document.getElementById("dodept").innerHTML=value.doc_dept;
	                	document.getElementById("doph").innerHTML=value.doc_phone;
	                	document.getElementById("doei").innerHTML=value.doc_email;
	                });
	                //alert("calling hide sp");
	               // hidesp();
	                }
	            });
	            $("#tablediv2").show();
	            document.getElementById("doc").value=docnam;
	  });      
	});
var patnam;
function getpatnam(patidds)
{
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/patient/patientname/'+patidds;
	SendAsync_GETRequest(xmlHttp,req_url,null,mypatname);
}
function mypatname()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	//Json response
		//alert(json_resp);
		patnam=json_resp;
		repeat(patnam);
	}
}
//var patname = new Array();
//function getpatname(patids)
//{
//	xmlHttp  = GetXmlHttpObject();
//	var req_url = 'rest/patient/patientname/'+patids;
//	SendAsync_GETRequest(xmlHttp,req_url,null,patn);
//	return;
//}
//function patn()
//{
//	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
//		var json_resp =  xmlHttp.responseText;	//Json response
//		//alert(json_resp);
//		patname[ac]=json_resp;
//	}
//}
var vc;
var pri;
$(document).ready(function() {
	 $("#tablediv3").hide();
	 $("#nothing").hide();
	 $("#patmedform").hide();
	 var not;
	 docid=getCookie("docid");
	 
		//alert(docid);
        $.get('rest/doctor/patientrecord/'+docid,function(responseJson) {
         if(responseJson!=null){
        	 pri=0;
        	 $.each(responseJson, function(key,value) { 
             	pri++;
             	getpatnam(value.pat_id);
        	 });
         }
        });
//	     $("#showTable").mouseover(function(event){
	 	$("#showPatient").click(function(event){
	 		vc=0;
	 		$("#patmedform").hide();
	 		 $("#nothing").hide();
	 		docid=getCookie("docid");
	 		//alert(docid);
	           $.get('rest/doctor/patientrecord/'+docid,function(responseJson) {
	            if(responseJson!=null){
	                $("#prtable").find("tr:gt(0)").remove();
	                var table1 = $("#prtable");
	                $.each(responseJson, function(key,value) { 
	                	vc++;
	                	not = value.pr_id;
	                	var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td></tr>");
//	                        rowNew.children().eq(0).text(value['pr_id']); 
//	                        rowNew.children().eq(1).text(value['doc_id']); 
//	                        rowNew.children().eq(2).text(value['pat_id']);
	                      //get patName func getpatnam(value.pat_id);
//	                		alert(value.pat_id);
	                        rowNew.children().eq(0).text(docnam);
	                        rowNew.children().eq(1).text(value['docName']);
	                        rowNew.children().eq(2).text(value['symtoms']); 
	                        rowNew.children().eq(3).text(value['disease']); 
	                        rowNew.children().eq(4).text(value['status']);
	                       // var inp="<input type='button' name='cmed' id='medb"+vc"' value='create medication' onclick='displaypr()'>";
	                        //rownew.children().eq(5).text(inp);
	                        rowNew.append("<td><input type='button' value='create medication' id='med' onclick='getmedlist("+value.pat_id+")'>");
	                        rowNew.append("<td><input type='button' value='Delete Patient Record' id='drod' onclick='calldelete("+value.pat_id+")'>");
	                        rowNew.appendTo(table1);
	                        $("#tablediv3").show();
	                        //alert(patnam);
	                });
	                }
	            if(typeof not == 'undefined')
	       		{
	        	   $("#nothing").show();
	        	   $("#tablediv3").hide();
	       		}
	            });
	                      
	   });      
	});

function calldelete(pentid)
{
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/patient/deleterecord/'+pentid;
	SendAsync_GETRequest(xmlHttp,req_url,null,conformdelete);
}

function conformdelete()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	//Json response
		if(json_resp!="failure")
			{
			alertify.alert("<h3>Deleted the Record</h3>");
			getrecords();
			}
		else
			{
			alertify.alert("Wrong Operation");
			}
	}
}
function getrecords()
{
	 $.get('rest/doctor/patientrecord/'+docid,function(responseJson) {
         if(responseJson!=null){
             $("#prtable").find("tr:gt(0)").remove();
             var table1 = $("#prtable");
             $.each(responseJson, function(key,value) { 
             	vc++;
             	not = value.pr_id;
             	var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td></tr>");
//                     rowNew.children().eq(0).text(value['pr_id']); 
//                     rowNew.children().eq(1).text(value['doc_id']); 
//                     rowNew.children().eq(2).text(value['pat_id']);
                   //get patName func getpatnam(value.pat_id);
//             		alert(value.pat_id);
                     rowNew.children().eq(0).text(docnam);
                     rowNew.children().eq(1).text(value['docName']);
                     rowNew.children().eq(2).text(value['symtoms']); 
                     rowNew.children().eq(3).text(value['disease']); 
                     rowNew.children().eq(4).text(value['status']);
                    // var inp="<input type='button' name='cmed' id='medb"+vc"' value='create medication' onclick='displaypr()'>";
                     //rownew.children().eq(5).text(inp);
                     rowNew.append("<td><input type='button' value='create medication' id='med' onclick='getmedlist("+value.pat_id+")'>");
                     rowNew.append("<td><input type='button' value='Delete Record' id='drod' onclick='calldelete("+value.pat_id+")'>");
                     rowNew.appendTo(table1);
                     $("#tablediv3").show();
                     //alert(patnam);
             });
             }
         if(typeof not == 'undefined')
    		{
     	   $("#nothing").show();
     	   $("#tablediv3").hide();
    		}
         });
}

var mymedpatid;
function getmedlist(papid)
{
//	patnam="";
	getpatnam(papid);
	mymedpatid=papid;
//	document.getElementById("usernamep").value=patnam;
	repeat();
	$("#tablediv3").hide();
	$("#patmedform").show();
}
function repeat(patna)
{
	document.getElementById("usernamep").value=patna;
	document.getElementById("pat").value=patna;
}
var ac;
$(document).ready(function() {
	 $("#tablediv4").hide();
	 $("#nothing1").hide();
	 var not;
	     $("#showAppointment").click(function(event){
	    	 ac=0;
	    	 $("#nothing1").hide();
	    	 docid=getCookie("docid");
	           $.get('rest/doctor/appointment/'+docid,function(responseJson) {
	            if(responseJson!=null){
	                $("#appointmenttable").find("tr:gt(0)").remove();
	                var table1 = $("#appointmenttable");
	                $.each(responseJson, function(key,value) {
	                	ac++;
	                	not=value.appointId;
	                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
//	                        rowNew.children().eq(0).text(value['appointId']); 
//	                        rowNew.children().eq(2).text(value['docId']);
//	                     	getpatname(value.patId);
	                     	rowNew.children().eq(0).text(docnam);
	                     	rowNew.children().eq(1).text(value['docName']);
	                        rowNew.children().eq(2).text(value['appointDersc']);
	                        rowNew.children().eq(3).text(value['appointTimming']); 
	                        rowNew.children().eq(4).text(value['appointDate']); 
	                        rowNew.children().eq(5).text(value['appointStatus']);
	                        rowNew.append("<td><input type='button' value='update appointment' id='app'"+ac+"' onclick='getupdateapp("+value.appointId+")'></td>");
	                        rowNew.append("<td><input type='button' value='create patient record' id='cpr'"+ac+"' onclick='getpatientrecord("+value.patId+")'></td>");
	                        rowNew.appendTo(table1);
	                        $("#tablediv4").show(); 
	                });
	                }
	            if(typeof not == 'undefined')
	       		{
	        	   $("#nothing1").show();
	        	   $("#tablediv4").hide();
	       		}
	            });
	  });      
	});

function setpatid(patientname)
{
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/patient/patientid/'+patientname;
	SendAsync_GETRequest(xmlHttp,req_url,null,mypatid);
}
function mysetpatid(patientname)
{
//	var patiname = document.form9.patId.value;
	//alert(patientname);
//	setpatid(patiname);
	xmlHttp = GetXmlHttpObject();
	var req_url = 'rest/patient/patientid/' + patientname;
	SendAsync_GETRequest(xmlHttp, req_url, null, mypid);
}
var patientid;
function mypatid()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	//Json response
		//alert(json_resp);
		patientid=json_resp;
//		test();
	}
}
function mypid()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	//Json response
//		alert(json_resp);
		patientid=json_resp;
		test(json_resp);
	}
}
var readyid;
function getpatientrecord(ppid)
{
	getpatnam(ppid);
	readyid=ppid;
	document.getElementById("pat").value=patnam;
	document.getElementById("doc").value=docnam;
	repeat();
	//active--display patient record.
	$("#shpr").show();
}
function getupdateapp(apid)
{
	document.getElementById("appID").value=apid;
	//display update appoitnment tab active
}
$(document).ready(function() {
	$("#medform").hide();
	$("#showform").click(function(event){
		$("#medform").show();
		//call for the values in the dynamic forms 
	});
});
var result,i=1;

function formmulti()
{
	i++;
//	var padd=$("<p></p><br>");
//	padd.append("Medication List "+i);
//	padd.appendTo($("#mediname"));
	$("#mediname").append("Medication List");
	var type="text";
	var name="medName"+i;
	var values="Enter Medicine Name "+i;
	mednames(type,name,values,i);
	document.getElementById(name+i).innerHTML="<b>Medication List "+i+"</b><br>";
	name="medDosage"+i;
	values="Enter Medicine Dosage "+i;
	meddosages(type,name,values,i);
	name="medFrequency"+i;
	values="Enter Medicine Frequency "+i;
	medfrequencies(type,name,values,i);
	name="qty"+i;
	values="Enter Medicine availability "+i;
	medqtys(type,name,values,i);
}
var k=1;
function formmultip()
{
	k++;
	var type="text";
	var name="medNamep"+k;
	//$("#medlist").show();
//	$( ".inner" ).prepend( "<p>Test</p>" );
	var values="Enter Medicine Name "+k;
	mednamesp(type,name,values,k);
	document.getElementById(name+k).innerHTML="<b>Medication List "+k+"</b><br>";
	name="medDosagep"+k;
	values="Enter Medicine Dosage "+k;
	meddosagesp(type,name,values,k);
	name="medFrequencyp"+k;
	values="Enter Medicine Frequency "+k;
	medfrequenciesp(type,name,values,k);
	name="qtyp"+k;
	values="Enter Medicine availability "+k;
	medqtysp(type,name,values,k);
	
}
function mednames(type,name,values,i)
{
	var spn=document.createElement("span");
	spn.setAttribute("id", name+i);
	var element = document.createElement("input");
    //Assign different attributes to the element.
    element.setAttribute("type", type);
    element.setAttribute("placeholder", values);
//    element.setAttribute("name", name);
    element.setAttribute("id", name);
 
    var foo = document.getElementById("formadd");
    //Append the element in page (in span).
    foo.appendChild(spn);
    foo.appendChild(element);
    var brs=document.createElement("br");
    foo.appendChild(brs);
}

function meddosages(type,name,values,i)
{
	var element = document.createElement("input");
    //Assign different attributes to the element.
    element.setAttribute("type", type);
    element.setAttribute("placeholder", values);
//    element.setAttribute("name", name);
    element.setAttribute("id", name);
    var foo = document.getElementById("formadd");
    //Append the element in page (in span).
    foo.appendChild(element);
    var brs=document.createElement("br");
    foo.appendChild(brs);
}

function medfrequencies(type,name,values,i)
{
	var element = document.createElement("input");
    //Assign different attributes to the element.
    element.setAttribute("type", type);
    element.setAttribute("placeholder", values);
//    element.setAttribute("name", name);
    element.setAttribute("id", name);
    var foo = document.getElementById("formadd");
    //Append the element in page (in span).
    foo.appendChild(element);
    var brs=document.createElement("br");
    foo.appendChild(brs);
}

function medqtys(type,name,values,i)
{
	var element = document.createElement("input");
    //Assign different attributes to the element.
    element.setAttribute("type", type);
    element.setAttribute("placeholder", values);
//    element.setAttribute("name", name);
    element.setAttribute("id", name);
    var foo = document.getElementById("formadd");
    //Append the element in page (in span).
    foo.appendChild(element);
    var brs=document.createElement("br");
    foo.appendChild(brs);
}

function mednamesp(type,name,values,i)
{
//	
//	var nam=document.createElement("input");
//	nam.setAttribute("value", "medication list"+i);
//	nam.setAttribute("id", "strong"+i);
//	$( name ).prepend( "Hello <br>" );
	var spn=document.createElement("span");
	spn.setAttribute("id", name+i);
	var element = document.createElement("input");
    //Assign different attributes to the element.
    element.setAttribute("type", type);
    element.setAttribute("placeholder", values);
//    element.setAttribute("name", name);
    element.setAttribute("id", name);
    var foo = document.getElementById("formaddp");
    //Append the element in page (in span).
    foo.appendChild(spn);
    var brs=document.createElement("br");
    foo.appendChild(brs);
    foo.appendChild(element);
    foo.appendChild(brs);
//    var newDiv = document.createElement("div"); 
//    var newContent = document.createTextNode("Medication List"+i);
//    newDiv.appendChild(newContent);
//    var my_div=document.getElementById(name);
//    document.body.insertBefore(newDiv, my_div);
}

function meddosagesp(type,name,values,i)
{
	var element = document.createElement("input");
    //Assign different attributes to the element.
    element.setAttribute("type", type);
    element.setAttribute("placeholder", values);
//    element.setAttribute("name", name);
    element.setAttribute("id", name);
    var foo = document.getElementById("formaddp");
    //Append the element in page (in span).
    foo.appendChild(element);
    var brs=document.createElement("br");
    foo.appendChild(brs);
}

function medfrequenciesp(type,name,values,i)
{
	var element = document.createElement("input");
    //Assign different attributes to the element.
    element.setAttribute("type", type);
    element.setAttribute("placeholder", values);
//    element.setAttribute("name", name);
    element.setAttribute("id", name);
    var foo = document.getElementById("formaddp");
    //Append the element in page (in span).
    foo.appendChild(element);
    var brs=document.createElement("br");
    foo.appendChild(brs);
}

function medqtysp(type,name,values,i)
{
	var element = document.createElement("input");
    //Assign different attributes to the element.
    element.setAttribute("type", type);
    element.setAttribute("placeholder", values);
//    element.setAttribute("name", name);
    element.setAttribute("id", name);
    var foo = document.getElementById("formaddp");
    //Append the element in page (in span).
    foo.appendChild(element);
    var brs=document.createElement("br");
    foo.appendChild(brs);
}

function validatename()
{
	var name=document.form9.medName;
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h4>Please Enter Name field</h4>");
		name.focus();
		return false;
	}
	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
	if(!filter.test(name.value)) 
		{
		alertify.alert('<h4>Please provide only aphabets with space allowed</h4>');
		name.focus;
		return false;
		}
	return true;
} 
function validatepatname()
{
	var ppid=document.form9.patName;
	if(ppid==null || ppid=='')
		{
		alertify.alert("<h4>please enter patient id</h4>");
		return false;
		}
	return true;
}
function validatepid()
{
	var ppid=document.getElementById("pat").value;
	if(ppid==null || ppid=='')
	{
		alertify.alert("<h4>please enter Patient id<h4>");
	return false;
	}
return true;
}

function validatedocname()
{
	var ddid=document.getElementById("doc").value;
	if(ddid==null || ddid=='')
		{
		alertify.alert("<h4>please enter doctor id</h4>");
		return false;
		}
	return true;
}

function validatesyts()
{
	var name=document.getElementById("symm");
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h4>Please Enter symtoms field</h4>");
		name.focus();
		return false;
	}
//	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
//	if(!filter.test(name.value)) 
//		{
//		alertify.alert('Please provide only aphabets with space allowed');
//		name.focus;
//		return false;
//		}
	return true;
}

function validatedia()
{
	var name=document.getElementById("diaes");
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h4>Please Enter disease field</h4>");
		name.focus();
		return false;
	}
//	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
//	if(!filter.test(name.value)) 
//		{
//		alertify.alert('Please provide only aphabets with space allowed');
//		name.focus;
//		return false;
//		}
	return true;
}

function validatesta()
{
	var name=document.getElementById("stss");
	if((name.value==null)||(name.value=="")){
		alertify.alert("<h4>Please Enter status field</h4>");
		name.focus();
		return false;
	}
//	var filter = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
//	if(!filter.test(name.value)) 
//		{
//		alertify.alert('Please provide only aphabets with space allowed');
//		name.focus;
//		return false;
//		}
	return true;
}

//function validatedosage()
//{
//	var name=document.form9.medDosage;
//	if((name.value==null)||(name.value=="")){
//		alertify.alert("Please Enter Dosage field");
//		name.focus();
//		return false;
//	}
////	var filter=/^[a-zA-Z[0-9]]*$/;
////	if(!filter.test(name.value)) 
////		{
////		alertify.alert('Please provide only aphabets and numbers');
////		name.focus;
////		return false;
////		}
//	return true;
//}
//
//function validatefrequency()
//{
//	var name=document.form9.medFrequency;
//		if((name.value==null)||(name.value=="")){
//			alertify.alert("Please Enter frequency field");
//			name.focus();
//			return false;
//		}
//		
//		return true;
//}
//
//function validatesdate()
//{
//	var sdate=document.form9.medStartDate;
//	if(sdate==false || sdate=='')
//		{
//		alertify.alert("please enter start date of the course");
//		return false;
//		}
//	return true;
//}
//
//function validateedate()
//{
//	var edate=document.form9.medEndDate;
//	if(edate==false || edate=='')
//		{
//		alertify.alert("please enter end date of the course");
//		return false;
//		}
//	return true;
//}
//
//function validateqty()
//{
//	var mqty=document.form9.qty;
//	if(mqty==false || mqty=='')
//		{
//		alertify.alert("please enter quantity");
//		return false;
//		}
//	return true;
//}
//
//function validateall()
//{
//	var vp=validatepatid();
//	var vn=validatename();
//	var vd=validatedosage();
//	var vf=validatefrequency();
//	var vs=validatesdate();
//	var ve=validateedate();
//	var vq=validateqty();
//	if(vp==false || vn==false || vd==false || vf==false || vs==false || ve==false || vq==false)
//		{
//		 return false;
//		}
//	test();
//}

function validatepr()
{
	var vvd=validatedocname();
	//var vvp=validatepatid();
	var vvs=validatesyts();
	var vvdi=validatedia();
	var vvst=validatesta();
	if( vvd==false || vvs==false || vvdi==false || vvst==false) //|| vvp==false
		{
		return false;
		}
	else
		{
		pr();
		}
}
var pname,sdates,edates;
var x=0,z=0;
function test(ppaid)
{
	var a,b,c;
	document.getElementById("username").value = ppaid;
	a=$("#username").val();
	b=$("#csd").val();
	c=$("#ced").val();
	for(var j=1;j<=i;j++)
		{
//			pname="patName";
//			sdates="medStartDate";
//			edates="medEndDate";
		var medn="mname";
		var medd="md";
		var medf="frw";
		var medq="mqty";
		if(j>1)
			{
			medn="medName"+j;
			medd="medDosage"+j;
			medf="medFrequency"+j;
			medq="qty"+j;
			}
			//var a=document.form9.pname.value;
	
//		if(j<=1)
//			{
//			a=document.form9.patName.value;
//			b=document.form9.medStartDate.value;
//			c=document.form9.medEndDate.value;
//			}
//		else
//			{
			
//			}
//			var d=document.form9.medName+j.value;
//			var e=document.form9.medDosage+j;
//			var f=document.form9.medFrequency+j;
//			var g=document.form9.qty+j;
			var d=$('#'+medn).val();
			//alert(d);
			var e=$('#'+medd).val();
			var f=$('#'+medf).val();
			var g=$('#'+medq).val();
//			var a1='"'+a+'"';
//			var b1='"'+b+'"';
//			var c1='"'+c+'"';
//			var d1='"'+d+'"';
//			var e1='"'+e.value+'"';
//			var f1='"'+f.value+'"';
//			var g1='"'+g.value+'"';
//			var formd={"patName":a}+{"medStartDate":b}+{"medEndDate":c}+{"medName":d}+{"medDosage":e}+{"medFrequency":f}+{"qty":g};
			var formd={};
			formd["patId"]=a;
			formd["medStartDate"]=b;
			formd["medEndDate"]=c;
			formd["medName"]=d;
			formd["medDosage"]=e;
			formd["medFrequency"]=f;
			formd["qty"]=g;
			results = JSON.stringify(formd);
//			alert(result);
			registerUser(results);
			x=j;
		}
}
function setmypatid(pnam)
{
	xmlHttp = GetXmlHttpObject();
	var req_url = 'rest/patient/patientid/' + pnam;
	SendAsync_GETRequest(xmlHttp, req_url, null, myppid);
}
function myppid()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	//Json response
//		alert(json_resp);
		patientid=json_resp;
		testp(json_resp);
	}
}
function testp(pmyid)
{
	var a,b,c;
	document.getElementById("usernamep").value=pmyid;
	a=$("#usernamep").val();
//	alert(k);
	b=$("#csdp").val();
	c=$("#cedp").val();
	for(var j=1;j<=k;j++)
	{
	var medn="mnamep";
	var medd="mdp";
	var medf="frwp";
	var medq="mqtyp";
	if(j>1)
		{
		medn="medNamep"+j;
		medd="medDosagep"+j;
		medf="medFrequencyp"+j;
		medq="qtyp"+j;
		}
		var d=$('#'+medn).val();
		//alert(d);
		var e=$('#'+medd).val();
		var f=$('#'+medf).val();
		var g=$('#'+medq).val();
		var formd={};
		formd["patId"]=a;
		formd["medStartDate"]=b;
		formd["medEndDate"]=c;
		formd["medName"]=d;
		formd["medDosage"]=e;
		formd["medFrequency"]=f;
		formd["qty"]=g;
		myresults = JSON.stringify(formd);
//		alert(result);
		registerPatient(myresults);
		z=j;
	}
}
function medsubmit() 
	{
		//how to add form submit.....
	
		var formData = form2object('fff', '.', true,
				function(node)
				{
					if (node.id && node.id.match(/www/))
					{
						return { name: node.id, value: node.innerHTML };
					}
				});

		result = JSON.stringify(formData, null, '\t');
		//alert(result);
		//registerUser();
	}
	var xmlHttp;
function registerUser(results)
{
//	alert(results);
	//var username = document.getElementById("email").value; //alert(username)
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/medicine/addmedicine';
	var params    = results;  
	$("#username").val('');
	$("#password").val('');
	$("#md").val('');
	$("#frw").val('');
	$("#csd").val('');
	$("#ced").val('');
	$("#mqty").val('');
	$("#formadd").hide();
	SendAsync_PostRequest(xmlHttp,req_url,params,registration_resp);
}

function registerPatient(myresults)
{
	//var username = document.getElementById("email").value; //alert(username)
	xmlHttp  = GetXmlHttpObject();
	var req_url = 'rest/medicine/addmedicine';
	var params    = myresults;  
	$("#usernamep").val('');
	$("#passwordp").val('');
	$("#mnamep").val('');
	$("#mdp").val('');
	$("#frwp").val('');
	$("#csdp").val('');
	$("#cedp").val('');
	$("#mqtyp").val('');
	$("#formaddp").hide();
	SendAsync_PostRequest(xmlHttp,req_url,params,registration_resp);
}
function registration_resp()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	//Json response
		//alert(json_resp);
		if(z==k || x==i)
			{
		alertify.alert("<h3>Meidcines list Added successfully</h3>");
			}
	}
	
	//redirecting to patient profile
	
	//window.location.replace("http://localhost:8080/RESTSample/medicine.html");//or not sure  "./patientprofile.html"
}
function registration_respa()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	//Json response
		//alert(json_resp);
		
		alertify.alert("<h3>Appointment Updated successfully</h3>");
	}
	//redirecting to patient profile
	
	//window.location.replace("http://localhost:8080/RESTSample/medicine.html");//or not sure  "./patientprofile.html"
}
function registration_respp()
{
	if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp =  xmlHttp.responseText;	//Json response
		//alert(json_resp);
		
		alertify.alert("<h3>Patient Record Created Successful!!!</h3>");
	}
	
	//redirecting to patient profile
	
	//window.location.replace("http://localhost:8080/RESTSample/medicine.html");//or not sure  "./patientprofile.html"
}
function SendAsync_PostRequest(post_xmlHttp, post_url, post_params, resFunction)
{
  try
  {
      post_xmlHttp.onreadystatechange = resFunction;
     // post_url = post_url.replace(/\|/g, "%7C");
      post_xmlHttp.open("POST",post_url,true);
      post_xmlHttp.setRequestHeader("Content-type", "application/json");
      //post_xmlHttp.setRequestHeader("Content-length", post_params.length);
      //post_xmlHttp.setRequestHeader("Connection", "close");
      post_xmlHttp.send(post_params);
  }
  catch(e)
  {
	  alertify.alert('<h3>Server is not Responding... some Problem in server</h3>');
  }
}
function SendAsync_GETRequest(post_xmlHttp, post_url, post_params, resFunction)
{
  try
  {
      post_xmlHttp.onreadystatechange = resFunction;
     // post_url = post_url.replace(/\|/g, "%7C");
      post_xmlHttp.open("GET",post_url,true);
      post_xmlHttp.setRequestHeader("Content-type", "application/json");
      //post_xmlHttp.setRequestHeader("Content-length", post_params.length);
      //post_xmlHttp.setRequestHeader("Connection", "close");
      post_xmlHttp.send();
  }
  catch(e)
  {
	  alertify.alert('<h4>Server is not Responding... some Problem in server</h4>');
  }
}
function GetXmlHttpObject(){

  var xmlHttp = null;
  try
  {
      // Firefox, Opera 8.0+, Safari
      xmlHttp = new XMLHttpRequest();
		
  }
  catch (e)
  {
      // Internet Explorer
      try
      {
          xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
      }
      catch (e)
      {
          xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
      }
  }

  return xmlHttp;
}

function validateappid()
{
	var app=document.getElementById("appID").value;
	if(app==null || app=='')
		{
		alertify.alert("<h4>please enter appoitment</h4>");
		}
	return true;
}

function validatestatus()
{
	var sta=document.getElementById("Status").value;
	if(sta==null || sta=='')
		{
		alertify.alert("<h4>please enter status</h4>");
		return false;
		}
	return true;
}

function updateappoint()
{
	var ap=validateappid();
	var s=validatestatus();
	if(ap==false || s ==false)
		{
		alertify.alert("<h4>one of the field is not filled</h4>");
		return false;
		}
	else
		{
	xmlHttp  = GetXmlHttpObject();
	var appID=document.getElementById("appID").value;
	var status=document.getElementById("Status").value;
	var req_url = 'rest/doctor/appointment/update/'+appID+'/'+status;
	$("#appID").val('');
	$("#Status").val('');
	SendAsync_GETRequest(xmlHttp,req_url,null,registration_respa);
		}
	return true;
}
function pr()
{
	var prpatname=document.getElementById("pat").value;
//	setpatid(prpatname);
	document.getElementById("pat").value=readyid;
	document.getElementById("doc").value=id;
	var formData = form2object('fsr', '.', true,
			function(node)
			{
				if (node.id && node.id.match(/zzz/))
				{
					return { name: node.id, value: node.innerHTML };
				}
			});

	result = JSON.stringify(formData, null, '\t');
	//alert(result);
	prregister();
}
function prregister()
{
xmlHttp  = GetXmlHttpObject();
var req_url = 'rest/doctor/addpatientrecord';
var params    = result;  
//$("#doc").val('');
$("#pat").val('');
$("#symm").val('');
$("#diaes").val('');
$("#stss").val('');
SendAsync_PostRequest(xmlHttp,req_url,params,registration_respp);
}