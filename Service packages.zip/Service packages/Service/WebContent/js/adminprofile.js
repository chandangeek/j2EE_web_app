var ipaddr="http://192.168.10.140:8080"; 
var myipaddr="http://ingbtcpic2nb3nb:8080/";
$(document).on('click', 'a.resize', function() {
		$cn = $('.container');
		var width = 600, onComplete;
		if (!$cn.data('fullWidth')) {
			$cn.data('fullWidth', $cn.width());
			$cn.css('maxWidth', $cn.width());
		} else {
			width = $cn.data('fullWidth');
			$cn.data('fullWidth', null);
			onComplete = function() {
				$cn.css('maxWidth', null);
			};
		}
		$cn.animate({
			maxWidth : width
		}, {
			complete : onComplete
		});
		$(window).trigger('resize');
		return false;
	});
$(function() {
	$('.tabcordion').tabcordion();
});
window.brunch = window.brunch || {};
window.brunch['auto-reload'] = {
	enabled : true
};
function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
  }
return "";
}
var adminid;

function deletecookies(){
	var cookies = document.cookie.split(";");

	for (var i = 0; i < cookies.length; i++) {
		var cookie = cookies[i];
		var eqPos = cookie.indexOf("=");
		var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		window.location.replace(myipaddr+"UIA");
	}
}
function checkcookie()
{
	patid=getCookie("adminid");
		if(patid=='')
			{
			window.location.replace(myipaddr+"UIA");
			}
		else
			{
			adminid=getCookie("adminid");
			//alert(adminid);
			}
}
function getem()
{
	 $.get("rest/admin/emergencylist",function(responseJson) {
         if(responseJson!=null){
             $("#mapholder").find("tr:gt(0)").remove();
             //var table1 = $("#mapholder");
             ct=0;
             $.each(responseJson, function(key,value) {
             	ct++;
             	getemergency(value.em_lat,value.em_log);
             	document.getElementById("demo").innerHTML="<p>Patient Name: <h4>"+value.pat_name+"</h4> <br> Patient Id: <h4>"+value.pat_id+"</h4></p>Clear Service: <input type='button' value='clear' id='em"+ct+" onclick='clearem('"+value.pat_id+"')><hr>";
             //	$("#mapholder").append("<img src='"+img_url+"'>");
             	document.getElementById("mapholder").innerHTML="<img src='"+img_url+"'>";
             	//$("#mapholder").append("<input type='button' value='clear' id='em"+ct+" onclick='clearem('"+value.pat_id+"')>");
             	//document.getElementById("mapholder").innerHTML="<img src='"+img_url+"'>";
});    
         }
});
	 $("#tablediv1").show();
}

$(document).ready(function() {
	 $("#tablediv1").hide();
	 $("#nothing").hide();
	 $("#tablediv").hide();
//	 var not;
	 $("#showem").click(function(event){
//	    	 $("#nothing").hide();
//	    	 $("#tablediv").hide();
		 $.get("rest/admin/emergencylist",function(responseJson) {
	         if(responseJson!=null){
	             $("#mapholder").find("tr:gt(0)").remove();
	             //var table1 = $("#mapholder");
	             ct=0;
	             $.each(responseJson, function(key,value) {
	             	ct++;
	             	getemergency(value.em_lat,value.em_log);
	             	document.getElementById("demo").innerHTML="<p>Patient Name: "+value.pat_name+" <br> patient id: "+value.pat_id+" <hr>Immediate Service "+ct+" For patient "+value.pat_id+"</p><input type='button' value='clear' id='em"+ct+" onclick='clearem('"+value.pat_id+"')><br>";
	             	document.getElementById("mapholder").innerHTML="<img src='"+img_url+"'>"+"<br>";
//	             	$("#mapholder").append("Patient Name: "+value.pat_name+" <br> patient id: "+value.pat_id+" <hr>"+ 
//	             	Immediate Service "+ct+" For patient "+value.pat_id"+"<img src='"+img_url+"'>"+ //     	
//	             	"<input type='button' value='clear' id='em"+ct+" onclick='clearem('"+value.pat_id+"')>");
	             	//$("#mapholder").show();
	});    
	         }
	});
		 $("#tablediv1").show();
	    	 if(ct==0)
	    		 {
	    		 $("#tablediv1").hide();
	    		 $("#noting").show();
	    		 }
	    	 });
});

$(document).ready(function() {
	 $("#tablediv").hide();
	 $("#tablediv1").hide();
	 //document.getElementById("MainPopupIframe").value=ipaddr;
	 $("#showad").click(function(event){
	    	 adminid=getCookie("adminid");
	    	 //alert(adminid);
	           $.get('rest/admin/'+adminid,function(responseJson) {
	            if(responseJson!=null){
	                $("#showadp").find("tr:gt(0)").remove();
	                //var table1 = $("#showadp");
	                $.each(responseJson, function(key,value) {
	                	document.getElementById("aid").innerHTML=value.admin_Id;
	                	document.getElementById("aei").innerHTML=value.admin_email;
	                });
	                }
	            });
	            $("#tablediv").show();
	  });      
	});
var ct=0;


function clearem(patid)
{
	xmlHttp  = GetXmlHttpObject();
//	alert(iservice+" "+spid);
	var req_url = 'rest/admin/clearemergency/'+patid;
	SendAsync_GETRequest(xmlHttp,req_url,null,resp);
}

var img_url,xx;
function getemergency(lat,log)
{
//	if (navigator.geolocation)
//    {
//    navigator.geolocation.watchPosition(showPosition);
//    }
//  else{
//	  alertify.alert("Geolocation is not supported by this browser.");
//  }
//	
//}
	//alert(lat+" "+log);
	 var latlon=lat+","+log;
	  	img_url="http://maps.googleapis.com/maps/api/staticmap?center="
	   +latlon+"&zoom=14&size=400x300&maptype=roadmap&marker=color:red&sensor=false";
	  	//document.getElementById("mapholder").innerHTML="<img src='"+img_url+"'>";
}
	xx=document.getElementById("demo");
	function getLocation()
	  {
	  if (navigator.geolocation)
	    {
	    navigator.geolocation.getCurrentPosition(showPosition,showError);
	    }
	  else{x.innerHTML="Geolocation is not supported by this browser.";}
	  }

	function showPosition(position)
	  {
	 // var latlon=position.coords.latitude+","+position.coords.longitude;
	  var latlon=lat+","+log;
	  	img_url="http://maps.googleapis.com/maps/api/staticmap?center="
	   +latlon+"&zoom=14&size=400x300&maptype=roadmap&markers=color:red&sensor=false";
	  // $("#imdservice").hide();
	  // create a service by geting the latitude and logitude of the patient
		// to get immediate ambulance by admin profile granting the service on
		// his profils tab immediate service(1st tab)....
	  }

	function showError(error)
	  {
	  switch(error.code) 
	    {
	    case error.PERMISSION_DENIED:
	      xx.innerHTML="The request for Geolocation denied .";
	      break;
	    case error.POSITION_UNAVAILABLE:
	      xx.innerHTML="Location information is unavailable.";
	      break;
	    case error.TIMEOUT:
	     xx.innerHTML="The request to get user location timed out.";
	      break;
	    case error.UNKNOWN_ERROR:
	      xx.innerHTML="An unknown error occurred.";
	      break;
	    }
	  }

	
	function SendAsync_GETRequest(post_xmlHttp, post_url, post_params, resFunction)
	{
	  try
	  {
	      post_xmlHttp.onreadystatechange = resFunction;
	     // post_url = post_url.replace(/\|/g, "%7C");
	      post_xmlHttp.open("GET",post_url,true);
	      post_xmlHttp.setRequestHeader("Content-type", "application/json");
	      //post_xmlHttp.setRequestHeader("Content-length", post_params.length);
	      //post_xmlHttp.setRequestHeader("Connection", "close");
	      post_xmlHttp.send();
	  }
	  catch(e)
	  {
		  alertify.alert('<h3> Server is not Responding... some Problem in server</h3>');
	  }
	}
	var responseJson;
	function resp()
	{
		if(xmlHttp.readyState == 4 && xmlHttp.status == 200) {
			var json_resp =  xmlHttp.responseText;	//Json response
			if(json_resp!=null)
			{
				alertify.alert("<h3>Emergency Cleared</h3>");
			}
			else
			{
				alertify.alert("<h3>Server Problem</h3>");
			}
		}
	}

	
	var xmlHttp;
	function GetXmlHttpObject() {

		var xmlHttp = null;
		try {
			// Firefox, Opera 8.0+, Safari
			xmlHttp = new XMLHttpRequest();

		} catch (e) {
			// Internet Explorer
			try {
				xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
			}
		}

		return xmlHttp;
	}
