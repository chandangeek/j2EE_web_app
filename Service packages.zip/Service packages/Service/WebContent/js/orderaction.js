function test() {
	var formData = form2object('fff', '.', true, function(node) {
		if (node.id && node.id.match(/www/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	result = JSON.stringify(formData, null, '\t');
	//alert(result);
	registerUser();
}
var xmlHttp;
function registerUser() {
	xmlHttp = GetXmlHttpObject();
	var req_url = 'rest/medicationservice/placeorder';
	var params = result;
	//alert(params);
	SendAsync_PostRequest(xmlHttp, req_url, params, registration_resp);
}

function registration_resp() {
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText; //Json response
		if (json_resp != null) {
			alertify.alert("<h3>Your Order is Placed Suceesfully!!</h3>");
		}
	}
}

function SendAsync_PostRequest(post_xmlHttp, post_url, post_params, resFunction) {
	try {
		post_xmlHttp.onreadystatechange = resFunction;
		// post_url = post_url.replace(/\|/g, "%7C");
		post_xmlHttp.open("POST", post_url, true);
		post_xmlHttp.setRequestHeader("Content-type", "application/json");
		//post_xmlHttp.setRequestHeader("Content-length", post_params.length);
		//post_xmlHttp.setRequestHeader("Connection", "close");
		post_xmlHttp.send(post_params);
	} catch (e) {
		alertify.alert('<h3>Server is not Responding... some Problem in server</h3>');
	}
}
function GetXmlHttpObject() {

	var xmlHttp = null;
	try {
		// Firefox, Opera 8.0+, Safari
		xmlHttp = new XMLHttpRequest();

	} catch (e) {
		// Internet Explorer
		try {
			xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}

	return xmlHttp;
}
var price1=0,medName,medDosage;

function start()
{
    $.get('rest/medicationservice/productprice/'+medName+'/'+medDosage,function(responseJson) {
     if(responseJson!=null){
         $.each(responseJson, function(key,value) { 
        	 price1=value.price;
        	 //alert(price1);
        		price1=price1*qty;
        		//document.getElementById("").innerHTML="price: "+price1;
        		document.getElementById("cost").value=price1;
         });
         }
     });
}     
var qty;
function setprice()
{
	qty=document.getElementById("qty").value;
	medName=document.getElementById("medname").value;
	medDosage=document.getElementById("meddosage").value;
	//price1=document.getElementById("price").value;
	start();

}