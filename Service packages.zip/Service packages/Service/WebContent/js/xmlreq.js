var result;
function spcall() {
	var formData = form2object('f', '.', true, function(node) {
		if (node.id && node.id.match(/qqq/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	var json = JSON.stringify(formData, null, '\t');
	//alert(json);
	result = json;
	registerSp();
}

//	$.ajax({
//            type: "POST",
//            url: "rest/serviceprovider/spinsert",
//            data: json,
//            dataType: "json"
//        .done(function() { 
//            alert("Success!!");    
//			window.location.replace("login.html");
//        }).fail(function() { 
//            alert("Failed to add to-do"); 
//        })
//	});
function registerSp() {
	xmlHttp = GetXmlHttpObject();
	var req_url = 'rest/serviceprovider/spinsert';
	var params = result;
	SendAsync_PostRequest(xmlHttp, req_url, params, registration_resp);
}

function test() {
	var formData = form2object('fff', '.', true, function(node) {
		if (node.id && node.id.match(/www/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	result = JSON.stringify(formData, null, '\t');
	//alert(result);
	registerUser();
}
var xmlHttp;
function registerUser() {
	xmlHttp = GetXmlHttpObject();
	var req_url = 'rest/patient/addpatient';
	var params = result;
	SendAsync_PostRequest(xmlHttp, req_url, params, registration_resp);
}

function registration_resp() {
	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
		var json_resp = xmlHttp.responseText; //Json response
		if (json_resp != null) {
			//alert("Welcome, " + json_resp+ " to our portal, you have registerd successfully!!!");
			window.location.replace("login.html?patid="+json_resp);
		}
	}
}

function SendAsync_PostRequest(post_xmlHttp, post_url, post_params, resFunction) {
	try {
		post_xmlHttp.onreadystatechange = resFunction;
		// post_url = post_url.replace(/\|/g, "%7C");
		post_xmlHttp.open("POST", post_url, true);
		post_xmlHttp.setRequestHeader("Content-type", "application/json");
		//post_xmlHttp.setRequestHeader("Content-length", post_params.length);
		//post_xmlHttp.setRequestHeader("Connection", "close");
		post_xmlHttp.send(post_params);
	} catch (e) {
		alertify.alert('<h3>Server is not Responding... some Problem in server</h3>');
	}
}
function GetXmlHttpObject() {

	var xmlHttp = null;
	try {
		// Firefox, Opera 8.0+, Safari
		xmlHttp = new XMLHttpRequest();

	} catch (e) {
		// Internet Explorer
		try {
			xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}

	return xmlHttp;
}

function doccall() {
	var formData = form2object('ff', '.', true, function(node) {
		if (node.id && node.id.match(/zzz/)) {
			return {
				name : node.id,
				value : node.innerHTML
			};
		}
	});

	var json = JSON.stringify(formData, null, '\t');
	//alert(json);
	result = json;
	registerDoc();
}

function registerDoc() {
	xmlHttp = GetXmlHttpObject();
	var req_url = 'rest/doctor/adddoctor';
	var params = result;
	SendAsync_PostRequest(xmlHttp, req_url, params, registration_resp);
}