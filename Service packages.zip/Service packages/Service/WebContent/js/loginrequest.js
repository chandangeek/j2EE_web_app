/* function loadUserData() {
	alert('start');
	var htmlContent ="<table><th>Medicine Name</th><th>Dosage<th>";
	//alert('test');
	
	var xmlhttp;
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
	    {
	     alert(xmlhttp.responseText);
	    }
	  }
	  
	xmlhttp.open("POST","http://localhost:8080/RESTSample/rest/patient/add",true);
	xmlhttp.send();
	alert(xmlhttp.reponseText);
	
	$.getJSON("xmlhttp.responseText", function(obj) {
		$.each(obj, function(key, value) {
			htmlContent += "<tr><td>"+value.medName +"</td>"+"<td>"+value.medDosage +"</td></tr>";
			//alert(value.medName);
		});
	});
	alert('end');
} */
function ajax_json()
{
	var hr=new XMLHttpRequest();
	var url="";
	var email=form1.email.value;
	var pass=form1.password.value;
	varinp=
	hr.open("POST",url,true);
	hr.setRequestHeader("Context-text","application/x-www-form-urlencoded");
	hr.onreadysateexchange=function()
	{
	if(hr.readyState == 4 && hr.status == 200)
	{
	var return_data=hr.responceText;
	document.getElementById("status").innerHTML=return_data;
	}
	
	hr.send(inp);
	document.getElementById("status").innerHTML="processing....";
}
}