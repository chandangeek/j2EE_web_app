$(document).ready(function() {
	 $("#tablediv").hide();
//	     $("#showTable").mouseover(function(event){
	 	$("#bdy").click(function(event){
	 		spid=getCookie("patid");
	 		//alert(docid);
	           $.get('rest/serviceprovider/'+docid,function(responseJson) {
	            if(responseJson!=null){
	                $("#patienttable").find("tr:gt(0)").remove();
	                var table1 = $("#patienttable");
	                $.each(responseJson, function(key,value) { 
	                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
	                        rowNew.children().eq(0).text(value['patId']); 
	                        rowNew.children().eq(1).text(value['patName']); 
	                        rowNew.children().eq(2).text(value['patDob']); 
	                        rowNew.children().eq(3).text(value['patBloodGroup']); 
	                        rowNew.children().eq(4).text(value['patAddress']); 
	                        rowNew.children().eq(5).text(value['patCity']);
	                        rowNew.children().eq(6).text(value['patState']);
	                        rowNew.children().eq(7).text(value['patPhone']);
	                        rowNew.children().eq(8).text(value['patEmail']);
	                        rowNew.children().eq(9).text(value['patGender']);
	                        rowNew.appendTo(table1);
	                });
	                }
	            });
	            $("#tablediv").show();          
	   });      
	});


$(document).ready(function() {
	 $("#tablediv4").hide();
	     $("#showSp").click(function(event){
	    	 spid=getCookie("patid");
	           $.get('rest/doctor/appointment/'+docid,function(responseJson) {
	            if(responseJson!=null){
	                $("#appointmenttable").find("tr:gt(0)").remove();
	                var table1 = $("#appointmenttable");
	                $.each(responseJson, function(key,value) { 
	                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
	                        rowNew.children().eq(0).text(value['appointId']); 
	                        rowNew.children().eq(1).text(value['patId']);
	                        rowNew.children().eq(2).text(value['docId']);
	                        rowNew.children().eq(3).text(value['appointDersc']);
	                        rowNew.children().eq(4).text(value['appointTimming']); 
	                        rowNew.children().eq(5).text(value['appointDate']); 
	                        rowNew.children().eq(6).text(value['appointStatus']); 
	                        rowNew.appendTo(table1);
	                });
	                }
	            });
	            $("#tablediv4").show();          
	  });      
	});
