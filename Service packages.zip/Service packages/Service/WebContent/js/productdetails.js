var medN="medName";
var medD="medDosage";
var medName,medDosage;
	function abc()
	{
		$("#row2").hide();
		//getmedicine();		
	}
// 	function getCookie(name) {
// 		  var value = "; " + document.cookie;
// 		  var parts = value.split("; " + name + "=");
// 		  if (parts.length == 2) return parts.pop().split(";").shift();
// 		}
	function getmedicine()
	{
		$(document).ready(function() {
// 			$("#taskmsg").hide();
// 			$("#col2").hide();
			 $("#tablediv").hide();
//			     $("#showTable").mouseover(function(event){
			 	$("#bdy").mouseover(function(event){
			 		medName=getCookie(medN);
					medDosage=getCookie(medD);
					//alert(medName);
					//alert(medDosage);
			           $.get('rest/medicationservice/rmed/'+medName+"/"+medDosage,function(responseJson) {
			            if(responseJson!=null){
			                $("#table").find("tr:gt(0)").remove();
			                var table1 = $("#table");
			                $.each(responseJson, function(key,value) { 
			                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
			                        rowNew.children().eq(0).text(value['productId']); 
			                        rowNew.children().eq(1).text(value['productName']); 
			                        rowNew.children().eq(2).text(value['productDosage']); 
			                        rowNew.children().eq(3).text(value['stock']); 
			                        rowNew.children().eq(4).text(value['status']); 
			                        rowNew.children().eq(5).text(value['price']);
			                        rowNew.appendTo(table1);
			                });
			                }
			            });
			            $("#tablediv").show();          
			   });      
			});
	}
	function getCookie(cname)
	{
	var name = cname + "=";
 	var ca = document.cookie.split(';');
 	for(var i=0; i<ca.length; i++) 
 	  {
 	  var c = ca[i].trim();
 	  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
 	  }
 	return "";
 	}
	function getproducts()
	{
		$(document).ready(function() {
// 			$("#taskmsg").hide();
// 			$("#col2").hide();
			 $("#tablediv").hide();
//			     $("#showTable").mouseover(function(event){
			 	$("#bdy").mouseover(function(event){
// 			 		medName=getCookie(medN);
// 					medDosage=getCookie(medD);
// 					alert(medName);
// 					alert(medDosage);
			           $.get('rest/medicationservice',function(responseJson) { // +'/rmed/'+medName+'/'+medDosage
			            if(responseJson!=null){
			                $("#table").find("tr:gt(0)").remove();
			                var table1 = $("#table");
			                var i=1;
			                $.each(responseJson, function(key,value) { 
			                	
			                document.getElementById("productId"+i).innerHTML=value.productId;
			                document.getElementById("productName"+i).innerHTML=value.productName;
			                document.getElementById("productDosage"+i).innerHTML=value.productDosage;
			                document.getElementById("stock"+i).innerHTML=value.stock;
			                document.getElementById("status"+i).innerHTML=value.status;
			                document.getElementById("price"+i).innerHTML=value.price;
			                i+=1;
// 			                     var rowNew = $("<tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>");
// 			                        rowNew.children().eq(0).text(value['productId']); 
// 			                        rowNew.children().eq(1).text(value['productName']); 
// 			                        rowNew.children().eq(2).text(value['productDosage']); 
// 			                        rowNew.children().eq(3).text(value['stock']); 
// 			                        rowNew.children().eq(4).text(value['status']); 
// 			                        rowNew.children().eq(5).text(value['price']);
// 			                        rowNew.appendTo(table1);
			                });
			                }
			            });
			            $("#tablediv").show();          
			   });      
			});
	
	}