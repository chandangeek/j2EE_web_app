package com.pharma.model;

public class Products {
	
	int productId;
	String productName;
	String productDosage;
	String stock;
	String status;
	String price;
	
	Products()
	{
		super();
	}
	
	public Products(int productId,String productName,String productDosage,String stock,String status,String price)
	{
		this.productId=productId;
		this.productName=productName;
		this.productDosage=productDosage;
		this.stock=stock;
		this.status=status;
		this.price=price;
	}
	
	public Products(String price)
	{
		this.price=price;
	}
	
	public String getProductDosage() {
		return productDosage;
	}

	public void setProductDosage(String productDosage) {
		this.productDosage = productDosage;
	}

	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	
	
}

