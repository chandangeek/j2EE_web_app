package com.pharma.model;

public class Order {
	
	int o_id;
	String pat_name;
	String med_name;
	String med_dosage;
	String med_quantity;
	String med_price;
	String status;
	
	public Order()
	{
		super();
	}
	
	public Order(int o_id,String pat_name,String med_name,String med_dosage,String med_quantity,String med_price,String status)
	{
		this.o_id=o_id;
		this.pat_name=pat_name;
		this.med_name=med_name;
		this.med_dosage=med_dosage;
		this.med_quantity=med_quantity;
		this.med_price=med_price;
		this.status=status;
	}
	
	public Order(String pat_name,String med_name,String med_dosage,String med_quantity,String status,String med_price)
	{
		this.pat_name=pat_name;
		this.med_name=med_name;
		this.med_dosage=med_dosage;
		this.med_quantity=med_quantity;
		this.med_price=med_price;
		this.status=status;
	}
	public Order(String pat_name,String med_name,String med_dosage,String med_price)
	{
		this.pat_name=pat_name;
		this.med_name=med_name;
		this.med_dosage=med_dosage;
		this.med_price=med_price;
	}
	
	public Order(String med_price)
	{
		this.med_price=med_price;
	}
	
	
	public String getPat_name() {
		return pat_name;
	}

	public void setPat_name(String pat_name) {
		this.pat_name = pat_name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getO_id() {
		return o_id;
	}

	public void setO_id(int o_id) {
		this.o_id = o_id;
	}


	public String getMed_name() {
		return med_name;
	}

	public void setMed_name(String med_name) {
		this.med_name = med_name;
	}

	public String getMed_dosage() {
		return med_dosage;
	}

	public void setMed_dosage(String med_dosage) {
		this.med_dosage = med_dosage;
	}

	public String getMed_quantity() {
		return med_quantity;
	}

	public void setMed_quantity(String med_quantity) {
		this.med_quantity = med_quantity;
	}

	public String getMed_price() {
		return med_price;
	}

	public void setMed_price(String med_price) {
		this.med_price = med_price;
	}

}
