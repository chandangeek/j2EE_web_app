package com.pharma.model;

public class Login {
	private String sp_email;
	private String sp_password;
	private int sp_id;
	
	public Login()
	{
		super();
	}
	public String getSp_email() {
		return sp_email;
	}
	public void setSp_email(String sp_email) {
		this.sp_email = sp_email;
	}
	public String getSp_password() {
		return sp_password;
	}
	public void setSp_password(String sp_password) {
		this.sp_password = sp_password;
	}
	public int getSp_id() {
		return sp_id;
	}
	public void setSp_id(int sp_id) {
		this.sp_id = sp_id;
	}
	public Login(int sp_id)
	{
		this.sp_id=sp_id;
	}
	
	public Login(int sp_id,String sp_email,String sp_password)
	{
		this.sp_id=sp_id;
		this.sp_email=sp_email;
		this.sp_password=sp_password;
	}
	public Login(String sp_email,String sp_password)
	{
		this.sp_email=sp_email;
		this.sp_password=sp_password;
	}

}
