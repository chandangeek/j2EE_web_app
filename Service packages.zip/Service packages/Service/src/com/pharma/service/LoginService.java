package com.pharma.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.pharma.model.Login;
import com.pharma.model.ServiceProvider;
import com.pharma.util.DBConnection;


public class LoginService {
	Connection mConnection =  null;
	private Statement stmt = null;
	private PreparedStatement ps= null;
	ResultSet rs= null;
	public int setLogin(Login login) {
		final String FETCH_PATIENT_QUERY = "select sp_id from sp where sp_email=? and sp_password=?;";
		Connection mConnection = null;
		//List<User> userList = new ArrayList<User>();
			//List<User> userInfo = null;
		int res = 0;
		try {
				mConnection = DBConnection.getDBConnection();
				PreparedStatement ps;
				ps = mConnection.prepareStatement(FETCH_PATIENT_QUERY);
				ps.setString(1,(login.getSp_email()));
				ps.setString(2,(login.getSp_password()));
				ResultSet rs = ps.executeQuery();
				if(rs.next())
				{
				login.setSp_id((rs.getInt(1)));
				}
				
				res=login.getSp_id();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return res;
	}
	public List<ServiceProvider> getSpecificSpInfo(int spid) {
		List<ServiceProvider> spInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			//ServiceProvider sp = null;
			//sp.setSpId(spid);
			final String FETCH_USER_QUERY = "select * from sp where sp_id="+spid+";";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			//ps.setInt(1,spid); //sp.getSpId()
			ResultSet rs = ps.executeQuery(FETCH_USER_QUERY);
			spInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return spInfo;
	}
	private List<ServiceProvider> convertPojoList1(ResultSet rs) throws SQLException {

		List<ServiceProvider> spList = new ArrayList<ServiceProvider>();
		while (rs.next()) {
			ServiceProvider sp = new ServiceProvider(rs.getInt(1),rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(8));
			spList.add(sp);
		}
		return spList;
	}

}
