package com.pharma.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.pharma.model.Order;
import com.pharma.model.Products;
import com.pharma.util.DBConnection;

public class PharmaService
{
	Connection mConnection =  null;
	private Statement stmt = null;
	private PreparedStatement ps= null;
	ResultSet rs= null;
	public List<Products> getMedicationInfo(String medName,String medDosage)
	{
		List<Products> productInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			//Products product = null;
			//product.setPatId(patname);
			final String FETCH_USER_QUERY = "select * from products where product_name='"+medName+"' and product_dosage='"+medDosage+"';";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			ResultSet rs = ps.executeQuery();
			productInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return productInfo;
	}

	private List<Products> convertPojoList1(ResultSet rs) throws SQLException {

		List<Products> productList = new ArrayList<Products>();
		while (rs.next()) {
			Products product = new Products(rs.getInt(1),rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
			productList.add(product);
		}
		return productList;
	}
	
	public List<Products> getAllMedicines()
	{
		List<Products> medicines =null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			//Products product = null;
			//product.setPatId(patname);
			final String FETCH_SP_QUERY = "select * from products;";
			ps = mConnection.prepareStatement(FETCH_SP_QUERY);
			ResultSet rs = ps.executeQuery();
			medicines = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return medicines;
	}
	
	public List<Order> getorders(String patname)
	{
		List<Order> returninfo=null;
		final String FETCH_USER_QUERY = "SELECT * FROM orders where pat_name="+patname+";";
		try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				//Patient patient=null;
//				ps.setInt(1,patname);
				ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
				returninfo = convertPojoList13(rs11);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return returninfo;
	}
	private List<Order> convertPojoList13(ResultSet rs) throws SQLException {

		List<Order> patientList = new ArrayList<Order>();
		while (rs.next()) {
			Order patientor = new Order(rs.getInt(1), rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
			patientList.add(patientor);
		}
		return patientList;
	}
	private List<Order> convertPojoList14(ResultSet rs,String pname) throws SQLException {

		List<Order> patientList = new ArrayList<Order>();
		while (rs.next()) {
			Order patientor = new Order(pname, rs.getString(2),rs.getString(3),rs.getString(6));
			patientList.add(patientor);
		}
		return patientList;
	}
	
	public List<Products> getProductDetails()
	{
		List<Products> productlist=null;
		
		Connection Pharmacon = DBConnection.getDBConnection();
		String query="select * from products;";
		try {
			stmt = Pharmacon.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			productlist= convertPojoList11(rs);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			}
		catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return productlist;
	}
	private List<Products> convertPojoList11(ResultSet rs) throws SQLException {

		List<Products> prodlist = new ArrayList<Products>();
		while (rs.next()) {
			Products prod = new Products(rs.getInt(1),rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
			prodlist.add(prod);
		}
		return prodlist;
	}
	
	public List<Order> getrproduct(String pname,String mname,String mdosage)
	{
		List<Order> list=null;
		final String FETCH_USER_QUERY = "SELECT * FROM orders where pat_name='"+pname+"' and "+"med_name='"+mname+"';";
		try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				//Patient patient=null;
//				ps.setInt(1,patname);
				ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
				if(rs11.next())
				{
					return null;
				}
				else
				{
					final String FETCH_QUERY = "select * from products where product_name='"+mname+"' and product_dosage='"+mdosage+"';";
					ps = mConnection.prepareStatement(FETCH_QUERY);
					ResultSet rs = ps.executeQuery();
					list = convertPojoList14(rs,pname);
				}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			}
		catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
		
	}
	public String getmyurl(int sid)
	{
		String myurl=null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			ResultSet rs = stmt.executeQuery("select sp_url from sp where sp_id="+sid+";");
			if(rs.next())
			{
				myurl=rs.getString(1);
			//	System.out.println(myurl);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return myurl;
	}
	
}


	
