package com.pharma.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.pharma.model.Order;
import com.pharma.model.Products;
import com.pharma.util.DBConnection;

public class OrderService {

	Connection mConnection = null;
	private Statement stmt = null;
	private PreparedStatement ps = null;
	ResultSet rs = null;

	public List<Order> getAllPatientOrderInfo() {
		final String FETCH_ORDER_QUERY = "SELECT * FROM orders;";
		List<Order> orderInfo = null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			ResultSet rs = stmt.executeQuery(FETCH_ORDER_QUERY);
			orderInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return orderInfo;
	}

	public int setOrderList(Order order) {

		final String FETCH_USER_QUERY = "INSERT INTO orders values(?,?,?,?,?,?,'')";

		Connection mConnection = null;

		int odrid = 0;
		try {
			mConnection = DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			stmt = mConnection.createStatement();
			String medname = order.getMed_name();
			String meddosage = order.getMed_dosage();
			ResultSet rs11 = stmt.executeQuery("select product_id from products where product_name="
							+ medname
							+ " and product_dosage="
							+ meddosage
							+ ";");
			if (rs11.next()) {
				// Product and order checking???
				ResultSet rs = stmt.executeQuery("select max(o_id) from orders;");
				if (rs.next()) {
					odrid = rs.getInt(1);
					odrid += 1;
					order.setO_id(odrid);
				}
				ps.setInt(1, order.getO_id());
				ps.setString(2, order.getPat_name());
				ps.setString(3, order.getMed_name());
				ps.setString(4, order.getMed_dosage());
				ps.setString(5, order.getMed_quantity());
				ps.setString(6, order.getMed_price());
				ps.executeUpdate();
				// userInfo = convertPojoList(rs);
			} else {
				odrid=-1;
			}
		}

		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return odrid;
	}

	private List<Order> convertPojoList1(ResultSet rs) throws SQLException {

		List<Order> orderList = new ArrayList<Order>();
		while (rs.next()) {
			Order order = new Order(rs.getInt(1), rs.getString(2),rs.getString(3), rs.getString(4), rs.getString(5),rs.getString(6),rs.getString(7));
			orderList.add(order);
		}
		return orderList;
	}

	// public int PatientOrderId(Order order) {
	//
	// final String FETCH_USER_QUERY =
	// "SELECT odr_id FROM orders innerjoin product on order.odr_id=product.odr_id where odr_id =? ";
	// int res = 0;
	// Connection mConnection = null;
	// Statement stmt = null;
	// PreparedStatement ps= null;
	// //List<Patient> patientInfo = null;
	// try {
	// mConnection = DBConnection.getDBConnection();
	// ps = mConnection.prepareStatement(FETCH_USER_QUERY);
	// ps.setInt(1, order.getOdrId());
	// ps.setString(2,order.getMedName());
	// ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
	// if(rs.next())
	// {
	// res=rs11.getInt(1);
	// }
	// //patientInfo.add(res); //convertPojoList(rs11);
	// } catch (Exception e) {
	// e.printStackTrace();
	// } finally {
	// try {
	// if (stmt != null) {
	// stmt.close();
	// }
	// if (mConnection != null) {
	// mConnection.close();
	// }
	// } catch (SQLException e) {
	// e.printStackTrace();
	// }
	// }
	// return res;
	// }
	public List<Order> setOrderInformation(String patname) {

		final String FETCH_USER1_QUERY = "SELECT * FROM orders where pat_name="
				+ patname + ";";
		List<Order> orderInfo = null;
		try {

			mConnection = DBConnection.getDBConnection();
			PreparedStatement ps = null;
			ps = mConnection.prepareStatement(FETCH_USER1_QUERY);
			// ps.setInt(1, odrid);
			// Patient patient=null;
			// patient.setPatId(patname);
			// ps.setInt(1,patient.getPatId());
			/*
			 * ResultSet rs2= ps.executeQuery(); medicineInfo =
			 * convertPojoList1(rs2);
			 */
			ResultSet rs11 = ps.executeQuery(FETCH_USER1_QUERY);
			orderInfo = convertPojoList1(rs11);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return orderInfo;
	}

	public List<Products> getSpecificPrice(String medname, String meddosage) {
		final String FETCH_USER1_QUERY = "SELECT price FROM products where product_name='"+ medname + "'and product_dosage='" + meddosage + "';";
		List<Products> price = new ArrayList<Products>();

		try {
			mConnection = DBConnection.getDBConnection();
			PreparedStatement ps = null;
			ps = mConnection.prepareStatement(FETCH_USER1_QUERY);
			// ps.setInt(1, odrid);
			// Patient patient=null;
			// patient.setPatId(patname);
			// ps.setInt(1,patient.getPatId());
			/*
			 * ResultSet rs2= ps.executeQuery(); medicineInfo =
			 * convertPojoList1(rs2);
			 */
			ResultSet rs11 = ps.executeQuery(FETCH_USER1_QUERY);
			if (rs11.next()) {
				Products product = new Products(rs11.getString(1));
				price.add(product);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return price;
	}

	public String setorders(String patname, String medname, String meddosage,
			String medqty, String medprice) {
		final String FETCH_USER_QUERY = "INSERT INTO orders values(?,?,?,?,?,?,'')";

		Connection mConnection = null;

		int odrid = 0;
		String rest = null;
		try {
			mConnection = DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			stmt = mConnection.createStatement();
			// Product and order checking???
			ResultSet rs11 = stmt.executeQuery("select product_id from products where product_name='"
							+ medname
							+ "' and product_dosage='"
							+ meddosage
							+ "';");
			if (rs11.next()) {
				// int prodid=rs.getInt(1);
				ResultSet rs = stmt
						.executeQuery("select max(o_id) from orders;");
				if (rs.next()) {
					odrid = rs.getInt(1);
					odrid += 1;
				}
				Order order=new Order(odrid,patname,medname,meddosage,medqty,medprice,null);
				ps.setInt(1, order.getO_id());
				ps.setString(2, order.getPat_name());
				ps.setString(3, order.getMed_name());
				ps.setString(4, order.getMed_dosage());
				ps.setString(5, order.getMed_quantity());
				ps.setString(6, order.getMed_price());
				int res = ps.executeUpdate();
				if (res > 0) {
					rest = "<html><head></head><body><div>Your order is successfully placed, your orderid is "
							+ odrid
							+ " <a href=\"http://192.168.8.178:8080/Service/index.html\">click here</a> to place more orders.</div> </body></html>";
				} else {
					rest = " <html><head></head><body><div>Your Order is not placed, please <a href=\"http://192.168.8.178:8080/Service/orderform.html\">click here</a> to order again</div></body></html>";
				}
			} else {
				rest = "<html><head></head><body><div>Sorry, this product is not available with us <a href=\"http://192.168.8.178:8080/Service/index.html\"click here</a> to go to home page</div></body></html>";
			}
			// userInfo = convertPojoList(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return rest;
	}
	
	public int setorder(String patname, String medname, String meddosage,String medqty, String medprice) {
		final String FETCH_USER_QUERY = "INSERT INTO orders values(?,?,?,?,?,?,'')";

		Connection mConnection = null;

		int odrid = 0;
		String rest = null;
		try {
			mConnection = DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			stmt = mConnection.createStatement();
			// Product and order checking???
			ResultSet rs11 = stmt.executeQuery("select product_id from products where product_name='"
							+ medname
							+ "' and product_dosage='"
							+ meddosage
							+ "';");
			if (rs11.next()) {
				// int prodid=rs.getInt(1);
				ResultSet rs = stmt
						.executeQuery("select max(o_id) from orders;");
				if (rs.next()) {
					odrid = rs.getInt(1);
					odrid += 1;
				}
				Order order=new Order(odrid,patname,medname,meddosage,medqty,medprice,null);
				ps.setInt(1, order.getO_id());
				ps.setString(2, order.getPat_name());
				ps.setString(3, order.getMed_name());
				ps.setString(4, order.getMed_dosage());
				ps.setString(5, order.getMed_quantity());
				ps.setString(6, order.getMed_price());
				int res = ps.executeUpdate();
				if (res > 0) {
					rest = "<html><head></head><body><div>Your order is successfully placed, your orderid is "
							+ odrid
							+ " <a href=\"http://192.168.8.178:8080/Service/index.html\">click here</a> to place more orders.</div> </body></html>";
				} else {
					rest = " <html><head></head><body><div>Your Order is not placed, please <a href=\"http://192.168.8.178:8080/Service/orderform.html\">click here</a> to order again</div></body></html>";
				}
			} else {
				odrid=-1;
				rest = "<html><head></head><body><div>Sorry, this product is not available with us <a href=\"http://locahost:8080/Service/index.html\"click here</a> to go to home page</div></body></html>";
			}
			// userInfo = convertPojoList(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return odrid;
	}
	
	public List<Order> setstatus(int oid,String status)
	{
		List<Order> res=null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			String FETCH_USER_QUERY = "update orders set status='"+status+"' where o_id="+oid+";";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			int rest=ps.executeUpdate(FETCH_USER_QUERY);
			if(rest>0)
			{
				FETCH_USER_QUERY = "select * from orders where o_id="+oid+";";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				ResultSet rs=ps.executeQuery(FETCH_USER_QUERY);
				res=convertPojoList1(rs);
			}
			//appointInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
	
	public List<Order> getorders(String patname)
	{
		List<Order> returninfo=null;
		final String FETCH_USER_QUERY = "SELECT * FROM orders where pat_name='"+patname+"';";
		try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				//Patient patient=null;
//				ps.setInt(1,patname);
				ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
				returninfo = convertPojoList13(rs11);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return returninfo;
	}
	
	private List<Order> convertPojoList13(ResultSet rs) throws SQLException {

		List<Order> patientList = new ArrayList<Order>();
		while (rs.next()) {
			Order patientor = new Order(rs.getInt(1), rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
			patientList.add(patientor);
		}
		return patientList;
	}
	

	public List<Order> getAllOrders()
	{
		List<Order> orderlist=null;
		
		Connection Pharmacon = DBConnection.getDBConnection();
		String query="select * from orders;";
		try {
			stmt = Pharmacon.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			orderlist= convertPojoList12(rs);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			}
		catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return orderlist;
	}
	private List<Order> convertPojoList12(ResultSet rs) throws SQLException {

		List<Order> ordlist = new ArrayList<Order>();
		while (rs.next()) {
			Order ord = new Order(rs.getInt(1),rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
			ordlist.add(ord);
		}
		return ordlist;
	}
	public int checkorderedmedicine(String patname,String medname)
	{
		int res=0;
		final String FETCH_USER_QUERY = "SELECT o_id FROM orders where pat_name="+patname+" and med_name='"+medname+"';";
		try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				//Patient patient=null;
//				ps.setInt(1,patname);
				ResultSet rs11 = ps.executeQuery(FETCH_USER_QUERY);
				if(rs11.next())
				{
					res=rs11.getInt(1);
				}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return res;
	}
	
	public int setorders(Order order)
	{
		int res = 0;
		final String FETCH_USER_QUERY = "INSERT INTO orders values(?,?,?,?,?,?,'not delivered')";

		Connection mConnection = null;

		int odrid = 0;
//		String rest = null;
		try {
			mConnection = DBConnection.getDBConnection();
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			stmt = mConnection.createStatement();
			// Product and order checking???
//			ResultSet rs11 = stmt.executeQuery("select product_id from products where product_name='"
//							+ order.getMed_name()
//							+ "' and product_dosage='"
//							+ order.getMed_dosage()
//							+ "';");
//			if (rs11.next()) {
				// int prodid=rs.getInt(1);
				ResultSet rs = stmt.executeQuery("select max(o_id) from orders;");
				if (rs.next()) {
					odrid = rs.getInt(1);
					odrid += 1;
				}
//			}
//				Order order=new Order(odrid,patname,medname,meddosage,medqty,medprice,null);
				ps.setInt(1, order.getO_id());
				ps.setString(2, order.getPat_name());
				ps.setString(3, order.getMed_name());
				ps.setString(4, order.getMed_dosage());
				ps.setString(5, order.getMed_quantity());
				ps.setString(6, order.getMed_price());
				ps.executeUpdate();
				res=odrid;
			}catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		return res;
	}
	
	@SuppressWarnings("null")
	public List<Order> setprices(String mname,String meddos)
	{
		List<Order> list=null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			// Product and order checking???
			ResultSet rs11 = stmt.executeQuery("select price from products where product_name='"
							+ mname
							+ "' and product_dosage='"
							+ meddos
							+ "';");
			if (rs11.next()) {
				Order order=new Order(rs11.getString(1));
				list.add(order);
			}
		}catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public String deleteorder(int oid)
	{
		String res="failure";
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			String FETCH_USER_QUERY = "delete from orders where o_id="+oid+";";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			int rest=ps.executeUpdate();
			if(rest>0)
			{
				res="success";
			}
			//appointInfo = convertPojoList1(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return res;
	}
}
