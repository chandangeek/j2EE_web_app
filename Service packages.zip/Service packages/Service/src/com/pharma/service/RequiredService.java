package com.pharma.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.pharma.util.DBConnection;

public class RequiredService {
	Connection mConnection;
	Statement stmt=null;
	PreparedStatement ps;
	public String setRequiredMedicines(String medName,String medDosage)
	{
			String productinfo = null;
			try {
				mConnection = DBConnection.getDBConnection();
				//Products product = null;
				//product.setPatId(patid);
				final String FETCH_USER_QUERY = "select * from products where product_name=? and product_dosage=?;";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				ps.setString(1, medName);
				ps.setString(2, medDosage);
				ResultSet rs = ps.executeQuery();
				//productInfo = convertPojoList1(rs);
				if(rs.next())
				{
				productinfo="<html><head><style>iframe{	}</style><script src=\"http://code.jquery.com/jquery-latest.min.js\"></script><script> function validatepatid(){	var num=document.getElementById(\"patid\");	if((num.value==null)||(num.value=='')){		alert(\"Please Enter patient id\");		return false;	}	return true;	} function validatemedquantity(){	var num=document.getElementById(\"med_quantity\");	if((num.value==null)||(num.value=='')){		alert(\"Please Enter quantity\");		return false;	}	return true;} function validateall(){	var aa=validatepatid();	var bb=validatemedquantity();	if(aa==true && bb==true )	{	test();	}	else 	{	return false;	}}"
						+"var a,b,c,d,f,totalprice; function test(){ a=document.getElementById(\"patid\").value; b=document.getElementById(\"med_name\").value; c=document.getElementById(\"med_dosage\").value; d=document.getElementById(\"med_quantity\").value; e=document.getElementById(\"med_price\").value; test1(); }"
						+ "var xmlHttp,result;function test1() {	xmlHttp = GetXmlHttpObject();	f=totalprice; var req_url = 'http:// 192.168.9.1:8080/Service/rest/medicationservice/setorder/'+a+'/'+b+'/'+c+'/'+d+'/'+f;	var params = result;	SendAsync_PostRequest(xmlHttp, req_url, null, registration_resp);}function registration_resp() {	if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {	var json_resp = xmlHttp.responseText;	if (json_resp != '-1') { alert('Your Order is Placed Succesfully!! Your Order Id is ' + json_resp); $(\"#res1\").hide();} else{alert(\"your order is not placed--internal server error\");}}}function SendAsync_PostRequest(post_xmlHttp, post_url, post_params, resFunction) {try {	post_xmlHttp.onreadystatechange = resFunction;post_xmlHttp.open('POST', post_url, true);post_xmlHttp.setRequestHeader('Content-type', 'application/json');post_xmlHttp.send();} catch (e) {	alert(' Server is not Responding... some Problem in server');}}function GetXmlHttpObject() {	var xmlHttp = null;	try {	xmlHttp = new XMLHttpRequest();	} catch (e) {	try {	xmlHttp = new ActiveXObject('Msxml2.XMLHTTP');	} catch (e) {	xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');}}return xmlHttp;}"
						+ "function gettotalprice(){ var qty=document.getElementById(\"med_quantity\").value; var uprice=document.getElementById(\"med_price\").value; totalprice=uprice*qty; document.getElementById(\"price\").innerHTML=totalprice; }"
						+ "</script></head><body><div><div id=\"res1\"><div><h1>Medicines Bellow are Required-Order now</h1></div><hr><div><form action='javascript:validateall()' method='post'><table>";
					//int productid=rs.getInt(1);
					String productname=rs.getString(2);
					String productdosage=rs.getString(3);
					String productprice=rs.getString(6);
					productinfo+="<tr><td>Patient Name</td><td><input type='text' id =\"patid\" name='patid'placeholder=\"enter patient id\" ></td></tr><tr><td>Product Name</td><td><input type='text' name='pname' id=\"med_name\" value='"+productname+"' readonly></td></tr><tr><td>Product Dosage</td><td><input type='text' id=\"med_dosage\" name='med_dosage' value='"+productdosage+"' readonly></td></tr><tr><td>Quantity </td><td><input type=\"text\" name=\"med_quantity\" id=\"med_quantity\" placeholder=\"enter Quantity\" onchange=\"gettotalprice();\"></td></tr><tr><td>Unit price:</td><td><input type='text' name='med_price' id=\"med_price\" value='"+productprice+"' readonly></td></tr><tr><td>Total Price: <span id=\"price\"></span></td></tr>";
				productinfo+="</table><input type='submit' value='order'></form></div></div><div><iframe src='http:// 192.168.9.1:8080/Service/' style='width:100%;height:500px;'></div></div>/body></html>";
				}
				else
				{
					productinfo="<html><body><iframe src='http:// 192.168.9.1:8080/Service/' style='width:100%;height:500px;'></body></html>";
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return productinfo;
		}
	}
