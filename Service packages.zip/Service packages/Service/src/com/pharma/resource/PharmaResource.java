package com.pharma.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.pharma.model.Login;
import com.pharma.model.Order;
import com.pharma.model.Products;
import com.pharma.model.ServiceProvider;
import com.pharma.service.LoginService;
import com.pharma.service.OrderService;
import com.pharma.service.PharmaService;
import com.pharma.service.RequiredService;


@Path("/medicationservice")
public class PharmaResource {
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Products> getAllProducts()
	{
		List<Products> list =null;
		PharmaService service=new PharmaService();
		list=service.getAllMedicines();
		return list;
	}
	
	@Path("/rmed/{medName}/{medDosage}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Products> getRequiredMedication(@PathParam("medName") String medName, @PathParam("medDosage") String medDosage)
	{
		PharmaService service=new PharmaService();
		List<Products> htmllist=service.getMedicationInfo(medName,medDosage);
		//String html="<html><body><div style='border:5px solid gray;'><form action='#' method='post'>Medicine Name: ";
		return htmllist;
	}
	
	@Path("/imd/{medName}/{medDosage}")
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String getRequiredMed(@PathParam("medName") String medName,@PathParam("medDosage") String medDosage)
	{
		String rethtml=null;
		RequiredService service=new RequiredService();
		rethtml=service.setRequiredMedicines(medName, medDosage);
		return rethtml;
	}
	
	@Path("/placeorder")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public int getOrder(Order order)
	{
		OrderService service=new OrderService();
		int oid=service.setOrderList(order);
		return oid;
	}
	
	@Path("/patientorderinfo/{patname}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Order> getPatientOrder(@PathParam("patname") String patname)
	{
		List<Order> list=null;
		OrderService service=new OrderService();
		list=service.setOrderInformation(patname);
		return list;
	}
	
	@Path("/productprice/{medname}/{meddosage}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Products> getPrice(@PathParam("medname") String medname,@PathParam("meddosage") String meddosage)
	{
		List<Products> res=null;
		OrderService service=new OrderService();
		res=service.getSpecificPrice(medname,meddosage);
		return res;
	}
	
	
	@Path("/getorder/{patname}/{medname}/{meddosage}/{medqty}/{medprice}")
	@POST
	@Produces(MediaType.TEXT_HTML)
	public String getorders(@PathParam("patname") String patname,@PathParam("medname") String medname,@PathParam("meddosage") String meddosage,@PathParam("medqty") String medqty,@PathParam("medprice") String medprice)
	{
		String res;
		OrderService service=new OrderService();
		res=service.setorders(patname,medname,meddosage,medqty,medprice);
		return res;
	}
	
	@Path("/setorder/{patname}/{medname}/{meddosage}/{medqty}/{medprice}")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public int setorders(@PathParam("patname") String patname,@PathParam("medname") String medname,@PathParam("meddosage") String meddosage,@PathParam("medqty") String medqty,@PathParam("medprice") String medprice)
	{
		int res;
		OrderService service=new OrderService();
		res=service.setorder(patname,medname,meddosage,medqty,medprice);
		return res;
	}
	
	@Path("/update/{oid}/{status}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Order> setorderstatus(@PathParam("oid") int oid,@PathParam("status") String status)
	{
		List<Order> res=null;
		OrderService service=new OrderService();
		res=service.setstatus(oid,status);
		return res;
	}
	
	@Path("/orderedlist/{patname}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Order> getor(@PathParam("patname") String patname)
	{
		OrderService service = new OrderService();
		List<Order> list = service.getorders(patname);
		return list;
	}
	
	@Path("/orders")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Order> getAllOrder()
	{
		List<Order> list=null;
		OrderService service= new OrderService();
		list=service.getAllOrders();
		return list;
	}

	@Path("/products")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Products> getProductsPharma()
	{
		List<Products> list =null;
		PharmaService service=new PharmaService();
		list=service.getProductDetails();
		return list;
	}
	
	@Path("/checkreqmedicine/{patname}/{medname}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public int checkmedicine(@PathParam("patname") String patname,@PathParam("medname") String medname)
	{
		int res;
		OrderService service=new OrderService();
		res=service.checkorderedmedicine(patname,medname);
		return res;
	}
	
	@Path("/orderinsert")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public int placeorders(Order order)
	{
		int res;
		OrderService service = new OrderService();
		res=service.setorders(order);
		return res;
	}
	
	@Path("/imdjson/{patname}/{medname}/{meddosage}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Order> getproducts(@PathParam("patname") String pname,@PathParam("medname") String mname,@PathParam("meddosage") String mdosage)
	{
		List<Order> list=null;
		PharmaService service= new PharmaService();
		list=service.getrproduct(pname,mname,mdosage);
		return list;
		
	}
	
	@Path("/setprice/{medname}/{meddosage}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Order> setprice(@PathParam("medname") String mname,@PathParam("meddosage") String meddos)
	{
		List<Order> list=null;
		OrderService service=new OrderService();
		list=service.setprices(mname,meddos);
		return list;
	}
	
	@Path("/deleteorder/{oid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String deleterorders(@PathParam("oid") int oid)
	{
		String res="failure";
		OrderService service=new OrderService();
		res=service.deleteorder(oid);
		return res;
	}
	@Path("/login")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public int loginsp(Login sp){
		int spid;
		LoginService service = new LoginService();
		spid = service.setLogin(sp);
		return spid;
	}
	@Path("/{spid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<ServiceProvider> getSpInfomatiion(@PathParam("spid") int spid){
		LoginService service = new LoginService();
		List<ServiceProvider> list = service.getSpecificSpInfo(spid);
		return list;
		
	}
	@Path("/geturl/{sid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getspecificurl(@PathParam("sid") int sid)
	{
		String res;
		PharmaService service = new PharmaService();
		res=service.getmyurl(sid);
		return res;
	}
}

