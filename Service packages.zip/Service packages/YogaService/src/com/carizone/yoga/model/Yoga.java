package com.carizone.yoga.model;

public class Yoga {
	int y_id;
	String p_name;
	String p_age;
	String yoga_desc;
	
	public Yoga()
	{
		super();
	}
	public Yoga(int yId,String pName,String pAge,String yogaDesc)
	{
		this.y_id=yId;
		this.p_name=pName;
		this.p_age=pAge;
		this.yoga_desc=yogaDesc;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public int getY_id() {
		return y_id;
	}
	public void setY_id(int y_id) {
		this.y_id = y_id;
	}
	
	public String getP_age() {
		return p_age;
	}
	public void setP_age(String p_age) {
		this.p_age = p_age;
	}
	public String getYoga_desc() {
		return yoga_desc;
	}
	public void setYoga_desc(String yoga_desc) {
		this.yoga_desc = yoga_desc;
	}

}
