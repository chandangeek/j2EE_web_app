package com.carizone.yoga.model;

public class YogaAlert {
	String a_disease;
	String a_desc;
	
	public YogaAlert(){
		super();
	}
	public YogaAlert(String aDisease,String aDesc)
	{
		this.a_disease=aDisease;
		this.a_desc=aDesc;
	}
	public String getA_disease() {
		return a_disease;
	}
	public void setA_disease(String a_disease) {
		this.a_disease = a_disease;
	}
	public String getA_desc() {
		return a_desc;
	}
	public void setA_desc(String a_desc) {
		this.a_desc = a_desc;
	}

}
