package com.carizone.yoga.model;

public class Subscriber {
	int s_id;
	int yg_id;
	int p_id;
	String p_name;
	String p_age;
	String p_disease;
	
	public Subscriber() {
		
		super();
	}
	
	
	public Subscriber(int yId,int pId,String pName,String pAge,String pDisease)
	{
		this.yg_id=yId;
		this.p_id=pId;
		this.p_name=pName;
		this.p_age=pAge;
		this.p_disease=pDisease;
	}
	public Subscriber(int sId,int ygId,int pId,String pName,String pAge,String pDisease)
	{
		this.s_id=sId;
		this.yg_id=ygId;
		this.p_id=pId;
		this.p_name=pName;
		this.p_age=pAge;
		this.p_disease=pDisease;
	}

	public int getS_id() {
		return s_id;
	}

	public void setS_id(int s_id) {
		this.s_id = s_id;
	}

	public int getYg_id() {
		return yg_id;
	}

	public void setYg_id(int yg_id) {
		this.yg_id = yg_id;
	}

	public int getP_id() {
		return p_id;
	}

	public void setP_id(int p_id) {
		this.p_id = p_id;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public String getP_age() {
		return p_age;
	}

	public void setP_age(String p_age) {
		this.p_age = p_age;
	}

	public String getP_disease() {
		return p_disease;
	}

	public void setP_disease(String p_disease) {
		this.p_disease = p_disease;
	}
	
	
	

}
