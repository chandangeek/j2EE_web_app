package com.carizone.yoga.model;

public class YogaSpec {
	int yg_id;
	String yg_desc;
	String p_age;
	
	public YogaSpec(){
		super();
	}
	
	public YogaSpec(int ygId,String ygDesc,String pAge)
	{
		this.yg_id=ygId;
		this.yg_desc=ygDesc;
		this.p_age=pAge;
	}

	public int getYg_id() {
		return yg_id;
	}

	public void setYg_id(int yg_id) {
		this.yg_id = yg_id;
	}

	public String getYg_desc() {
		return yg_desc;
	}

	public void setYg_desc(String yg_desc) {
		this.yg_desc = yg_desc;
	}

	public String getP_age() {
		return p_age;
	}

	public void setP_age(String p_age) {
		this.p_age = p_age;
	}

}
