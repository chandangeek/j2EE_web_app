package com.carizone.yoga.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.carizone.yoga.model.Subscriber;
import com.carizone.yoga.model.Yoga;
import com.carizone.yoga.model.YogaAlert;
import com.carizone.yoga.model.YogaSpec;
import com.carizone.yoga.util.DBConnection;

public class YogaService {
	Connection mConnection =  null;
	private Statement stmt = null;
	private PreparedStatement ps= null;
	ResultSet rs= null;
	int yid=0;
	public List<Yoga> getAllYogaSteps()
	{
		List<Yoga> yogasteps =null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			final String FETCH_USER_QUERY = "select * from yogaservice;";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			rs = ps.executeQuery();
			yogasteps = convertPojoList12(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return yogasteps;
	}
	private List<Yoga> convertPojoList12(ResultSet rs2) throws SQLException {
		List<Yoga> exerciseList = new ArrayList<Yoga>();
		while (rs.next()) {
			Yoga exercise = new Yoga(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
			exerciseList.add(exercise);
		}
		return exerciseList;
	}
	public List<Yoga> getYogasanas(String pName,String pAge)
	{
			List<Yoga> yogaInfo=null;
			try {
				mConnection = DBConnection.getDBConnection();
				final String FETCH_USER_QUERY = "select * from yogaservice where p_name='"+pName+"' and p_Age='"+pAge+"';";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				rs = ps.executeQuery();
				yogaInfo = convertPojoList(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return yogaInfo;
		}
	private List<Yoga> convertPojoList(ResultSet rs2) throws SQLException {
		List<Yoga> yogaList = new ArrayList<Yoga>();
		while (rs.next()) {
			Yoga tip = new Yoga(rs.getInt(1),rs.getString(4),rs.getString(2),rs.getString(3));
			yogaList.add(tip);
		}
		return yogaList;
	}
	public List<YogaSpec> getYogaMantras(int pId ,String pName,String pAge,String pDisease)
	{
		List<YogaSpec> yogaInfoSpec=null;
		//String page=null;
		int age = 0;
		int id = 0;
				try {
				mConnection = DBConnection.getDBConnection();
				age=roundoffAge(Integer.parseInt(pAge));
				//page=Integer.toString(age);
				System.out.println(age);
				final String FETCH_USER_QUERY = "select * from yogaspec where p_Age='"+age+"';";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				rs = ps.executeQuery();
				
//				if(rs.next())
//				{
				yogaInfoSpec = convertPojoList22(rs);
//				}
				if(rs.next())
					{
					id=rs.getInt(1);
				System.out.println(id);
					Subscriber subscriber=new Subscriber(id,pId,pName,pAge,pDisease);
					if(CheckSubscriber(pId,pAge)==0)
					{
					setSubscriberParamater(subscriber);
					System.out.println(pAge);
					}
				}
//				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return yogaInfoSpec;
		//	return getnextyogatip(age, id);
		}
	private List<YogaSpec> convertPojoList22(ResultSet rs2) throws SQLException {
		List<YogaSpec> yogaListSpec = new ArrayList<YogaSpec>();
		if (rs.next()) {
			yid=rs.getInt(1);
			System.out.println(yid);
			YogaSpec tip = new YogaSpec(yid,rs.getString(2),rs.getString(3));
			yogaListSpec.add(tip);
		}
		return yogaListSpec;
	}
	 public int CheckSubscriber(int pId, String pAge) throws SQLException
	 {
		 int result=0,age=0;
		 mConnection = DBConnection.getDBConnection();
			age=roundoffAge(Integer.parseInt(pAge));
			//page=Integer.toString(age);
			final String FETCH_USER_QUERY = "select * from subscriber where p_age='"+age+"'and p_id='"+pId+"';";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			rs = ps.executeQuery();
			if(rs.next())
			{
				result=1;
			}
			return result;
	 }
	
	private List<YogaSpec> convertPojoList21(ResultSet rs2,int y) throws SQLException {
		List<YogaSpec> yogaListSpec = new ArrayList<YogaSpec>();
		int yids = 0;
		while (rs.next()) {
			yids=rs.getInt(1);
			System.out.println(yids+" "+y);
//			if(yid!=currentyid)
//			{
			if(yids>y)
			{
			YogaSpec tip = new YogaSpec(yids,rs.getString(2),rs.getString(3));
			yogaListSpec.add(tip);
			break;
			}
		}
		return yogaListSpec;
	}
public void setSubscriberParamater(Subscriber subscriber) {
		
		final String FETCH_USER_QUERY = "INSERT INTO subscriber values(?,?,?,?,?,?)";
		int rss=0;
//		boolean res=false;
		Connection mConnection = null;

			//List<Subscriber> subscriberInfo = null;
			try {
				mConnection = DBConnection.getDBConnection();
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				stmt = mConnection.createStatement();
				int sid;
				ResultSet rs = stmt.executeQuery("select max(s_id) from subscriber;");
				if(rs.next())
				{
					sid=rs.getInt(1);
					sid+=1;
					subscriber.setS_id(sid);
				}
				System.out.println(subscriber.getYg_id());
				ps.setInt(1, subscriber.getS_id());
				ps.setInt(2,subscriber.getYg_id());
				ps.setInt(3,subscriber.getP_id());
				ps.setString(4,subscriber.getP_name());
				ps.setString(5,subscriber.getP_age());
				ps.setString(6,subscriber.getP_disease());
				rss=ps.executeUpdate();
			//	userInfo = convertPojoList(rs);
//				if(rss != 0)
//				{
//					res=true;
//				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
//			return res;
	}
	int currentyid=0;
	public List<YogaSpec> getnextyogatip(int page,int yid)
	{
		List<YogaSpec> yogaInfoSpec=null;
		int age=roundoffAge(page);
		System.out.println(age);
			try {
				mConnection = DBConnection.getDBConnection();
				final String FETCH_USER_QUERY = "select * from yogaspec where yg_id!="+yid+" and p_age='"+age+"';";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				rs = ps.executeQuery();
				
			//	 page=rs.getInt(3);
			//	yid+=1;
			//	if(rs.next())
			//	{
			//		if(yid!=rs.getInt(1) && page!=rs.getInt(3))
			//		yid++;
					
					
			//	}
//				currentyid=yid;
//				System.out.println(currentyid);
				yogaInfoSpec = convertPojoList21(rs,yid);
				/*if(rs.next())
				{
						int j = rs.getInt(1);
						if(j!=rs.getInt(1)&& page==rs.getInt(3))
						{
							 j = j++ ;                                              //rs.getInt(3);
							 return yogaInfoSpec;
							 
						}
				}*/
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return yogaInfoSpec;
	}
	
	public List<YogaSpec> getbacktip(int page,int yid)
	{
		List<YogaSpec> yogaBackInfoSpec=null;
		int age=roundoffAge(page);
			try {
				mConnection = DBConnection.getDBConnection();
				final String FETCH_USER_QUERY = "select * from yogaspec where yg_id="+yid+" and p_age='"+age+"';";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				rs = ps.executeQuery();
				
			
				yogaBackInfoSpec = convertPojoList23(rs);
				
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return yogaBackInfoSpec;
	}
	private List<YogaSpec> convertPojoList23(ResultSet rs2) throws SQLException {
		List<YogaSpec> yogaListSpec = new ArrayList<YogaSpec>();
		if (rs.next()) {
			YogaSpec tip = new YogaSpec(rs.getInt(1),rs.getString(2),rs.getString(3));
			yogaListSpec.add(tip);
		}
		return yogaListSpec;
	}
	
	public List<YogaSpec> getYogaTip(int yid)
	{
		List<YogaSpec> yogaInfoSpec=null;
			try {
				mConnection = DBConnection.getDBConnection();
				final String FETCH_USER_QUERY = "select * from yogaspec where yg_id="+yid+";";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				rs = ps.executeQuery();
				yogaInfoSpec = convertPojoList22(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return yogaInfoSpec;
	}
	
	public int roundoffAge(int age)
	{
		int res=100;
		System.out.println(age);
		if(age<5)
		{
			res=5;
		}
		else if(age>5 && age<=10)
		{
			res=10;
		}
//		else if(age>10 && age <15)
//		{
//			res=15;
//		}
		else if(age>10 && age <=20)
		{
			res=20;
		}
//		else if(age>20 && age <25)
//		{
//			res=25;
//		}
		else if(age>20 && age <=30)
		{
			res=30;
		}
//		else if(age>30 && age <35)
//		{
//			res=35;
//		}
		else if(age>30 && age <=40)
		{
			res=40;
		}
//		else if(age>40 && age <45)
//		{
//			res=45;
//		}
		else if(age>40 && age <=50)
		{
			res=50;
		}
//		else if(age>50 && age <55)
//		{
//			res=55;
//		}
		else if(age>50 && age <=60)
		{
			res=60;
		}
		else if(age>50 && age <=70)
		{
			res=70;
		}
		else if(age>70 && age <=80)
		{
			res=80;
		}
		else 
		{
			res=90;
		}
//		else if(age>60 && age <65)
//		{
//			res=65;
//		}
		return res;
	}
	public List<YogaAlert> getYogaAlert(String aDisease)
	{
		List<YogaAlert> yogaInfoAlert=null;
		//String page=null;
		//String disease;
				try {
				mConnection = DBConnection.getDBConnection();
				//disease=diseaseAlert();
				//page=Integer.toString(age);
			//	System.out.println(disease);
				final String FETCH_USER_QUERY = "select * from yogaalert where a_disease='"+aDisease+"';";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				rs = ps.executeQuery();
//				if(rs.next())
//				{
				yogaInfoAlert = convertPojoList33(rs);
				System.out.println(yogaInfoAlert);
//				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return yogaInfoAlert;
		}
	private List<YogaAlert> convertPojoList33(ResultSet rs2) throws SQLException {
		List<YogaAlert> yogaListAlert = new ArrayList<YogaAlert>();
		while (rs.next()) {
			YogaAlert alert = new YogaAlert(rs.getString(1),rs.getString(2));
			yogaListAlert.add(alert);
		}
		return yogaListAlert;
	}
	/*public String diseaseAlert(String disease)
	{
		String resa="malaria";
		String resb="diarrhea";
		String resc="heart";
		if(disease=="malaria")
		{
			
			
		}
		
	}*/
}

