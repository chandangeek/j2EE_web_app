package com.carizone.yoga.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.carizone.yoga.model.Yoga;
import com.carizone.yoga.model.YogaAlert;
import com.carizone.yoga.model.YogaSpec;
import com.carizone.yoga.service.YogaService;


@Path("/yoga")
public class YogaResource {
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Yoga> getAllYoga()
	{
		List<Yoga> list=null;
		YogaService service = new YogaService();
		list=service.getAllYogaSteps();
		return list;
	}
	@Path("/yogasana/{pname}/{page}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Yoga> getYogaDetails(@PathParam("pname") String pname,@PathParam("page") String page)
	{
		List<Yoga> list=null;
		YogaService service=new YogaService();
		list=service.getYogasanas(pname,page);
		return list;
	}
	@Path("/yogamantra/{pid}/{pname}/{page}/{pdisease}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<YogaSpec> getYogas(@PathParam("pid") int pid,@PathParam("pname") String pname,@PathParam("page") String page,@PathParam("pdisease") String pdisease )
		{
			List<YogaSpec> list=null;
			YogaService service=new YogaService();
			list=service.getYogaMantras(pid,pname,page,pdisease);
			return list;
	}
	
	
	@Path("/nexttip/{page}/{yid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<YogaSpec> getNextTip(@PathParam("page") int page,@PathParam("yid") int yid)
		{
			List<YogaSpec> list=null;
			YogaService service=new YogaService();
			list=service.getnextyogatip(page,yid);
			return list;
	}
	@Path("/backtip/{page}/{yid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<YogaSpec> getBackTip(@PathParam("page") int page,@PathParam("yid") int yid)
	{
		List<YogaSpec> list=null;
		YogaService service=new YogaService();
		list=service.getbacktip(page,yid);
		return list;
	}
	
	@Path("/{yid}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<YogaSpec> getTip(@PathParam("yid") int yid)
		{
			List<YogaSpec> list=null;
			YogaService service=new YogaService();
			list=service.getYogaTip(yid);
			return list;
	}
	@Path("/yogaalert/{adisease}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<YogaAlert> getAlert(@PathParam("adisease") String adisease)
	{
		List<YogaAlert> list=null;
		YogaService service=new YogaService();
		list=service.getYogaAlert(adisease);
		return list;
	}
}
