var patname ,patage;
//function getagedisease()
//{
//	patage = getParam("patage");
//	patdisease= getParam("patdisease");
//}

function getParam(name)
{  
    name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");  
    var regexS = "[\\?&]"+name+"=([^&#]*)";  
    var regex = new RegExp( regexS );  
    var results = regex.exec(window.location.href);
    if(results == null)
        return "";  
    else    
        return results[1];
}
function getall()
{
	$("#container").hide();
//	 	$("#bdy").mouseover(function(event){
	           $.get('rest/yoga/yogasana/'+patname+'/'+patage,function(responseJson) {
	            if(responseJson!=null){
	               // $("#table").find("tr:gt(0)").remove();
	                $.each(responseJson, function(key,value) { 
	                	document.getElementById("yoga").innerHTML=value.yoga_desc;
	                });
	                }
	            });
	            $("#container").show();    
	          

//	   });      
	}
//window.onload=getagedisease;
//var patname,patage,patdisease;
function getagedisease1()
{
	patname = getParam("patname");
	patage = getParam("patage");
	
    if(patname!="" && patage!="")
  	  {
//  	  $("#container").show();
    	document.getElementById("name").innerHTML=patname;
    	document.getElementById("aged").innerHTML=patage;
  	  }
   
  getall();
}



/*
$('a').on('click',function(e){
  e.preventDefault();
});*/