function download(tet)
{
 window.location=tet;
}