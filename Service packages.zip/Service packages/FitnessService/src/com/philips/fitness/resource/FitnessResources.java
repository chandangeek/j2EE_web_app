package com.philips.fitness.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.philips.fitness.model.ExerciseProcedure;
import com.philips.fitness.model.ExerciseService;
import com.philips.fitness.model.HealthyTips;
import com.philips.fitness.model.NutritionDiet;
import com.philips.fitness.service.FitnessService;

@Path("/fitness")
public class FitnessResources {
		
		@GET
		@Produces(MediaType.APPLICATION_JSON)
		public List<ExerciseService> getAllExe()
		{
			List<ExerciseService> list =null;
			FitnessService service=new FitnessService();
			list=service.getAllExercise();
			return list;
		}
		@Path("/exercise/{page}/{pdisease}")
		@GET
		@Produces(MediaType.APPLICATION_JSON)
		public List<ExerciseProcedure> getFitnessDetails(@PathParam("page") String page,@PathParam("pdisease") String pdisease)
		{
			List<ExerciseProcedure> list=null;
			FitnessService service=new FitnessService();
			list=service.getExerciseDetails(page,pdisease);
			return list;
		}
		@Path("/nutrition/{pname}/{page}/{pdisease}")
		@GET
		@Produces(MediaType.APPLICATION_JSON)
		public List<NutritionDiet> getNutritionDetails(@PathParam("pname") String pname,@PathParam("page")String page,@PathParam("pdisease") String pdisease)
		{
			List<NutritionDiet> list=null;
			FitnessService service=new FitnessService();
			list=service.getNutritionDiet(pname,page,pdisease);
			return list;

		}

		@Path("/tips/{pname}/{pdisease}")
		@GET
		@Produces(MediaType.APPLICATION_JSON)
		public List<HealthyTips> getTips(@PathParam("pname") String pname,@PathParam("pdisease") String pdisease)
		{
			List<HealthyTips> list=null;
			FitnessService service=new FitnessService();
			list=service.getHealthTip(pname,pdisease);
			return list;
		}
}

