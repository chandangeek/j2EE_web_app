package com.philips.fitness.model;

public class ExerciseProcedure {
	int ex_id;
	String pat_age;
	public int getEx_id() {
		return ex_id;
	}
	public void setEx_id(int ex_id) {
		this.ex_id = ex_id;
	}
	public void setPat_age(String pat_age) {
		this.pat_age = pat_age;
	}
	String pat_disease;
	String exe_proc;
	
	public ExerciseProcedure()
	{
		super();
	}
	
	public String getPat_disease() {
		return pat_disease;
	}
	public void setPat_disease(String pat_disease) {
		this.pat_disease = pat_disease;
	}
	public String getExe_proc() {
		return exe_proc;
	}
	public void setExe_proc(String exe_proc) {
		this.exe_proc = exe_proc;
	}
public ExerciseProcedure(int exId,String patAge,String patDisease,String exeProc){
	this.ex_id=exId;
	this.pat_age=patAge;
	this.pat_disease=patDisease;
	this.exe_proc=exeProc;
}
}
