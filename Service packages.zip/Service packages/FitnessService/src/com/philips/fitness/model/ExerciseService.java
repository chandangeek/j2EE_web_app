package com.philips.fitness.model;

public class ExerciseService {
	int ex_id;
	int pat_id;
	String pat_name;
	int pat_age;
	String pat_disease;
	String exe_desc;
	
	
	public ExerciseService()
	{
		super();
	}
	public int getEx_id() {
		return ex_id;
	}
	public void setEx_id(int ex_id) {
		this.ex_id = ex_id;
	}
	public int getPat_id() {
		return pat_id;
	}
	public void setPat_id(int pat_id) {
		this.pat_id = pat_id;
	}
	public String getPat_name() {
		return pat_name;
	}
	public void setPat_name(String pat_name) {
		this.pat_name = pat_name;
	}
	public int getPat_age() {
		return pat_age;
	}
	public void setPat_age(int pat_age) {
		this.pat_age = pat_age;
	}
	public String getPat_disease() {
		return pat_disease;
	}
	public void setPat_disease(String pat_disease) {
		this.pat_disease = pat_disease;
	}
	public String getExe_desc() {
		return exe_desc;
	}
	public void setExe_desc(String exe_desc) {
		this.exe_desc = exe_desc;
	}
	public ExerciseService(int ex_id,int pat_id,String pat_name,int pat_age,String pat_disease,String exe_desc)
	{
		this.ex_id=ex_id;
		this.pat_id=pat_id;
		this.pat_name=pat_name;
		this.pat_age=pat_age;
		this.pat_disease=pat_disease;
		this.exe_desc=exe_desc;
	}
	

}
