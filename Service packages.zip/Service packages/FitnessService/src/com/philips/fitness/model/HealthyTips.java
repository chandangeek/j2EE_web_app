package com.philips.fitness.model;

public class HealthyTips {
	int h_id;
	String pat_name;
	String pat_disease;
	String pat_tips;

	public HealthyTips()
	{
		super();
	}
	public HealthyTips(int hId,String patName,String patDisease,String patTips){
		this.h_id=hId;
		this.pat_name=patName;
		this.pat_disease=patDisease;
		this.pat_tips=patTips;
	}
	public int getH_id() {
		return h_id;
	}
	public void setH_id(int h_id) {
		this.h_id = h_id;
	}
	public String getPat_name() {
		return pat_name;
	}
	public void setPat_name(String pat_name) {
		this.pat_name = pat_name;
	}
	public String getPat_disease() {
		return pat_disease;
	}
	public void setPat_disease(String pat_disease) {
		this.pat_disease = pat_disease;
	}
	public String getPat_tips() {
		return pat_tips;
	}
	public void setPat_tips(String pat_tips) {
		this.pat_tips = pat_tips;
	}
}
