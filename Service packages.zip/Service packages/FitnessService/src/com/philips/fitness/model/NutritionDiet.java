package com.philips.fitness.model;

public class NutritionDiet {
	int n_id;
	String pat_name;
	String pat_age;
	String pat_disease;

	public NutritionDiet()
	{
		super();
	}

	public int getN_id() {
		return n_id;
	}

	public void setN_id(int n_id) {
		this.n_id = n_id;
	}

	public String getPat_name() {
		return pat_name;
	}

	public void setPat_name(String pat_name) {
		this.pat_name = pat_name;
	}

	public String getPat_age() {
		return pat_age;
	}

	public void setPat_age(String pat_age) {
		this.pat_age = pat_age;
	}

	public String getPat_disease() {
		return pat_disease;
	}

	public void setPat_disease(String pat_disease) {
		this.pat_disease = pat_disease;
	}
	public NutritionDiet(int nId,String patName,String patAge,String patDisease){
		
	this.n_id=nId;
	this.pat_name=patName;
	this.pat_age=patAge;
	this.pat_disease=patDisease;
	}
}
