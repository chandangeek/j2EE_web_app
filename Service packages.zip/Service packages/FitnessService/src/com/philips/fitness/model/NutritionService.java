package com.philips.fitness.model;

public class NutritionService {
	int n_id;
	int pat_id;
	String pat_name;
	int pat_age;
	String pat_disease;
	String diet_desc;
	
	public NutritionService()
	{
		super();
	}

	public int getN_id() {
		return n_id;
	}

	public void setN_id(int n_id) {
		this.n_id = n_id;
	}

	public int getPat_id() {
		return pat_id;
	}

	public void setPat_id(int pat_id) {
		this.pat_id = pat_id;
	}

	public String getPat_name() {
		return pat_name;
	}

	public void setPat_name(String pat_name) {
		this.pat_name = pat_name;
	}

	public int getPat_age() {
		return pat_age;
	}

	public void setPat_age(int pat_age) {
		this.pat_age = pat_age;
	}

	public String getPat_disease() {
		return pat_disease;
	}

	public void setPat_disease(String pat_disease) {
		this.pat_disease = pat_disease;
	}

	public String getDiet_desc() {
		return diet_desc;
	}

	public void setDiet_desc(String diet_desc) {
		this.diet_desc = diet_desc;
	}
	public NutritionService(int n_id,int pat_id,String pat_name,int pat_age,String pat_disease,String diet_desc)
	{
		this.n_id=n_id;
		this.pat_id=pat_id;
		this.pat_name=pat_name;
		this.pat_age=pat_age;
		this.pat_disease=pat_disease;
		this.diet_desc=diet_desc;
	}

}
