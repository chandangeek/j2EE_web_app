package com.philips.fitness.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.philips.fitness.model.ExerciseProcedure;
import com.philips.fitness.model.ExerciseService;
import com.philips.fitness.model.HealthyTips;
import com.philips.fitness.model.NutritionDiet;
import com.philips.fitness.util.DBConnection;

public class FitnessService {
	Connection mConnection =  null;
	private Statement stmt = null;
	private PreparedStatement ps= null;
	ResultSet rs= null;
	public List<ExerciseService> getAllExercise()
	{
		List<ExerciseService> exercise =null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			final String FETCH_USER_QUERY = "select * from exercise;";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			rs = ps.executeQuery();
			exercise = convertPojoList12(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return exercise;
	}
	private List<ExerciseService> convertPojoList12(ResultSet rs) throws SQLException  {
		List<ExerciseService> exerciseList = new ArrayList<ExerciseService>();
		while (rs.next()) {
			ExerciseService exercise = new ExerciseService(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getInt(4),rs.getString(5),rs.getString(6));
			exerciseList.add(exercise);
		}
		
		return exerciseList;
	}
	public List<ExerciseProcedure> getExerciseDetails(String patAge,String patDisease)
	{
			List<ExerciseProcedure> fitnessInfo=null;
			try {
				mConnection = DBConnection.getDBConnection();
				final String FETCH_USER_QUERY = "select * from exeprocedure where pat_age="+patAge+" and pat_disease='"+patDisease+"';";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				rs = ps.executeQuery();
				fitnessInfo = convertPojoList(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return fitnessInfo;
		}
	
private List<ExerciseProcedure> convertPojoList(ResultSet rs) throws SQLException {

	List<ExerciseProcedure> fitList = new ArrayList<ExerciseProcedure>();
	while (rs.next()) {
		ExerciseProcedure fit = new ExerciseProcedure(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
		fitList.add(fit);
	}
	return fitList;
}

public List<NutritionDiet> getNutritionDiet(String patName,String patAge,String patDisease)
{
	List<NutritionDiet> nutritionInfo=null;
	try {
		mConnection = DBConnection.getDBConnection();
		final String FETCH_USER_QUERY = "select * from nutritiondiet where pat_name='"+patName+"' and pat_age='"+patAge+"' and pat_disease='"+patDisease+"';";
		ps = mConnection.prepareStatement(FETCH_USER_QUERY);
		rs = ps.executeQuery();
		ResultSet rs2 = null;
		nutritionInfo = convertPojoList11(rs2);
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		try {
			if (stmt != null) {
				stmt.close();
			}
			if (mConnection != null) {
				mConnection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	return nutritionInfo;
}
private List<NutritionDiet> convertPojoList11(ResultSet rs2) throws SQLException{

	List<NutritionDiet> nutList = new ArrayList<NutritionDiet>();
	while (rs.next()) {
		NutritionDiet nut = new NutritionDiet(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
		nutList.add(nut);
	}
	
	return nutList;
}
public List<HealthyTips> getHealthTip(String patName,String patDisease){
	
	List<HealthyTips> tipInfo=null;
	try {
		mConnection = DBConnection.getDBConnection();
		final String FETCH_USER_QUERY = "select * from healthytips where pat_name='"+patName+"'and pat_disease='"+patDisease+"';";
		ps = mConnection.prepareStatement(FETCH_USER_QUERY);
		rs = ps.executeQuery();
		ResultSet rs3 = null;
		tipInfo = convertPojoList13(rs3);
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		try {
			if (stmt != null) {
				stmt.close();
			}
			if (mConnection != null) {
				mConnection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	return tipInfo;
}
private List<HealthyTips> convertPojoList13(ResultSet rs3) throws SQLException {
	List<HealthyTips> tipList = new ArrayList<HealthyTips>();
	while (rs.next()) {
		HealthyTips tip = new HealthyTips(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4));
		tipList.add(tip);
	}
	
	return tipList;
}

}
