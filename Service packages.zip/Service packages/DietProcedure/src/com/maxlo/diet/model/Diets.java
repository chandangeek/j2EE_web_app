package com.maxlo.diet.model;

public class Diets {
 int dt_id;
 int p_id;
 String p_age;
 String p_disease;
 String diet_desc;
 
 public Diets()
 {
	 super();
 }
 public Diets(int dtId,int pId,String pAge,String pDisease, String dietDesc)
 {
	 this.dt_id=dtId;
	 this.p_id=pId;
	 this.p_age=pAge;
	 this.p_disease=pDisease;
	 this.diet_desc=dietDesc;
 }
public int getDt_id() {
	return dt_id;
}
public void setDt_id(int dt_id) {
	this.dt_id = dt_id;
}
public int getP_id() {
	return p_id;
}
public void setP_id(int p_id) {
	this.p_id = p_id;
}
public String getP_age() {
	return p_age;
}
public void setP_age(String p_age) {
	this.p_age = p_age;
}
public String getP_disease() {
	return p_disease;
}
public void setP_disease(String p_disease) {
	this.p_disease = p_disease;
}
public String getDiet_desc() {
	return diet_desc;
}
public void setDiet_desc(String diet_desc) {
	this.diet_desc = diet_desc;
}
}