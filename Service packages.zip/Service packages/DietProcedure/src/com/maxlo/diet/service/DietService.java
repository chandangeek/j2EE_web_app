package com.maxlo.diet.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.maxlo.diet.model.Diets;
import com.maxlo.diet.util.DBConnection;

public class DietService {
	Connection mConnection =  null;
	private Statement stmt = null;
	private PreparedStatement ps= null;
	ResultSet rs= null;
	public List<Diets> getAllDiet()
	{
		List<Diets> diet =null;
		try {
			mConnection = DBConnection.getDBConnection();
			stmt = mConnection.createStatement();
			final String FETCH_USER_QUERY = "select * from dietprocedure;";
			ps = mConnection.prepareStatement(FETCH_USER_QUERY);
			rs = ps.executeQuery();
			diet = convertPojoList12(rs);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (mConnection != null) {
					mConnection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return diet;
	}
	private List<Diets> convertPojoList12(ResultSet rs) throws SQLException {
		List<Diets> dietList = new ArrayList<Diets>();
		while (rs.next()) {
			Diets diet = new Diets(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getString(5));
			dietList.add(diet);
		}
		return dietList;
	}
	public List<Diets> getDietDetails(String pId,String pAge,String pDisease)
	{
			List<Diets> dietInfo=null;
			try {
				mConnection = DBConnection.getDBConnection();
				final String FETCH_USER_QUERY = "select * from dietprocedure where p_id="+pId+" and p_age="+pAge+" and p_disease='"+pDisease+"';";
				ps = mConnection.prepareStatement(FETCH_USER_QUERY);
				rs = ps.executeQuery();
				dietInfo = convertPojoList(rs);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (stmt != null) {
						stmt.close();
					}
					if (mConnection != null) {
						mConnection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return dietInfo;
		}
	private List<Diets> convertPojoList(ResultSet rs2) throws SQLException {
		List<Diets> caloriList = new ArrayList<Diets>();
		while (rs.next()) {
			Diets calories = new Diets(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getString(5));
			caloriList.add(calories);
		}
		return caloriList;
	}

}
