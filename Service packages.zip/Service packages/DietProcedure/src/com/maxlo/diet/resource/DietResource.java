package com.maxlo.diet.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.maxlo.diet.model.Diets;
import com.maxlo.diet.service.DietService;

@Path("/diet")
public class DietResource {
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Diets> getAllDiet()
	{
		List<Diets> list=null;
		DietService service = new DietService();
		list=service.getAllDiet();
		return list;
	}
	@Path("/dietplan/{pid}/{page}/{pdisease}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Diets> getFitnessDetails(@PathParam("pid") String pid,@PathParam("page") String page,@PathParam("pdisease") String pdisease)
	{
		List<Diets> list=null;
		DietService service=new DietService();
		list=service.getDietDetails(pid,page,pdisease);
		return list;
	}

}
