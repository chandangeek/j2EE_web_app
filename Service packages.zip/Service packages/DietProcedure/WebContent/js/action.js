var patid,patname ,patage,patdisease;
//function getagedisease()
//{
//	patage = getParam("patage");
//	patdisease= getParam("patdisease");
//}

function getParam(name)
{  
    name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");  
    var regexS = "[\\?&]"+name+"=([^&#]*)";  
    var regex = new RegExp( regexS );  
    var results = regex.exec(window.location.href);
    if(results == null)
        return "";  
    else    
        return results[1];
}
function getall()
{
	$("#container").hide();
//	 	$("#bdy").mouseover(function(event){
	           $.get('rest/diet/dietplan/'+patid+'/'+patage+'/'+patdisease,function(responseJson) {
	            if(responseJson!=null){
	               // $("#table").find("tr:gt(0)").remove();
	                //var table1 = $("#patienttable");
	                $.each(responseJson, function(key,value) { 
	                	document.getElementById("diet").innerHTML=value.diet_desc;
	                });
	                }
	            });
	            $("#container").show();          
//	   });      
	}
//window.onload=getagedisease;
//var patname,patage,patdisease;
function getagedisease1()
{
	patid = getParam("patid");
	patname = getParam("patname");
	patage = getParam("patage");
	patdisease= getParam("patdisease");
	
    if(patname!="" && patage!=" "&& patdisease!="")
  	  {
//  	  $("#container").show();
    	document.getElementById("pid").innerHTML=patname;
    	document.getElementById("aged").innerHTML=patage;
    	document.getElementById("diseased").innerHTML=patdisease;
  	  }
   
  getall();
}



/*
$('a').on('click',function(e){
  e.preventDefault();
});*/